<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('includes/head'); ?>
</head>

<body class="boxed" onload="getOrder()">
	<div id="wrapper">
		<div class="page-wrapper">
    		<?php $this->load->view('includes/header'); ?>
			<main class="page-main">
				<div class="block">
					<div class="container">
						<div class="page-title">
							<div class="title">
								<h1>My Dashboard</h1>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="">
									<ul class="category-list">
										<li><a href="<?=base_url()?>acc-details">Account Details</a></li>
										<li><a href="<?=base_url()?>acc-wallet">My Wallet</a></li>
										<li class="active"><a href="<?=base_url()?>account">My Order History</a></li>
										<li><a href="<?=base_url()?>logout">Logout</a></li>
									</ul>
								</div>
								<div class="divider divider-lg"></div>
							</div>
							<div class="col-md-9">
								<h2>Order History</h2>
								<div class="table-responsive">
									<table class="table table-bordered table-striped">
										<thead>
											<tr>
												<th scope="col"># </th>
												<th scope="col">Order Code</th>
												<th scope="col">Order Date </th>
												<th scope="col">Total Price</th>
												<th scope="col">Cook</th>
												<th scope="col">Status</th>
											</tr>
										</thead>
										<tbody id="order_body">
											
										</tbody>
									</table>
									<!-- <pre> -->
										<?php 
											// print_r($orders);
										?>
									<!-- </pre> -->
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- Footer -->
    		<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		function getOrder(){  
			// alert('hi');
			let status = '';
			let order_body = '';
			$('#order_body').empty();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>get_order_ajax',
				data: 'search=3845784',
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						for (let i = 0; i < res.message.length; i++) {
							switch (res.message[i]['order_status']) {
								case '1':
									status = 'Order Placed';
									break;
								case '2':
									status = 'Cooking';
									break;
								case '3':
									status = 'Packed';
									break;
								case '4':
									status = 'Ready to Pick';
									break;
								case '5':
									status = 'Delivered';
									break;
								case '6':
									status = 'Cancelled';
									break;
							}
							// alert(status);
							order_body += '<tr>'+
												'<td>'+(i+1)+'</td>'+
												'<td><b>'+res.message[i]['order_code']+'</b> <a href="javascript:open_order('+res.message[i]['order_id']+')" class="pull-right">View Details</a></td>'+
												'<td>'+res.message[i]['order_date']+'</td>'+
												'<td><span class="color">Rs.'+res.message[i]['order_amount']+'</span></td>'+
												'<td>'+res.message[i]['f_name']+' '+res.message[i]['l_name']+'</td>'+
												'<td><a href="#" class="btn btn-sm">'+status+'</a></td>'+
											'</tr>';
						}
						$('#order_body').append(order_body);
					}
				},
				error: function (result){  

				}
			});
		}
	</script>
	<script>
		function open_order(id){  
			// alert(id);
			window.open("<?php echo site_url('view_order/'); ?>" + btoa(id), '_blank');
		}
	</script>

</body>

</html>