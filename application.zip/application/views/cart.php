<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Head -->
		<?php $this->load->view('includes/head'); ?>
	<!-- /Head -->
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
			<!-- Header -->
    			<?php $this->load->view('includes/header'); ?>
			<!-- /Header -->
			<main class="page-main">
				<div class="block">
					<div class="container">
						<div class="cart-table">
							<div class="table-header">
								<div class="photo">
									Product Image
								</div>
								<div class="name">
									Product Name
								</div>
								<div class="price">
									Unit Price
								</div>
								<div class="qty">
									Qty
								</div>
								<div class="subtotal">
									Subtotal
								</div>
								<div class="remove">
									<span class="hidden-sm hidden-xs">Remove</span>
								</div>
							</div>
							<!-- <pre> -->
								<?php
									// print_r($this->cart->contents());
								?>
							<!-- </pre> -->
							<?php
								$total = 0;
								foreach ($this->cart->contents() as $key => $value) {
							?>
							<div class="table-row" id="row_<?=$value['rowid']?>">
								<div class="photo">
									<a href="product.html"><img src="<?=PHOTO_DOMAIN.$value['options']['image']?>" alt=""></a>
								</div>
								<div class="name">
									<a href="product.html"><?=$value['name']?></a>
								</div>
								<div class="price" id="cart_price_<?=$value['rowid']?>" dat-price="<?=$value['price']?>">
									Rs.<?=$value['price']?>
								</div>
								<div class="qty qty-changer">
									<fieldset>
										<input type="button" value="&#8210;" class="decrease" onclick="decrease_qty('<?=$value['rowid']?>')">
										<input type="text" class="qty-input" id="cart_qty_<?=$value['rowid']?>" value="<?=$value['qty']?>" data-min="0" data-max="5">
										<input type="button" value="+" class="increase" onclick="increase_qty('<?=$value['rowid']?>')">
									</fieldset>
								</div>
								<div class="subtotal" id="cart_sub_<?=$value['rowid']?>">
									Rs.<?=$value['subtotal']?>
								</div>
								<div class="remove">
									<a href="javascript:remove_item('<?=$value['rowid']?>')" class="icon icon-close-2"></a>
								</div>
							</div>
							<?php 
								$total = $total + $value['subtotal'];
								} 
							?>
							<div class="table-footer">
								<a href="<?=base_url()?>" class="btn btn-alt">CONTINUE Buying</a>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3 total-wrapper">
								<table class="total-price">
									<tr>
										<td>Subtotal</td>
										<td id="cart_subtotal">Rs.<?=$total?></td>
									</tr>
									<tr class="total">
										<td>Grand Total</td>
										<td id="cart_grandtotal">Rs.<?=$total?></td>
									</tr>
								</table>
								<div class="cart-action">
									<div>
										<a href="javascript:checkout_order()" class="btn">Proceed To Checkout</a>
									</div>
									<!-- <pre> -->
									<?php 
									 	// print_r(if($this->session->userdata('cust_logged_in')['cust_id']));
										// echo $this->session->userdata('cust_logged_in')['cust_id'];
									?>
									<!-- <a href="#">Checkout with Multiple Addresses</a> -->
									<!-- </pre> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</main>
			<!-- Footer -->
    			<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- Modal -->
	<div class="modal fade" id="signin-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title" id="meal_name">Please Login to check</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="loginForm">
								<div id="item_body">
									<label>E-mail<span class="required">*</span></label>
									<input type="email" class="form-control input-lg" name="email" id="modalloginemail" placeholder="Email Address" data-error="Please enter a valid email address.">
									<label>Password<span class="required">*</span></label>
									<input type="password" class="form-control input-lg" placeholder="Password" name="password" data-required-error="Password is Required" required>
									<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="login_tbn">Login</button>
									<div class="back"><a href="<?=base_url()?>login">Create an account</a></div>

								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		function remove_item(id){
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>remove_from_cart_ajax',
				data: 'id='+id,
				success: function(result){  
					let res = $.parseJSON(result);
					console.log(res.count);
					$('#cart_count').text(res.count);
					$('#cart_grandtotal').text('Rs.'+res.total);
					$('#cart_subtotal').text('Rs.'+res.total);
					$('#row_'+id).remove();
				},
				error: function(result){  

				}
			});
		}
		
	</script>
	<script>
		function increase_qty(id){  
			// alert($('#cart_qty_'+id).val()+1);
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>update_cart_qty_ajax',
				data: 'rowid='+id+'&qty='+$('#cart_qty_'+id).val()+'&type=1',
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						let new_qty = parseInt($('#cart_qty_'+id).val());
						let price_new = parseInt($('#cart_price_'+id).attr('dat-price'));
						
						// alert(price_new * (new_qty+1));
						$('#cart_qty_'+id).val(new_qty+1);
						$('#cart_sub_'+id).html('Rs.'+(price_new * (new_qty+1)));
						$('#cart_subtotal').html('Rs.'+res.message);
						$('#cart_grandtotal').html('Rs.'+res.message);
					}else{
	                    toastr["error"](res.message);
					}
					

				},
				error: function (result){  

				}
			});
		}
		function decrease_qty(id){  
			// alert($('#cart_qty_'+id).val()-1);
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>update_cart_qty_ajax',
				data: 'rowid='+id+'&qty='+$('#cart_qty_'+id).val()+'&type=2',
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						let new_qty = parseInt($('#cart_qty_'+id).val());
						let price_new = parseInt($('#cart_price_'+id).attr('dat-price'));
						
						// alert(price_new * (new_qty+1));
						$('#cart_qty_'+id).val(new_qty-1);
						$('#cart_sub_'+id).html('Rs.'+(price_new * (new_qty-1)));
						$('#cart_subtotal').html('Rs.'+res.message);
						$('#cart_grandtotal').html('Rs.'+res.message);
						if ((new_qty-1) < 1) {
							$('#row_'+id).remove();
							$('#cart_count').text(res.count);
						}
					}else{
	                    toastr["error"](res.message);
					}
				},
				error: function (result){  

				}
			});
		}
	</script>
	<script>
		function checkout_order(){
			let vals = "<?=$this->session->userdata('cust_logged_in')['cust_id']?>";
			console.log(vals);
			if (vals == 0 || vals == '' || vals == null) {
				// alert('login form');
				$('#signin-modal').modal('show');
				
			}else{
				// $.ajax({
				// 	type: 'POST',
				// 	url: '<?=base_url()?>check_out_check_ajax',
				// 	data: 'id='+vals,
				// 	success: function(result){  
				// 		// let res = $.parseJSON(result);
				// 		// if (res.status == 'success') {
				// 		// 	alert('Success');
				// 		// }else{
				// 		// 	alert('login required');
				// 		// }

				// 	},
				// 	error: function(result){  

				// 	}
				// });
				window.location.href = "<?=base_url()?>checkout";
			}
			
		}
	</script>
	<script>
		$('#loginForm').on('submit', function (e) {
			// alert('hi');
			if (!(e.isDefaultPrevented())) {
				e.preventDefault();
				$.ajax({
					type: "POST",
					url: "<?=base_url()?>sign-in",
					data: $('#loginForm').serialize(),
					success: function(result) {
						var responsedata = $.parseJSON(result);
						if(responsedata.status=='success'){
							window.location.href = "<?=base_url()?>checkout";
						}else{
							document.getElementById('loginForm').reset(); 
							$('#loginForm').find("input").val("");
							toastr["error"](responsedata.message);
						}
					},
					error: function(result) {
						toastr["error"](result);
					}
				});
			}
		});
	</script>

</body>

</html>