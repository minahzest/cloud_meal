<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('includes/head'); ?>
	<style>
		.details-tag{
			position: relative;
			display: block;
			padding: 11px 0;
			font-size: 16px;
			line-height: 1.25em;
			font-weight: 500;
			color: #333745;
			text-decoration: none;
		}
	</style>
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
    		<?php $this->load->view('includes/header'); ?>
			<main class="page-main">
				<div class="block">
					<div class="container">
						<div class="page-title">
							<div class="title">
								<div class="row">
									<div class="col-md-6"  style="display: inline-flex;">
										<h1>#<?=$order_info[0]->order_code?></h1>
										<?php 
											if ($order_rating) {
												$active = $order_rating->rating;
												
										?>
										<div class="rating" style="padding: 20px;">
											<?php 
												for ($i=1; $i < 6; $i++) { 
													$fill = '';
													if ($i <= $active) {
														$fill = 'fill';
													}
											?>
											<i class="icon icon-star <?=$fill?>"></i>
											<?php 
												}
											?>
										</div>
										<?php 
											}
										?>
									</div>
									<div class="col-md-6">
										<?php 
											if($order_info[0]->order_status == 1){
										?>
											<a href="javascript:cancel_order()" style="float: right;" class="btn btn-lg">Cancel Order</a>
										<?php 
											}else if($order_info[0]->order_status == 5){
										?>
											<a href="javascript:rating_order()" style="float: right;" class="btn btn-lg">Rate and Feedback</a>
										<?php 
											}
										?>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<input type="hidden" id="operation_id" value="<?=$order_info[0]->order_id?>" data-code="<?=$order_info[0]->order_code?>">
							<div class="col-md-9">
								<h2>View Item</h2>
								<div class="table-responsive">
									<table class="table table-bordered table-striped">
										<thead>
											<tr>
												<th scope="col"># </th>
												<th scope="col"></th>
												<th scope="col">Meal Pack </th>
												<th scope="col">Price</th>
											</tr>
										</thead>
										<tbody id="order_body">
											<?php 
												foreach ($order_meal as $key => $value) {
											?>
											<tr>
												<td><?=$key+1?></td>
												<td><span class="color"></span></td>
												<td style="color: #f82e56;"><b><?=$value->meal_name?></b> <span style="float: right; margin-right: 20px;">Rs.<?=$value->min_price?></span> </td>
												<td></td>
											</tr>			
											<?php 
													if ($value->items) {
													$item_count = count($value->items);
													$border = "";
													$final_item_price = "";
													// echo $item_count;
													foreach ($value->items as $key1 => $item) {
														if ($item_count == ($key1+1)) {
															$border = 'border-bottom: inset;';
															$final_item_price = "Rs.".$value->order_meal_price;
												}
											?>
											<tr>
												<td></td>
												<td></td>
												<td style="<?=$border?>"><?=$item->item_name?> <span style="float: right; margin-right: 20px;">Rs.<?=$item->item_price?></span> </td>
												<td><b><?=$final_item_price?></b></td>
											</tr>		
											<?php
													}
												}
												}
											?>
											<tr>
												<td></td>
												<td></td>
												<td></td>
												<td style="color: #f82e56; color: #f82e56; border-top: inset; border-bottom: double;"><b>Rs.<?=$order_info[0]->order_amount?></b></td>
											</tr>
										</tbody>
									</table>
									<!-- <pre> -->
										<?php 
											// print_r($order_info);
										?>
									<!-- </pre> -->
								</div>
							</div>
							<div class="col-md-3">
								<h2>Order Details</h2>
								<div class="">
									<ul class="category-list">
										<li class="details-tag">Order Code </a> <span style="float: right; font-weight: 100;"><?=$order_info[0]->order_code?></span></li>
										<li class="details-tag">Date <span style="float: right; font-weight: 100;"><?=$order_info[0]->order_date?></span></li>
										<li class="details-tag">Cook <span style="float: right; font-weight: 100;"><a href="javascript:open_cook(<?=$order_info[0]->phone?>)" style="padding: 0px; color: #f82e56;"><?=$order_info[0]->f_name.' '.$order_info[0]->l_name?></a></span></li>
										<li class="details-tag">Cook Phone <span style="float: right; font-weight: 100;"><?=$order_info[0]->phone?></span></li>
										<li class="details-tag">No. of Items <span style="float: right; font-weight: 100;"><?=$order_info[0]->items?></span></li>
										<?php 
											$status = "";
											$color = "";
											switch ($order_info[0]->order_status) {
												case '1':
													$status = 'Order Placed';
													$color = "color: blue;";
													break;
												case '2':
													$status = 'Cooking';
													$color = "color: yellow;";
													break;
												case '3':
													$status = 'Packed';
													$color = "color: orange;";
													break;
												case '4':
													$status = 'Ready to Pick';
													$color = "color: green;";
													break;
												case '5':
													$status = 'Delivered';
													$color = "color: grey;";
													break;
												case '6':
													$status = 'Cancelled';
													$color = "color: red;";
													break;
											}
										?>
										<li class="details-tag">Order Status <span style="float: right; font-weight: 100;" class="btn btn-sm"><?=$status?></span></li>
										<li class="details-tag">Amount <span style="float: right; font-weight: 100;">Rs.<?=$order_info[0]->order_amount?></span></li>
									</ul>
								</div>
								<div class="divider divider-lg"></div>
								<?php 
									if ($order_cancel) {
								?>
								<h2>Cancel Details</h2>
								<div class="">
									<ul class="category-list">
										<li class="details-tag">Wallet Refund </a> <span style="float: right; font-weight: 100;"><?=$order_cancel[0]->referance?></span></li>
										<?php 
											if ($order_cancel[0]->reason) {
										?>
										<li class="details-tag">Reason <span style="float: right; font-weight: 100;"><a href="javascript:open_reason()" style="padding: 0px;">View Details</a></span></li>
										<input type="hidden" id="view_reason" value="<?=$order_cancel[0]->reason?>">
										<?php 
											}
										?>
										<li class="details-tag">Date <span style="float: right; font-weight: 100;"><?=$order_cancel[0]->cancel_date?></span></li>
									</ul>
								</div>
								<?php 
									}
								?>
								<div class="divider divider-lg"></div>
								<?php 
									if ($order_rating) {
										$active = $order_rating->rating;		
								?>
								<h2>Rating and Feedback</h2>
								<ul class="category-list">
									<li class="details-tag">Reason <span style="float: right; font-weight: 100;">
										<div class="rating">
											<?php 
												for ($i=1; $i < 6; $i++) { 
													$fill = '';
													if ($i <= $active) {
														$fill = 'fill';
													}
											?>
											<i class="icon icon-star <?=$fill?>"></i>
											<?php 
												}
											?>
										</div></span>
									</li>
									<li class="details-tag">Feedback <span style="float: right; font-weight: 100; font-size: 14px; width: 100%; margin-top: 5px;"><?=$order_rating->feedback?></span></li>
								</ul>
								<?php 
									}
								?>
								<div class="divider divider-lg"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- Footer -->
    		<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- Cancel Modal -->
	<div class="modal fade" id="cancel-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title" id="order_cancel_name">Cancel Order</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="cancelForm">
								<input type="hidden" id="cancel_id" name="cancel_id" value="0">
								<div id="item_body">
									<ul>
										<li>when the cook udate the status to cooking, packed or ready to picked up, you can't cancel the order.</li>
										<li>The respective amount will be added to your wallet.</li>
										<li>Please provide your reason for cancelation, if you have any (optional).</li>
									</ul>
									<label>Reason for Cancelation (Optional)<span class="required"></span></label>
									<textarea class="form-control input-lg" name="reason" id="reason" cols="30" rows="4"></textarea>
									<div class="row">
										<div class="col-md-6">
											<button type="button" class="btn btn-invert" data-dismiss="modal" style="width: 100%;" aria-label="Close">No</button>
										</div>
										<div class="col-md-6">
											<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="cancel_btn">Yes! Cancel</button>
										</div>
									</div>

								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- rating Modal -->
	<div class="modal fade" id="rating-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title">Rating and Feedback</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="ratingForm">
								<input type="hidden" id="rating_id" name="rating_id" value="0">
								<input type="hidden" id="rating_number" name="rating_number" value="1">
								<div>
									<label>Rating<span class="required"></span></label>
									<div class="rating" style="padding: 20px;">
										<i class="icon icon-star str fill" id="star_1" onclick="select_star(1)"></i>
										<i class="icon icon-star str" id="star_2" onclick="select_star(2)"></i>
										<i class="icon icon-star str" id="star_3" onclick="select_star(3)"></i>
										<i class="icon icon-star str" id="star_4" onclick="select_star(4)"></i>
										<i class="icon icon-star str" id="star_5" onclick="select_star(5)"></i>
									</div>
									<label>Feedback<span class="required"></span></label>
									<textarea class="form-control input-lg" name="feedback" id="feedback" cols="30" rows="4"></textarea>
									<div class="row">
										<div class="col-md-6">
											<button type="button" class="btn btn-invert" data-dismiss="modal" style="width: 100%;" aria-label="Close">No</button>
										</div>
										<div class="col-md-6">
											<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="cancel_btn">Yes! Cancel</button>
										</div>
									</div>

								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		function getOrder(){  
			// alert('hi');
			let status = '';
			let order_body = '';
			$('#order_body').empty();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>get_order_ajax',
				data: 'search=3845784',
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						for (let i = 0; i < res.message.length; i++) {
							switch (res.message[i]['order_status']) {
								case '1':
									status = 'Order Placed';
									break;
								case '2':
									status = 'Cooking';
									break;
								case '3':
									status = 'Packed';
									break;
								case '4':
									status = 'Ready to Pick';
									break;
								case '5':
									status = 'Delivered';
									break;
								case '6':
									status = 'Cancelled';
									break;
							}
							// alert(status);
							order_body += '<tr>'+
												'<td>'+(i+1)+'</td>'+
												'<td><b>175525</b> <a href="javascript:open_order('+res.message[i]['order_id']+')" class="pull-right">View Details</a></td>'+
												'<td>'+res.message[i]['order_date']+'</td>'+
												'<td><span class="color">Rs.'+res.message[i]['order_amount']+'</span></td>'+
												'<td>'+res.message[i]['f_name']+' '+res.message[i]['l_name']+'</td>'+
												'<td><a href="#" class="btn btn-sm">'+status+'</a></td>'+
											'</tr>';
						}
						$('#order_body').append(order_body);
					}
				},
				error: function (result){  

				}
			});
		}
	</script>
	<script>
		function cancel_order(){  
			let id = $('#operation_id').val();
			$('#cancel_id').val(id);
			$('#order_cancel_name').html('Cancel Order <span style="color: #f82e56;">#'+$('#operation_id').attr('data-code')+'</span>');
			$('#cancel-modal').modal('show');
		}
		$('#cancelForm').on('submit', function(e){  
			e.preventDefault();
			$.ajax({
				type: "POST",
				url: "<?=base_url()?>cancel_order",
				data: $('#cancelForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
						$('#cancel-modal').modal('hide');
						if (res.status == 'success') {
							toastr["success"](res.message);
							setTimeout(function() { 
								window.location.reload();
							}, 2000);	
						}else{
							toastr["error"](res.message);

						}
				},
				error: function (result){  

				}
			});
		});
	</script>
	<script>
		function open_reason(){  
			alert($('#view_reason').val());
		}
		function open_cook(num){  
			alert('Dial to pickup'+num);
		}
	</script>
	<script>
		function rating_order(){  
			let id = $('#operation_id').val();
			$('#rating_id').val(id);
			$('#rating-modal').modal('show');
		}

		function select_star(num){
			// alert(num)
			$('.str').removeClass('fill');
			$('#rating_number').val(num);
			for (let i = 1; i <= num; i++) {
				$('#star_'+i).addClass('fill');
			}
		}

		$('#ratingForm').on('submit', function(e){  
			e.preventDefault();
			$.ajax({
				type: "POST",
				url: "<?=base_url()?>rating_feedback_ajax",
				data: $('#ratingForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
						$('#cancel-modal').modal('hide');
						if (res.status == 'success') {
							toastr["success"](res.message);
							// setTimeout(function() { 
								window.location.reload();
							// }, 2000);	
						}else{
							toastr["error"](res.message);

						}
				},
				error: function (result){  

				}
			});
		});
	</script>

</body>

</html>