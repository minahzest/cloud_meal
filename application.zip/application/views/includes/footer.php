<footer style="width: 100vw;margin-left: -50vw;left: 50%;position: relative;padding: 50px; border-top: 1px solid #e5e5e5;margin-top: 50px;">
	<div class="row">
		<div class="col-lg-3 col-sm-3 col-md-3">
			<a href="index.html" title="Logo"><img src="<?=base_url()?>assets/images/logo.png" alt="Logo" alt class="img-responsive"></a>
		</div>
		<div class="col-lg-3 col-sm-3 col-md-3" style="padding: 10px;">
			<div class="title">
				<h4>MY ACCOUNT</h4>
			</div>
			<div>
				<ul>
					<li><a href="account-create.html">My account</a></li>
					<li><a href="<?=base_url()?>business">Business</a></li>
					<li><a href="<?=base_url()?>meal-pack">Meal Packs</a></li>
					<li><a href="<?=base_url()?>constact-us">Contact Us</a></li>
					<li><a href="search.html">Search Terms</a></li>
				</ul>
			</div>
		</div>
		<div class="col-lg-3 col-sm-3 col-md-3" style="padding: 10px;">
			<!-- <div class="title">
				<h4>CUSTOMER CARE</h4>
			</div>
			<div>
				<ul>
					<li><a href="blog.html">Our Blog</a></li>
					<li><a href="search.html">Search Terms</a></li>
					<li><a href="contact.html">Contact Us</a></li>
					<li><a href="faq.html">Customer Service</a></li>
					<li><a href="about.html">Privacy Policy</a></li>
				</ul>
			</div> -->
		</div>
		<div class="col-lg-3 col-sm-3 col-md-3" style="padding: 10px;">
			<div class="title">
				<h4>CONTACT US</h4>
			</div>
			<div>
				<ul>
					<li><i class="icon icon-phone"></i>+01 234 567 89</li>
					<li><i class="icon icon-close-envelope"></i><a href="mailto:support@seiko.com">support@cloudneal.com</a></li>
					<li><i class="icon icon-clock"></i>8:00 - 19:00, Monday - Saturday</li>
				</ul>
			</div>
		</div>	
	</div>
</footer>