<header class="page-header variant-2 sticky always" style="width: 100vw; margin-left: -50vw; left: 50%; ">
	<div class="navbar">
		<div class="container" style="padding: 0px 50px 0px 50px;">
			<div style="display: inline-block;">
				<ul class="nav">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li><a href="<?=base_url()?>meal-pack" title="">Meal Packs</a></li>
					<!-- <li><a href="<?=base_url()?>">About Us</a></li> -->
					<li><a href="<?=base_url()?>contact-us">Contact Us</a></li>
					<li><a href="<?php if($this->session->userdata('user_logged_in')==null){ echo base_url()."business"; }else{ echo base_url()."chef-account"; }?>">Business</a></li>

				</ul>
			</div>
			<div class="header-link  header-cart">
				<a href="<?=base_url()?>cart"> <i class="icon icon-cart"></i> <span class="badge" id="cart_count"><?=count($this->cart->contents())?></span> </a>
			</div>
			<div class="header-links">
				<div class="header-link dropdown-link header-account">
				<?php 
					if($this->session->userdata('cust_logged_in')!=null){ 
				?>
					<a href="<?=base_url()?>wallet">
						<input type="hidden" name="wallet_balance" id="wallet_balance" value="<?=$this->session->userdata('wallet_balance')?>">
						<i class="icon icon-money"></i> Rs.<?=$this->session->userdata('wallet_balance')?>
					</a>
				<?php } ?>
					<a href="<?php if($this->session->userdata('cust_logged_in')==null){ echo base_url()."login"; }else{ echo base_url()."account"; }?>"><i class="icon icon-user"></i></a>
				</div>
			</div>
			<div class="header-logo">
				<a href="<?=base_url()?>" title="Logo"><img src="<?=base_url()?>assets/images/logo.png" alt="Logo" /></a>
			</div>
		</div>
	</div>
</header>