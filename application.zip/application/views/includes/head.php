<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>CloudMeal | Online Food</title>
<meta name="author" content="BigSteps">
<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
<link rel="shortcut icon" href="<?=base_url()?>assets/images/logo.png"> 
<!-- Vendor -->
<link href="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
<!-- Custom -->
<link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">

<!-- Icon Font -->
<link href="<?=base_url()?>assets/fonts/icomoon-reg/style.css" rel="stylesheet">

<!-- Google Font -->
<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

<!--toastr-->
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">