<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Head -->
		<?php $this->load->view('includes/head'); ?>
	<!-- /Head -->
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
			<!-- Header -->
    			<?php $this->load->view('includes/header'); ?>
			<!-- /Header -->
			<!-- Page Content -->
			<main class="page-main">
				<div class="block">
					<div class="container">
						<ul class="breadcrumbs">
							<li><a href="index.html"><i class="icon icon-home"></i></a></li>
							<li>/<span>Business</span></li>
						</ul>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<!-- Wellcome text -->
						<div class="text-center bottom-space">
							<h1 class="size-lg no-padding">Start your business with <span class="theme-color">cloudMeal</span></h1>
							<div class="line-divider"></div>
							<p class="custom-color-alt">Become a chef at <span class="theme-color">cloudMeal</span> and seliing your cuizine.
								<!-- <br> Vim ei oblique tacimates, usu cu iudico graeco. Graeci eripuit inimicus vel eu, eu mel unum laoreet splendide, cu integre apeirian has. -->
							</p>
						</div>
						<!-- /Wellcome text -->
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="row row-eq-height">
							<div class="col-sm-6">
								<div class="form-card">
									<h4>Login</h4>
									<p>By login with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
									<div>
										<!-- <a href="account-create.html" class="btn btn-lg">
											<i class="icon icon-user"></i><span>Create An Account</span>
										</a> -->
										<img src="<?=base_url()?>assets/images/12892962_5098293.jpg" width="100%" style="border-radius: 10px;">
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-card" style=";">
									<!-- <h4>Registered Customers</h4>
									<p>If you have an account with us, please log in.</p> -->
									<form class="loginForm" id="loginForm" data-toggle="validator">
										<label>E-mail<span class="required">*</span></label>
										<input type="email" class="form-control input-lg" name="email" id="modalloginemail" placeholder="Email Address" data-error="Please enter a valid email address.">
										<label>Password<span class="required">*</span></label>
										<input type="password" class="form-control input-lg" placeholder="Password" name="password" data-required-error="Password is Required" required>
										<div>
											<button class="btn btn-lg" type="submit">Login</button>
											<span class="required-text" style="float: right;">* Required Fields</span>
										</div>
											<div class="back"><a href="#">Forgot Your Password?</a></div>
									</form>
									<div>
										<!-- sdfhsdjhk -->
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<!-- Wellcome text -->
						<div class="text-center bottom-space">
							<h1 class="size-lg no-padding">Become a <span class="theme-color">cloudMeal</span> chef</h1>
							<div class="line-divider"></div>
							<p class="custom-color-alt">Register as a chef and start selling your specialized cuzine at <span class="theme-color">cloudMeal</span>.
								<!-- <br> Vim ei oblique tacimates, usu cu iudico graeco. Graeci eripuit inimicus vel eu, eu mel unum laoreet splendide, cu integre apeirian has. -->
							</p>
						</div>
						<!-- /Wellcome text -->
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="row row-eq-height">
							<div class="col-sm-6">
								<div class="form-card">
									<h4>Register as Chef</h4>
									<p>By register with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
									<div>
										<!-- <a href="account-create.html" class="btn btn-lg">
											<i class="icon icon-user"></i><span>Create An Account</span>
										</a> -->
										<img src="<?=base_url()?>assets/images/20602936_6333040.jpg" width="100%" style="border-radius: 10px;">
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<!-- <div class="category-title title-border"><a href="#">CLOTHING<span class="menu-label-alt">NEW</span></a></div> -->
								<div class="form-card">
									<h4>Register as Chef</h4>
									<p>By register with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
									<div>
										<ul class="category-links column-count-2">
											
										</ul>
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<!-- Wellcome text -->
						<div class="text-center bottom-space">
							<h1 class="size-lg no-padding">What <span class="theme-color">cloudMeal</span> offer</h1>
							<div class="line-divider"></div>
							<p class="custom-color-alt">Register as a chef and start selling your specialized cuzine at <span class="theme-color">cloudMeal</span>.
								<!-- <br> Vim ei oblique tacimates, usu cu iudico graeco. Graeci eripuit inimicus vel eu, eu mel unum laoreet splendide, cu integre apeirian has. -->
							</p>
						</div>
						<!-- /Wellcome text -->
					</div>
				</div>
				<div class="block" style="margin-top: 20px;">
					<div class="container">
						<div class="row row-eq-height">
							<div class="col-md-4">
								<div class="blog-post">
									<div class="blog-photo">
										<a href="#"><img src="<?=base_url()?>assets/images/blog/blog-single-post.jpg" alt="Blog Single"></a>
									</div>
									<div class="blog-content">
										<h2 class="blog-title"><a href="<?=base_url()?>login">Cook if you wish</a></h2>
										<div class="blog-meta">
											<div class="pull-left">
												<span>Login and start selling</span>
											</div>
										</div>
										<!-- <div class="blog-text">
											<p>Aspernatur eos debitis vero quas quis itaque omnis nemo repellat accusamus expedita id ex, provident velit illo dolorum ducimus?</p>
										</div> -->
										<a href="<?=base_url()?>business" class="btn">Sign in</a>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="blog-post">
									<div class="blog-photo">
										<!-- <a href="#"><img src="images/blog/blog-single-post.jpg" alt="Blog Single"></a> -->
									</div>
									<div class="blog-content">
										<h2 class="blog-title"><a href="<?=base_url()?>meal-pack">Custom Orders</a></h2>
										<div class="blog-meta">
											<div class="pull-left">
												<span>Customize your meal pack</span>
											</div>
										</div>
										<!-- <div class="blog-text">
											<p>Aspernatur eos debitis vero quas quis itaque omnis nemo repellat accusamus expedita id ex, provident velit illo dolorum ducimus?</p>
										</div> -->
										<a href="<?=base_url()?>meal-pack" class="btn">Explore Meals</a>
									</div>
								</div>
							</div>
							<div class="col-md-4">
								<div class="blog-post">
									<div class="blog-photo">
										<!-- <a href="#"><img src="images/blog/blog-single-post.jpg" alt="Blog Single"></a> -->
									</div>
									<div class="blog-content">
										<h2 class="blog-title"><a href="#">Register</a></h2>
										<div class="blog-meta">
											<div class="pull-left">
												<span>Regsiter as chef/cook</span>
											</div>
										</div>
										<!-- <div class="blog-text">
											<p>Aspernatur eos debitis vero quas quis itaque omnis nemo repellat accusamus expedita id ex, provident velit illo dolorum ducimus?</p>
										</div> -->
										<a href="<?=base_url()?>register" class="btn">register</a>
									</div>
								</div>
							</div>
						</div>
						<!-- <pre> -->
							<?php 
								// print_r($this->session->userdata());
							?>
						<!-- </pre> -->
				</div>
			</main>
			
			<!-- Footer -->
    		<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		$('#loginForm').on('submit', function (e) {
			// alert('hi');
			if (!(e.isDefaultPrevented())) {
				e.preventDefault();
				$.ajax({
					type: "POST",
					url: "<?=base_url()?>chef-sign-in",
					data: $('#loginForm').serialize(),
					success: function(result) {
						var responsedata = $.parseJSON(result);
						if(responsedata.status=='success'){
							window.location.href = "<?=base_url()?>"+responsedata.message;
						}else{
							document.getElementById('loginForm').reset(); 
							$('#loginForm').find("input").val("");
							toastr["error"](responsedata.message);
						}
					},
					error: function(result) {
						toastr["error"](result);
					}
				});
			}
		});
	</script>
</body>

</html>