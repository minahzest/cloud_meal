<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CloudMeal | Chef Panel</title>
	<meta name="author" content="BigSteps">
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
	<link rel="shortcut icon" href="<?=base_url()?>assets/images/logo.png"> 
	<!-- Vendor -->
	<link href="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/slick/slick.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/swiper/swiper.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/nouislider/nouislider.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">

	<!-- Custom -->
	<link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/megamenu.css" rel="stylesheet">

	<!-- Color Schemes -->
	<!-- your style-color.css here  -->


	<!-- Icon Font -->
	<link href="<?=base_url()?>assets/fonts/icomoon-reg/style.css" rel="stylesheet">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

	<style>
		.active-nav{
			width: 100%;
			background-color: #494e62;
			left: 0;
			background-color: #494e62;
			left: -4px;
			border-right: 4px solid #f82e56;
		}
	</style>
</head>

<body class="fullwidth open-panel">
	<div id="wrapper">
		<!-- Page -->
		<div class="page-wrapper">
			<!-- Sidebar -->
			<div class="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li class="active-nav"> <a href="<?=base_url()?>chef-account" class="active">HOME</a> </li>
					<li> <a href="<?=base_url()?>chef-order">Orders</a> </li>
					<li> <a href="<?=base_url()?>chef-meals">My Meals</a> </li>
					<li> <a href="<?=base_url()?>chef-logout">LOGOUT</a> </li>
				</ul>
			</div>
			<!-- /Sidebar -->
			<!--header-->
			<header class="page-header variant-1 fullboxed sticky smart">
				<div class="navbar" style="margin: 0 0 0 0;">
					<div class="container">
						<div class="header-logo">
							<span style="font-size: 24px;font-family: 'Oswald', sans-serif; font-weight: 400; text-transform: uppercase; padding: 0 0 2px; margin: 0 0 30px 0; color: #333745;">Hi, <?=$this->session->userdata('user_logged_in')['user_name']?></span>
						</div>
					</div>
				</div>
			</header>
			<!--header end-->
			<!-- Page Content -->
			<main class="page-main">
				<div class="block fullwidth full-nopad small-margin">
					<div class="container">
						<!-- Main Slider -->
						<div class="mainSlider" data-thumb="true" data-thumb-width="230" data-thumb-height="100">
							<div class="sliderLoader">Loading...</div>
							<!-- Slider main container -->
							
						</div>
						<!-- /Main Slider -->
					</div>
				</div>

				<div class="block" style="padding: 35px; margin-top: 50px;">
					<div class="container">
						<div class="row">
							<div class="col-sm-12 col-md-12 col-lg-12">
								<div class="title">
									<!-- <h2>Advantages</h2> -->
								</div>
								<!-- <pre> -->
									<?php 
										// print_r($orders);
										// print_r($meals);
										// print_r($delivered);
										// print_r($rating);
												
									?>
								<!-- </pre> -->
								<div class="">
									<div class="row">
										<div class="col-sm-6 col-md-3">
											<div class="box-left-icon">
												<div class="box-icon rounded"><i class="icon icon-cart"></i></div>
												<div class="box-text">
													<div class="title">Number of Order</div>
													<?=$orders?>
												</div>
											</div>
										</div>
										<div class="col-sm-6 col-md-3">
											<div class="box-left-icon">
												<div class="box-icon rounded"><i class="icon icon-truck"></i></div>
												<div class="box-text">
													<div class="title">New Order</div>
													<?=$new_order?> Packages
												</div>
											</div>
										</div>
										<div class="col-sm-6 col-md-3">
											<div class="box-left-icon">
												<div class="box-icon rounded"><i class="icon icon-gift"></i></div>
												<div class="box-text">
													<div class="title">Number of Meals</div>
													<?=$meals?> Meal Packs
												</div>
											</div>
										</div>
										<div class="col-sm-6 col-md-3">
											<div class="box-left-icon">
												<div class="box-icon rounded"><i class="icon icon-star"></i></div>
												<div class="box-text">
													<div class="title">Rating</div>
													<?=$rating?> Star
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</main>
			<!-- /Page Content -->
			<!-- Footer -->
			<!-- <footer class="page-footer variant1" style="bottom: 0; position: absolute;">
				<div class="container">
					<div class="after-footer">
						<div class="footer-copyright text-center"> © 2016 Demo Store. All Rights Reserved. </div>
					</div>
				</div>
			</footer> -->
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/swiper/swiper.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/slick/slick.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/parallax/parallax.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/isotope/isotope.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/countdown/jquery.countdown.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/nouislider/nouislider.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/ez-plus/jquery.ez-plus.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/tocca/tocca.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/scrollLock/jquery-scrollLock.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/darktooltip/dist/jquery.darktooltip.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/instafeed/instafeed.min.js"></script>
	<script src="<?=base_url()?>assets/js/megamenu.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>

</body>

</html>