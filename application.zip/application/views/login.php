<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('includes/head'); ?>
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
    		<?php $this->load->view('includes/header'); ?>
			<main class="page-main">
				<div class="block">
					<div class="container">
						<div class="text-center bottom-space">
							<h1 class="size-lg no-padding">Start buying from <span class="theme-color">cloudMeal</span></h1>
							<div class="line-divider"></div>
							<p class="custom-color-alt">Become a user at <span class="theme-color">cloudMeal</span> and start buying cuzines.
							</p>
						</div>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="row row-eq-height">
							<div class="col-sm-6">
								<div class="form-card">
									<h4>Login</h4>
									<p>By login with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
									<div>
										<img src="<?=base_url()?>assets/images/12892962_5098293.jpg" width="100%" style="border-radius: 10px;">
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-card" style="">
									<form class="loginForm" id="loginForm" data-toggle="validator">
										<label>E-mail<span class="required">*</span></label>
										<input type="email" class="form-control input-lg" name="email" id="modalloginemail" placeholder="Email Address" data-error="Please enter a valid email address.">
										<label>Password<span class="required">*</span></label>
										<input type="password" class="form-control input-lg" placeholder="Password" name="password" data-required-error="Password is Required" required>
										<div>
											<button class="btn btn-lg" type="submit">Login</button>
											<span class="required-text" style="float: right;">* Required Fields</span>
										</div>
											<div class="back"><a href="#">Forgot Your Password?</a></div>
									</form>
									<div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="text-center bottom-space">
							<h1 class="size-lg no-padding">Become a <span class="theme-color">cloudMeal</span> user</h1>
							<div class="line-divider"></div>
							<p class="custom-color-alt">Register a consumer and start ordering your desired meal from <span class="theme-color">cloudMeal</span>.
							</p>
						</div>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="row row-eq-height">
							<div class="col-sm-6">
								<div class="form-card">
									<h4>Register as Consumer</h4>
									<p>By login with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
									<div>
										<img src="<?=base_url()?>assets/images/20602936_6333040.jpg" width="100%" style="border-radius: 10px;">
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-card" style="">
									<form id="signup-form">
										<label>First Name<span class="required">*</span></label>
										<input class="form-control" type="text" name="fname" placeholder="First Name" pattern="^[a-zA-Z. ]+$" data-minlength="3" data-pattern-error="Invalid first name" data-error="Minimum of 3 characters" data-required-error="First name is required" required>
										<label>Last Name<span class="required">*</span></label>
										<input class="form-control" type="text" name="lname" placeholder="Last Name" pattern="^[a-zA-Z. ]+$" data-minlength="3" data-pattern-error="Invalid last name" data-error="Minimum of 3 characters" data-required-error="Last name is required" required>
										<label>Mobile Number<span class="required">*</span></label>
										<input class="form-control" type="number" name="mobile" placeholder="Mobile Number" data-minlength="9" data-error="Mobile number is invalid" data-required-error="Mobile number is required" required>
										<label>E-mail<span class="required">*</span></label>
										<input class="form-control" type="email" name="email" placeholder="Email Address" data-error="Please enter a valid email address." data-remote="<?=base_url()?>checkfields?data=email&input=email&table=customers" data-remote-error="Email address already exist" required>
										<label>Password<span class="required">*</span></label>
										<input type="password" placeholder="Password" class="form-control" data-minlength="6" class="form-control" name="password" id="password" data-error="Minimum of 6 characters" data-required-error="Password is Required" required>
										<label>Confirm Password<span class="required">*</span></label>
										<input type="password" class="form-control" id="pass-match" data-match="#password" data-match-error="Password doesn't match" placeholder="Confirm password" data-required-error="Confirm Password is Required" required>
										<div>
											<button class="btn btn-lg" type="submit">Register</button>
											<span class="required-text" style="float: right;">* Required Fields</span>
										</div>
									</form>
									<div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</main>
    		<?php $this->load->view('includes/footer'); ?>
		</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script type="text/javascript">

	$('#loginForm').on('submit', function (e) {
		// alert('hi');
        if (!(e.isDefaultPrevented())) {
            e.preventDefault();
	        $.ajax({
	            type: "POST",
	            url: "<?=base_url()?>sign-in",
	            data: $('#loginForm').serialize(),
	            success: function(result) {
	                var responsedata = $.parseJSON(result);
	                if(responsedata.status=='success'){
	                    window.location.href = "<?=base_url()?>"+responsedata.message;
	                }else{
	                    document.getElementById('loginForm').reset(); 
	                    $('#loginForm').find("input").val("");
	                    toastr["error"](responsedata.message);
	                }
	            },
	            error: function(result) {
	                toastr["error"](result);
	            }
	        });
	    }
    });


	$('#pass-match').on('keyup', function(e){
		// alert($('#password').val()+' '+this.value);
		if($('#password').val() == this.value){
			// alert('match');
			this.style.border = '1px solid #e8e8e8';
		}else{
			// alert('not match');
			this.style.border = '1px solid red';
		}
	});

    $('#signup-form').on('submit', function (e) {
		e.preventDefault()
    	// alert($('#signup-form').serialize());
        if ($('#password').val() != $('#pass-match').val()) {
			toastr["error"]("Password doesn't match")
        } else {
			$.ajax({
				type: "POST",
				url: "<?=base_url()?>user-signup",
				data: $('#signup-form').serialize(),
				success: function(result) {
					var responsedata = $.parseJSON(result);
					if(responsedata.status=='success'){
						document.getElementById('signup-form').reset(); 
						$('#signup-form').find("input").val("");
						$('#signup-form').find("textarea").val("");
						// $('#signup-form').validator('destroy').validator();
						// $('.selectpicker').selectpicker('refresh');
						toastr["success"](responsedata.message)
					}else{
						toastr["error"](responsedata.message)
					}
				},
				error: function(result) {
					toastr["error"]('Error :'+result)
				}
			});
        }
    });
</script>

</body>

</html>