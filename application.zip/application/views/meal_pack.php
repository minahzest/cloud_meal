<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Head -->
		<?php $this->load->view('includes/head'); ?>
	<!-- /Head -->

	<style>
    .product-card {
      max-width: 300px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      margin: 10px;
    }

    .product-image {
      width: 100%;
      height: 200px;
      background-size: cover;
    }

    .product-details {
      padding: 10px;
    }

    .product-title {
      font-size: 18px;
      font-weight: bold;
      margin-bottom: 8px;
	  font-family: 'Oswald', sans-serif;
    }

    .product-price {
      font-size: 16px;
      color: #f82e56;
      margin-bottom: 12px;
    }

    .product-description {
      font-size: 14px;
      color: #555;
      line-height: 1.4;
    }

    .buy-button {
      display: block;
      width: 100%;
      padding: 10px;
      background-color: #3498db;
      color: #fff;
      text-align: center;
      text-decoration: none;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .buy-button:hover {
      background-color: #2980b9;
    }
	.prod-image-view{
		height: 300px;
		width: auto;
		background-size: cover;
		border-radius: 10px;
	}
  </style>
  <style>
	#flip, #flip1, #flip2{
		cursor: pointer;
	}

	#panel, #flip {
	  padding: 15px;
	  text-align: center;
	  background-color: #fff;
	  /*border: solid 1px #c3c3c3;*/
      
	}

	#panel {
	  padding: 15px;
	  display: none;
	  background-color: #fff;
      /* border-radius: 0px 0px 8px 8px; */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-top: 1px solid #e5e5e5;
      border-bottom: 1px solid #e5e5e5;
	}
	#panel1, #flip1 {
	  padding: 15px;
	  text-align: center;
	  background-color: #fff;
	  /*background-color: #e5eecc;*/
	  /*border: solid 1px #c3c3c3;*/
	}

	#panel1 {
	  padding: 15px;
	  display: none;
	  background-color: #fff;
      /* border-radius: 0px 0px 8px 8px; */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-top: 1px solid #e5e5e5;
      border-bottom: 1px solid #e5e5e5;
	}

	
	#panel2, #flip2 {
	  padding: 15px;
	  text-align: center;
	  background-color: #fff;
	  /*background-color: #e5eecc;*/
	  /*border: solid 1px #c3c3c3;*/
	}

	#panel2 {
	  padding: 15px;
	  display: none;
	  background-color: #fff;
      /* border-radius: 0px 0px 8px 8px; */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-top: 1px solid #e5e5e5;
      border-bottom: 1px solid #e5e5e5;
	}
  </style>
  <style>
	.filter-btn{
		border: 1px solid #e5e5e5;
		padding: 10px 20px 10px 20px;
		border-radius: 20px;
		font-weight: 400;
		display: block;
		cursor: pointer;
		transition: .5s;

	}
	.filter-btn-active{
		border: 1px solid #f82e56;
		color: #f82e56;
		transition: .5s;
		font-weight: 600;
	}
	.box-test {
		background-color: #ffffff;
		padding: 0px 0px 10px;
		margin-bottom: 0px;
	}
  </style>
  <style>
	.modal-dialog:after, .modal-dialog:before {
		content: '';
		height: 4px;
		background: #333745;
		position: absolute;
		z-index: 1;
		left: 0;
		width: 100%;
	}
  </style>
</head>

<body class="boxed" onload="get_meal()">
	<div id="wrapper">
		<div class="page-wrapper">
			<!-- Header -->
    		<?php $this->load->view('includes/header'); ?>
			<!-- /Header -->
			
			<div class="row" style="margin-top: 20px;">
				<div class="col-lg-3 col-md-6 text-left" style="text-align: left;">
					<!-- This is left side of the page -->
					<div id="flip"><span style="font-family: 'Oswald', sans-serif; font-weight: 600;"> Categories </span></div>
					<input type="hidden" id="cat_selected" name="cat_selected" value="0">
					<div id="panel">
						<div class="grid-box">
							<?php
								foreach ($cat as $key => $value) {
							?>
							<div class="box-test">
								<span class="filter-btn" dat-id="<?=$value->category_id?>"><?=$value->category?></span>
							</div>
							<?php
								}
							?>
						</div>
					</div>

					<div id="flip1"><span style="font-family: 'Oswald', sans-serif; font-weight: 600;"> Date Filter </span></div>
					<div id="panel1">
						<input type="date" class="form-control" name="filter_date" id="filter_date">
					</div>

					<div id="flip2"><span style="font-family: 'Oswald', sans-serif; font-weight: 600;"> City Filter </span></div>
					<div id="panel2">
						<select class="form-control" name="city_filter" id="city_filter">
							<option value="0" selected>All</option>
							<?php
								foreach ($cities as $key => $city) {
							?>
							<option value="<?=$city->city_id?>"><?=$city->city_name?></option>
							<?php 
								}
							?>
						</select>
					</div>

					<!-- <pre> -->
						<?php 
							// print_r($cities);
						?>
					<!-- </pre> -->

				</div>
				<div class="col-lg-9 col-md-6" style="text-align: -webkit-center;">
					<!-- this is right side of the page -->
					<div class="row" id="card_body">
					<div class="col-lg-4 col-md-4">
							<div class="product-card">
								<div class="product-image" style="background-image: url('product3.jpg');"></div>
								<div class="product-details">
								<div class="product-title">Product 1</div>
								<div class="product-price">Rs.100.00</div>
								<div class="product-description">Chef name.</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4">
							<div class="product-card">
								<div class="product-image" style="background-image: url('product3.jpg');"></div>
								<div class="product-details">
								<div class="product-title">Product 2</div>
								<div class="product-price">Rs.100.00</div>
								<div class="product-description">Chef name.</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4">
							<div class="product-card">
								<div class="product-image" style="background-image: url('product3.jpg');"></div>
								<div class="product-details">
								<div class="product-title">Product 3</div>
								<div class="product-price">Rs.100.00</div>
								<div class="product-description">Chef name.</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4">
							<div class="product-card">
								<div class="product-image" style="background-image: url('product3.jpg');"></div>
								<div class="product-details">
								<div class="product-title">Product 4</div>
								<div class="product-price">Rs.100.00</div>
								<div class="product-description">Chef name.</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4">
							<div class="product-card">
								<div class="product-image" style="background-image: url('product3.jpg');"></div>
								<div class="product-details">
								<div class="product-title">Product 5</div>
								<div class="product-price">Rs.100.00</div>
								<div class="product-description">Chef name.</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 col-md-4">
							<div class="product-card">
								<div class="product-image" style="background-image: url('product3.jpg');"></div>
								<div class="product-details">
								<div class="product-title">Product 6</div>
								<div class="product-price">Rs.100.00</div>
								<div class="product-description">Chef name.</div>
								</div>
							</div>
						</div>

					</div>
				</div>
			</div>
			

			<!-- Footer -->
    		<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
		<!-- Modal -->
		<div class="modal fade" id="mealModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header">
						<h2 class="modal-title" id="meal_name">Modal Title</h2>
					</div>
					<div class="modal-body">
						<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
							<div class="col-lg-6 col-md-6">
								<div class="prod-image-view" id="meal_image" style="background-image: url(http://localhost/cloud_meal/assets/images/1537403022514-w2880-b8.jpg);"></div>
							</div>
							<div class="col-lg-6 col-md-6">
								<form action="#" id="cart-form">
									<h2 id="meal_price"></h2>
									<p>customize your meal before add to cart by ticking and unticking the items from this meal pack.</p>
									<input type="hidden" name="cart_meal_id" id="cart_meal_id" value="0">
									<input type="hidden" name="final_price" id="final_price" value="0">
									<input type="hidden" name="final_qty" id="final_qty" value="0">
									<input type="hidden" name="min_price" id="min_price" value="0">
									<input type="hidden" name="meal_item_selected" id="meal_item_selected" value="0">
									<div id="item_body">
										
									</div>
									<label for="meal_qty">Qty</label>
									<select class="form-control" name="meal_qty" id="meal_qty">
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
									</select>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<div class="row">
							<div class="col-lg-6 col-md-6">

							</div>
							<div class="col-lg-6 col-md-6">
								<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="order_tbn"></button>
							</div>
						</div>
					</div>
					</form>
				</div>
			</div>
		</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script type="text/javascript">

	function get_meal(){
		let cat = $('#cat_selected').val();;
		let filter_date = $('#filter_date').val();;
		let filter_city = $('#city_filter').val();;
		
		$('#card_body').empty();
		// alert('hi');
		let meal_body = '';
		$('#card_body').empty();
		
		$.ajax({
			type: "POST",
			url: "<?=base_url()?>get_meal",
			data: "cat="+cat+'&filter_date='+filter_date+'&filter_city='+filter_city,
			success: function(result){  
				var res = $.parseJSON(result);
				console.log(res.meals[0]['category']);
				res.meals.forEach(element => {
					console.log(element);
					meal_body += '<div class="col-lg-4 col-md-4" onclick="open_meal('+element.user_meal_id+')" style="cursor: pointer;">'+
							'<div class="product-card">'+
								'<div class="product-image" id="image_id_'+element.user_meal_id+'" style="background-image: url(<?=PHOTO_DOMAIN?>'+element.meal_image+');"></div>'+
								'<div class="product-details">'+
								'<div class="product-title" id="meal_name_'+element.user_meal_id+'">'+element.meal_name+'</div>'+
								'<div class="product-price" id="meal_price_'+element.user_meal_id+'" dat-price="'+element.max_price+'">Rs.'+element.max_price+'</div>'+
								'<input type="hidden" id="meal_min_price_'+element.user_meal_id+'" value="'+element.min_price+'"></input>'+
								'<div class="product-description">'+element.f_name+'</div>'+
								'</div>'+
							'</div>'+
						'</div>';
				});
				console.log(meal_body);
				$('#card_body').append(meal_body);


			},
			error: function(result){

			}
		});
	}
</script>
<script> 
$(document).ready(function(){
  $("#flip").click(function(){
    $("#panel").slideToggle("slow");
  });
  $("#flip1").click(function(){
    $("#panel1").slideToggle("slow");
  });
  $("#flip2").click(function(){
    $("#panel2").slideToggle("slow");
  });
});

</script>
<script>
	$('.filter-btn').on('click', function(e){
		console.log($(this).hasClass('filter-btn-active'));
		if ($(this).hasClass('filter-btn-active')) {
			$(this).removeClass('filter-btn-active');
			$('#cat_selected').val(0);
		}else{
			$('.filter-btn').removeClass('filter-btn-active');
			$(this).addClass('filter-btn-active');
			$('#cat_selected').val($(this).attr('dat-id'));
		}
		get_meal();
	});
</script>
<script>
	$('#filter_date, #city_filter').on('change', function (e){  
		get_meal();
	});
</script>
<script>
	let item_prices = [];
	let item_id = [];
	let min_prices = 0;
	function open_meal(id){
		$('#meal_name').text($('#meal_name_'+id).text());
		$('#meal_price').text($('#meal_price_'+id).text());
		$('#order_tbn').text('Add 1 to cart - '+$('#meal_price_'+id).text());

		$('#cart_meal_id').val(id);
		$('#final_price').val($('#meal_price_'+id).attr('dat-price'));
		$('#min_price').val($('#meal_min_price_'+id).val());
		$('#final_qty').val(1);
		
		let meal_image = $('#image_id_'+id).css('background-image');
		$('#meal_image').css('background-image', meal_image);

		$('#item_body').empty();
		let item_append = '';
		$.ajax({
			type: 'POST',
			url: '<?=base_url()?>get_mealpack_items_ajax',
			data: 'id='+id,
			success: function(result){  
				let res = $.parseJSON(result);
				for (let i = 0; i < res.meal_item.length; i++){
					item_prices[res.meal_item[i]['user_meal_items_id']] = res.meal_item[i]['item_price'];
					item_id[i] = res.meal_item[i]['user_meal_items_id'];
					item_append += '<input type="checkbox" class="custom-checkbox" style="height: 17%; margin-right: 10px;" id="meal_item_'+res.meal_item[i]['user_meal_items_id']+'" name="meal_item_'+res.meal_item[i]['user_meal_items_id']+'" onclick="change_price('+res.meal_item[i]['user_meal_items_id']+')" value="'+res.meal_item[i]['user_meal_items_id']+'" checked>'+
									'<label for="meal_item_'+res.meal_item[i]['user_meal_items_id']+'" style="font-size: 16px; font-weight: 500; color: #f82e56;">'+res.meal_item[i]['item_name']+' (Rs.'+res.meal_item[i]['item_price']+')</label><br>';
				}
				$('#item_body').append(item_append);
				$('#meal_item_selected').val(item_id);
					

			},
			error: function(result){  

			}
		});
		$('#mealModal').modal('show')
	}
	function change_price(id){
		// console.log(item_prices[id]);
		// console.log($('#meal_item_'+id).attr('checked'));
		var checkedCheckboxes = $('.custom-checkbox:checked');
		let total = $('#min_price').val();
		// Display the values in the console (you can adapt this part based on your requirements)
		let count = 0;
		let selected_items = [];

		checkedCheckboxes.each(function() {
			console.log($(this).val());
			console.log(item_prices[$(this).val()]);
			total = parseInt(total) + parseInt(item_prices[$(this).val()]);
			selected_items[count] = $(this).val();
			count++;

		});
		$('#meal_price').text('Rs.'+total);
		$('#final_price').val(total);
		$('#meal_item_selected').val(selected_items);
		$('#meal_qty').trigger('change');	

	}
	$('#meal_qty').on('change', function(e){  
		let qty = this.value;
		let final_price = $('#final_price').val();
		$('#final_qty').val(qty);
		// alert(qty*final_price);
		$('#order_tbn').text('Add 1 to cart - RS.'+(qty*final_price));

	});
</script>
<script>
	$('#cart-form').on('submit', function(e){  
		e.preventDefault();
		// console.log($('#cart-form').serialize());
		$.ajax({
			type: 'POST',
			url: '<?=base_url()?>add_to_cart_ajax',
			data: $('#cart-form').serialize(),
			success: function(result){  
				let res = $.parseJSON(result);
				if (res.status == 'success') {
					console.log(res.count);
					$('#cart_count').text(res.count);
					$('#mealModal').modal('hide');
				}else{
					toastr['error'](res.message);
				}
				
			},
			error: function(result){  

			}
		});
	});
</script>

</body>

</html>