<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CloudMeal | Chef Panel</title>
	<meta name="author" content="BigSteps">
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
	<link rel="shortcut icon" href="<?=base_url()?>assets/images/logo.png"> 
	<!-- Vendor -->
	<link href="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/slick/slick.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/swiper/swiper.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/nouislider/nouislider.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">

	<!-- Custom -->
	<link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/megamenu.css" rel="stylesheet">

	<!--toastr-->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">

	<!-- Color Schemes -->
	<!-- your style-color.css here  -->


	<!-- Icon Font -->
	<link href="<?=base_url()?>assets/fonts/icomoon-reg/style.css" rel="stylesheet">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

	<style>
		.active-nav{
			width: 100%;
			background-color: #494e62;
			left: 0;
			background-color: #494e62;
			left: -4px;
			border-right: 4px solid #f82e56;
		}
		ul.category-list li {
			position: relative;
			display: block;
			padding: 8px 0;
			font-size: 16px;
			line-height: 1.25em;
			font-weight: 500;
			color: #333745;
			text-decoration: none;
		}
		.details-tag{
			position: relative;
			display: block;
			padding: 11px 0;
			font-size: 16px;
			line-height: 1.25em;
			font-weight: 500;
			color: #333745;
			text-decoration: none;
		}
		
		
		.button-set{
			border: 1px solid #f82e56;
			background-color: #f82e56;
			border-radius: 5px;
			padding: 25px 15px 25px 15px;
			text-align: center;
			margin: 5px;
			color: #ffffff;
			font-weight: 900;
			cursor: pointer;
		}

		.button-set:hover{
			border: 1px solid #f82e56;
			background-color: #ffffff;
			border-radius: 5px;
			padding: 25px 15px 25px 15px;
			text-align: center;
			margin: 5px;
			color: #f82e56;
			font-weight: 900;
		}

	</style>
</head>

<body class="fullwidth open-panel" >
	<div id="wrapper">
		<!-- Page -->
		<div class="page-wrapper">
			<!-- Sidebar -->
			<div class="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li> <a href="<?=base_url()?>chef-account">HOME</a> </li>
					<li> <a href="<?=base_url()?>chef-order">Orders</a> </li>
					<li class="active-nav"> <a href="<?=base_url()?>chef-meals" class="active">My Meals</a> </li>
					<li> <a href="<?=base_url()?>chef-logout">LOGOUT</a> </li>
				</ul>
			</div>
			<!-- /Sidebar -->
			<!--header-->
			<header class="page-header variant-1 fullboxed sticky smart">
				<div class="navbar" style="margin: 0 0 0 0;">
					<div class="container">
						<div class="header-logo">
							<span style="font-size: 24px;font-family: 'Oswald', sans-serif; font-weight: 400; text-transform: uppercase; padding: 0 0 2px; margin: 0 0 30px 0; color: #333745;">Hi, <?=$this->session->userdata('user_logged_in')['user_name']?></span>
						</div>
					</div>
				</div>
			</header>
			<!--header end-->
			<!-- Page Content -->
			<main class="page-main">
				<div class="block" style="padding-top: 100px;">
					<div class="container" style="padding: 0 30px 0 30px;">
						<div class="page-title">
							<div class="title">
								<div class="row">
									<div class="col-md-8" style="display: inline-flex;">
										<h1><?=$meal_info[0]->meal_name?></h1>
									</div>
								</div>
							</div>
						</div>
						<div class="row" style="margin-bottom: 10px;">
							<div class="col-md-4">
								<div style="border-radius: 5px;">
									<img src="<?=PHOTO_DOMAIN.$meal_info[0]->meal_image?>" alt="" width="100%">
								</div>
							</div>
							<div class="col-md-5">
								<ul class="category-list">
									<li class="details-tag">Meal Name </a> <span style="float: right; font-weight: 100;"><a href="javascript:open_cook()" style="padding: 0px; color: #f82e56;"><?=$meal_info[0]->meal_name?></a></span></li>
									<li class="details-tag">Category <span style="float: right; font-weight: 100;"><?=$meal_info[0]->category?></span></li>
									<li class="details-tag">Number of Items <span style="float: right; font-weight: 100;"><?=count($meal_items)?></span></li>
									<li class="details-tag">Quantity <span style="float: right; font-weight: 100;" id="info_qty"><?=$meal_info[0]->qty?></span></li>
									<?php 
										$col_row = '';
										if ($meal_info[0]->qty_ordered > 0) {
											$col_row = 'background-color: lightgoldenrodyellow;';
										}
									?>
									<li class="details-tag" style="<?=$col_row?>">Number of Orders <span style="float: right; font-weight: 100;"><?=$meal_info[0]->qty_ordered?></span></li>
									<li class="details-tag">Price Range <span style="float: right; font-weight: 100;">Rs.<?=$meal_info[0]->min_price.' - Rs.'.$meal_info[0]->max_price?></span></li>
									<li class="details-tag">Date <span style="float: right; font-weight: 100;"><?=$meal_info[0]->user_meal_date?></span></li>
								</ul>
							</div>
							<div class="col-md-3">
								<div class="row">
									<div class="col-md-6" style="padding-right: 0px;">
										<div class="button-set" onclick="open_qty()">
											<i class="icon icon-pencil" style="font-size: 30px;"></i>
											<p>Update Qty</p> 
										</div>
									</div>
									<div class="col-md-6" style="padding-left: 0px;">
										<div class="button-set" onclick="open_status()">
											<i class="icon icon-star" style="font-size: 30px;"></i>
											<p>Status</p>
										</div>
									</div>
									<div class="col-md-6" style="padding-right: 0px;">
										<div class="button-set">
											<i class="icon icon-cart" style="font-size: 30px;"></i>
											<p>Orders</p> 
										</div>
									</div>
									<div class="col-md-6" style="padding-left: 0px;">
										<div class="button-set" onclick="add_new()">
											<i class="icon icon-plus" style="font-size: 30px;"></i>
											<p>Add New</p> 
										</div>
									</div>
								</div>
							</div>
						</div>
						<?php 
						// print_r($meal_info);
						?>
						<hr>
						<div class="row">
							<input type="hidden" id="operation_id" value="<?=$meal_info[0]->user_meal_id?>" data-qty="<?=$meal_info[0]->qty?>" data-order="<?=$meal_info[0]->qty_ordered?>">
							<input type="hidden" id="cur_stat" value="<?=$meal_info[0]->user_meal_status?>">
							<div class="col-md-8">
								<h2>View Item</h2>
								<div class="table-responsive" style="margin-bottom: 100px;">
									<table class="table table-bordered table-striped">
										<thead>
											<tr>
												<th scope="col"># </th>
												<!-- <th scope="col"></th> -->
												<th scope="col">Meal Pack </th>
												<th scope="col">Price</th>
											</tr>
										</thead>
										<tbody id="order_body">
											<tr>
												<td></td>
												<!-- <td><span class="color"></span></td> -->
												<td style="color: #f82e56;"><b><?=$meal_info[0]->category?></b>  </td>
												<td><span style="float: left; margin-right: 20px;color: #f82e56; color: #f82e56;"><b>Rs.<?=$meal_info[0]->min_price?></b></span></td>
											</tr>			
											<?php 
													$final_item_price = 0;
													$count = count($meal_items);
													foreach ($meal_items as $key1 => $item) {
														// if ($item_count == ($key1+1)) {
															$border = 'border-bottom: inset;';
															$final_item_price = $final_item_price+$item->item_price;
														// }
											?>
											<tr>
												<!-- <td></td> -->
												<td><?=($key1+1)?></td>
												<td style="<?=$border?>"><?=$item->item_name?> <span style="float: right; margin-right: 20px;">Rs.<?=$item->item_price?></span> </td>
												<td><b><?php if($key1 == ($count-1)){echo 'Rs.'.$final_item_price.' (Item Total)';}?></b></td>
											</tr>		
											<?php
													}
											?>
											<tr>
												<!-- <td></td> -->
												<td></td>
												<td></td>
												<td style="color: #f82e56; color: #f82e56; border-top: inset; border-bottom: double;"><b>Rs.<?=$meal_info[0]->min_price+$final_item_price?></b></td>
											</tr>
										</tbody>
									</table>
								</div>
								
							</div>
							<div class="col-md-4" style="background-color: gainsboro; border-radius: 7px; padding-bottom: 10px;">
								<h2>Price Breakup Calculator</h2>
								<div class="">
									<ul class="category-list">
										<input type="hidden" id="base_price" value="<?=$meal_info[0]->min_price?>">
										<li class="details-tag">Base Price (with 0 items) </a> <span style="float: right; font-weight: 100;"><b>Rs.<?=$meal_info[0]->min_price?></b></span></li>
										<?php 
											$final_item_price = 0;
											foreach ($meal_items as $key1 => $item) {
											$final_item_price = $final_item_price+$item->item_price;
										?>
												<li class="details-tag">
													<input type="checkbox" name="item_name[]" checked value="<?=$item->item_price?>" style="height: 13px;">
													<label><?=$item->item_name?></label>
													<span style="float: right; font-weight: 100;">Rs.<?=$item->item_price?></span>
												</li>	
										<?php
											}
										?>
										<li class="details-tag">Total Amount <b><span style="float: right; font-weight: 900; color: #f82e56;" id="final_rice_calculator">Rs.<?=$meal_info[0]->min_price+$final_item_price?></span></b></li>
									</ul>
								</div>
								<div class="divider divider-lg"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- /Page Content -->
			<!-- Footer -->
			<footer class="page-footer variant1">
				<div class="container">
					<div class="after-footer">
						<div class="footer-copyright text-center"> © 2016 Demo Store. All Rights Reserved. </div>
					</div>
				</div>
			</footer>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- Modal -->
	<div class="modal fade" id="qty-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title" id="meal_name">Update Meal Quantity</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="qtyForm">
								<input type="hidden" name="meal_id" id="meal_id">
								<div id="item_body">
									<label>Quantity<span class="required">*</span></label>
									<!-- <input type="email" class="form-control input-lg" name="email" id="modalloginemail" placeholder="Email Address" data-error="Please enter a valid email address."> -->
									<input type="number" class="form-control" name="qty-update" id="qty-update" required>
									<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="update_btn">Update</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="status-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title" id="meal_name">Update Order status</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="statusForm">
								<input type="hidden" name="status_meal_id" id="status_meal_id">
								<div id="item_body">
									<label>Status<span class="required">*</span></label>
									<!-- <input type="email" class="form-control input-lg" name="email" id="modalloginemail" placeholder="Email Address" data-error="Please enter a valid email address."> -->
									<select class="form-control" name="stat-update" id="stat-update">
										<option value="1">Active</option>
										<option value="0">Deactive</option>
									</select>
									<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="update_btn">Update</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/swiper/swiper.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/slick/slick.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/parallax/parallax.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/isotope/isotope.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/countdown/jquery.countdown.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/nouislider/nouislider.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/ez-plus/jquery.ez-plus.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/tocca/tocca.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/scrollLock/jquery-scrollLock.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/darktooltip/dist/jquery.darktooltip.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/instafeed/instafeed.min.js"></script>
	<script src="<?=base_url()?>assets/js/megamenu.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		var checkboxes = $('input[name="item_name[]"]');
		// $("input[name='item_name[]'] checked").each(function (index, obj) {
		// 	console.log(obj);
		// });
		checkboxes.filter(":checked").map(function () {
			// return this.value;
			console.log(this.value);
		}).get()

		checkboxes.on('change', function (e){  
			$('#final_rice_calculator').empty();
			let base_price = $('#base_price').val();
			let item_price = 0;
			checkboxes.filter(":checked").map(function () {
				// return this.value;
				item_price = parseFloat(item_price) + parseFloat(this.value);
			}).get()
			base_price = parseFloat(base_price) + parseFloat(item_price);
			$('#final_rice_calculator').text('Rs.'+base_price);
		});
	</script>
	<script>
		function open_qty(){  
			let order_id = $('#operation_id').val();
			let qty = $('#operation_id').attr('data-qty');
			let order_qty = $('#operation_id').attr('data-order');
			$('#meal_id').val(order_id);
			$('#qty-update').val(qty);
			// alert(order_id);
			$('#qty-modal').modal('show');
		}
	</script>
	<script>
		$('#qtyForm').on('submit', function (e) {  
			e.preventDefault();
			let meal_id = $('#meal_id').val();
			let qty = $('#operation_id').attr('data-qty');
			let order_qty = $('#operation_id').attr('data-order');
			let update_qty = $('#qty-update').val();
			// alert($('#statusForm').serialize());
			if (parseInt(order_qty) > parseInt(update_qty)) {
				toastr["error"]("You already have orders more than "+update_qty);
			}else{
				$.ajax({
					type: 'POST',
					url: '<?=base_url()?>chef_meal_qty_update_ajax',
					data: $('#qtyForm').serialize(),
					success: function (result){  
						let res = $.parseJSON(result);
						if (res.status == 'success') {
							toastr["success"](res.message);
							$('#qty-modal').modal('hide');
							$('#operation_id').attr('data-qty', update_qty);
							$('#info_qty').empty();
							$('#info_qty').text(update_qty);
							
						}else{
							toastr["error"](res.message);
						}
					},
					error: function (result){  
	
					}
				});
			}
		});
	</script>

	<script>
		function open_status(){  
			let meal_id = $('#operation_id').val();
			let cur_stat = $('#cur_stat').val();
			$('#status_meal_id').val(meal_id);
			$('#stat-update').val(cur_stat);
			// alert(order_id);
			$('#status-modal').modal('show');
		}
	</script>
	<script>
		$('#statusForm').on('submit', function (e) {  
			e.preventDefault();
			let meal_id = $('#meal_id').val();
			let new_stat = $('#stat-update').val();

			// alert($('#statusForm').serialize());
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>chef_meal_status_update_ajax',
				data: $('#statusForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
	                    toastr["success"](res.message);
						$('#status-modal').modal('hide');
						$('#cur_stat').val(new_stat);
						
					}else{
	                    toastr["error"](res.message);
					}
				},
				error: function (result){  

				}
			});
		});
	</script>
	<script>
		function add_new(){  
			window.open("<?php echo site_url('add_meal'); ?>");
		}
	</script>
		













	<script>
		function getOrder(){  
			// alert('hi');
			let status = '';
			let order_body = '';
			$('#order_body').empty();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>get_order_ajax',
				data: 'search=3845784',
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						for (let i = 0; i < res.message.length; i++) {
							switch (res.message[i]['order_status']) {
								case '1':
									status = 'Order Placed';
									break;
								case '2':
									status = 'Cooking';
									break;
								case '3':
									status = 'Packed';
									break;
								case '4':
									status = 'Ready to Pick';
									break;
								case '5':
									status = 'Delivered';
									break;
								case '6':
									status = 'Cancelled';
									break;
							}
							// alert(status);
							order_body += '<tr>'+
												'<td>'+(i+1)+'</td>'+
												'<td><b>175525</b> <a href="javascript:open_order('+res.message[i]['order_id']+')" class="pull-right">View Details</a></td>'+
												'<td>'+res.message[i]['order_date']+'</td>'+
												'<td><span class="color">Rs.'+res.message[i]['order_amount']+'</span></td>'+
												'<td>'+res.message[i]['f_name']+' '+res.message[i]['l_name']+'</td>'+
												'<td><a href="#" class="btn btn-sm">'+status+'</a></td>'+
											'</tr>';
						}
						$('#order_body').append(order_body);
					}
				},
				error: function (result){  

				}
			});
		}
	</script>
	<script>
		function cancel_order(){  
			let id = $('#operation_id').val();
			$('#cancel_id').val(id);
			$('#order_cancel_name').html('Cancel Order <span style="color: #f82e56;">#'+$('#operation_id').attr('data-code')+'</span>');
			$('#cancel-modal').modal('show');
		}
		$('#cancelForm').on('submit', function(e){  
			e.preventDefault();
			$.ajax({
				type: "POST",
				url: "<?=base_url()?>cancel_order",
				data: $('#cancelForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
						$('#cancel-modal').modal('hide');
						if (res.status == 'success') {
							toastr["success"](res.message);
							setTimeout(function() { 
								window.location.reload();
							}, 2000);	
						}else{
							toastr["error"](res.message);

						}
				},
				error: function (result){  

				}
			});
		});
	</script>
	<script>
		function open_reason(){  
			alert($('#view_reason').val());
		}
		function open_cook(){  
			alert("hi");
		}
	</script>
</body>

</html>