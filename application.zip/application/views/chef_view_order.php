<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CloudMeal | Chef Panel</title>
	<meta name="author" content="BigSteps">
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
	<link rel="shortcut icon" href="<?=base_url()?>assets/images/logo.png"> 
	<!-- Vendor -->
	<link href="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/slick/slick.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/swiper/swiper.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/nouislider/nouislider.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">

	<!-- Custom -->
	<link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/megamenu.css" rel="stylesheet">

	<!--toastr-->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">

	<!-- Color Schemes -->
	<!-- your style-color.css here  -->


	<!-- Icon Font -->
	<link href="<?=base_url()?>assets/fonts/icomoon-reg/style.css" rel="stylesheet">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

	<style>
		.active-nav{
			width: 100%;
			background-color: #494e62;
			left: 0;
			background-color: #494e62;
			left: -4px;
			border-right: 4px solid #f82e56;
		}
		ul.category-list li {
			position: relative;
			display: block;
			padding: 11px 0;
			font-size: 16px;
			line-height: 1.25em;
			font-weight: 500;
			color: #333745;
			text-decoration: none;
		}
		.details-tag{
			position: relative;
			display: block;
			padding: 11px 0;
			font-size: 16px;
			line-height: 1.25em;
			font-weight: 500;
			color: #333745;
			text-decoration: none;
		}
		
		
		.star-rating {
		font-size: 0; /* Hide the text content */
		}

		.star {
		display: inline-block;
		width: 20px;
		height: 20px;
		background-color: #ccc; /* Default star color */
		margin-right: 5px; /* Space between stars */
		position: relative;
		}

		.star:before {
		content: '\2605'; /* Unicode character for a star */
		font-size: 20px;
		position: absolute;
		top: 0;
		left: 0;
		color: gold; /* Color of the filled star */
		overflow: hidden;
		width: 0;
		}

		.star[data-rating="0.5"]:before {
		width: 50%; /* Width of the filled star for a rating of 0.5 */
		}

		.star[data-rating="1"]:before {
		width: 100%; /* Width of the filled star for a rating of 1 */
		}

		.star[data-rating="1.5"]:before {
		width: 150%; /* Width of the filled star for a rating of 1.5 */
		}
	</style>
</head>

<body class="fullwidth open-panel" >
	<div id="wrapper">
		<!-- Page -->
		<div class="page-wrapper">
			<!-- Sidebar -->
			<div class="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li> <a href="<?=base_url()?>chef-account">HOME</a> </li>
					<li class="active-nav"> <a href="<?=base_url()?>chef-order" class="active">Orders</a> </li>
					<li> <a href="<?=base_url()?>chef-meals">My Meals</a> </li>
					<li> <a href="<?=base_url()?>chef-logout">LOGOUT</a> </li>
				</ul>
			</div>
			<!-- /Sidebar -->
			<!--header-->
			<header class="page-header variant-1 fullboxed sticky smart">
				<div class="navbar" style="margin: 0 0 0 0;">
					<div class="container">
						<div class="header-logo">
							<span style="font-size: 24px;font-family: 'Oswald', sans-serif; font-weight: 400; text-transform: uppercase; padding: 0 0 2px; margin: 0 0 30px 0; color: #333745;">Hi, <?=$this->session->userdata('user_logged_in')['user_name']?></span>
						</div>
					</div>
				</div>
			</header>
			<!--header end-->
			<!-- Page Content -->
			<main class="page-main">
				<div class="block" style="padding-top: 100px;">
					<div class="container" style="padding: 0 30px 0 30px;">
						<div class="page-title">
							<div class="title">
								<div class="row">
									<div class="col-md-8" style="display: inline-flex;">
										<h1>#<?=$order_info[0]->order_code?></h1>
										<?php 
											if ($order_rating) {
												$active = $order_rating->rating;
												
										?>
										<div class="rating" style="padding: 20px;">
											<?php 
												for ($i=1; $i < 6; $i++) { 
													$fill = '';
													if ($i <= $active) {
														$fill = 'fill';
													}
											?>
											<i class="icon icon-star <?=$fill?>"></i>
											<?php 
												}
											?>
										</div>
										<?php 
											}
										?>

										
										<!-- <pre>
											<?php 
												print_r($order_rating);
											?>
										</pre> -->
									</div>
									<div class="col-md-4">
										<?php 
											if($order_info[0]->order_status != 5){
										?>
											<a href="javascript:update_order()" style="float: right;" class="btn btn-lg">Update Order Status</a>
										<?php 
											}
										?>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<input type="hidden" id="operation_id" value="<?=$order_info[0]->order_id?>" data-code="<?=$order_info[0]->order_code?>">
							<input type="hidden" id="cur_stat" value="<?=$order_info[0]->order_status?>">
							<div class="col-md-8">
								<h2>View Item</h2>
								<div class="table-responsive" style="margin-bottom: 100px;">
									<table class="table table-bordered table-striped">
										<thead>
											<tr>
												<th scope="col"># </th>
												<!-- <th scope="col"></th> -->
												<th scope="col">Meal Pack </th>
												<th scope="col">Price</th>
											</tr>
										</thead>
										<tbody id="order_body">
											<?php 
												foreach ($order_meal as $key => $value) {
											?>
											<tr>
												<td><?=$key+1?></td>
												<!-- <td><span class="color"></span></td> -->
												<td style="color: #f82e56;"><b><?=$value->meal_name?></b> <span style="float: right; margin-right: 20px;">Rs.<?=$value->min_price?></span> </td>
												<td></td>
											</tr>			
											<?php 
													if ($value->items) {
													$item_count = count($value->items);
													$border = "";
													$final_item_price = "";
													// echo $item_count;
													foreach ($value->items as $key1 => $item) {
														if ($item_count == ($key1+1)) {
															$border = 'border-bottom: inset;';
															$final_item_price = "Rs.".$value->order_meal_price;
												}
											?>
											<tr>
												<!-- <td></td> -->
												<td></td>
												<td style="<?=$border?>"><?=$item->item_name?> <span style="float: right; margin-right: 20px;">Rs.<?=$item->item_price?></span> </td>
												<td><b><?=$final_item_price?></b></td>
											</tr>		
											<?php
													}
												}
												}
											?>
											<tr>
												<!-- <td></td> -->
												<td></td>
												<td></td>
												<td style="color: #f82e56; color: #f82e56; border-top: inset; border-bottom: double;"><b>Rs.<?=$order_info[0]->order_amount?></b></td>
											</tr>
										</tbody>
									</table>
								</div>

								<?php 
									if ($order_info[0]->order_note) {
								?>
								<h2>Special Note / Comment</h2>
								<div class="table-responsive">
									<?=$order_info[0]->order_note?>
								</div>
								<?php 
									}
								?>

								
							</div>
							<div class="col-md-4" style="background-color: gainsboro; border-radius: 7px; padding-bottom: 10px;">
								<h2>Order Details</h2>
								<div class="">
									<ul class="category-list">
										<li class="details-tag">Order Code </a> <span style="float: right; font-weight: 100;"><?=$order_info[0]->order_code?></span></li>
										<li class="details-tag">Date <span style="float: right; font-weight: 100;"><?=$order_info[0]->order_date?></span></li>
										<li class="details-tag">Cook <span style="float: right; font-weight: 100;"><a href="javascript:open_cook()" style="padding: 0px; color: #f82e56;"><?=$order_info[0]->f_name.' '.$order_info[0]->l_name?></a></span></li>
										<li class="details-tag">No. of Items <span style="float: right; font-weight: 100;"><?=$order_info[0]->items?></span></li>
										<?php 
											$status = "";
											$color = "";
											switch ($order_info[0]->order_status) {
												case '1':
													$status = 'Order Placed';
													$color = "color: blue;";
													break;
												case '2':
													$status = 'Cooking';
													$color = "color: yellow;";
													break;
												case '3':
													$status = 'Packed';
													$color = "color: orange;";
													break;
												case '4':
													$status = 'Ready to Pick';
													$color = "color: green;";
													break;
												case '5':
													$status = 'Delivered';
													$color = "color: grey;";
													break;
												case '6':
													$status = 'Cancelled';
													$color = "color: red;";
													break;
											}
										?>
										<li class="details-tag">Order Status <span style="float: right; font-weight: 100;" class="btn btn-sm" id="stat"><?=$status?></span></li>
										<li class="details-tag">Amount <span style="float: right; font-weight: 100;">Rs.<?=$order_info[0]->order_amount?></span></li>
									</ul>
								</div>
								<div class="divider divider-lg"></div>
								<?php 
									if ($order_rating) {
										$active = $order_rating->rating;
										
								?>
								<h2>Rating and Feedback</h2>
								<ul class="category-list">
									<li class="details-tag">Reason <span style="float: right; font-weight: 100;">
										<div class="rating">
											<?php 
												for ($i=1; $i < 6; $i++) { 
													$fill = '';
													if ($i <= $active) {
														$fill = 'fill';
													}
											?>
											<i class="icon icon-star <?=$fill?>"></i>
											<?php 
												}
											?>
										</div></span>
									</li>
									<li class="details-tag">Feedback <span style="float: right; font-weight: 100; font-size: 14px; width: 100%; margin-top: 5px;"><?=$order_rating->feedback?></span></li>
								</ul>
								<?php 
									}
								?>
								<div class="divider divider-lg"></div>
								<?php 
									if ($order_cancel) {
								?>
								<h2>Cancel Details</h2>
								<div class="">
									<ul class="category-list">
										<li class="details-tag">Wallet Refund </a> <span style="float: right; font-weight: 100;"><?=$order_cancel[0]->referance?></span></li>
										<?php 
											if ($order_cancel[0]->reason) {
										?>
										<li class="details-tag">Reason <span style="float: right; font-weight: 100;"><a href="javascript:open_reason()" style="padding: 0px;">View Details</a></span></li>
										<input type="hidden" id="view_reason" value="<?=$order_cancel[0]->reason?>">
										<?php 
											}
										?>
										<li class="details-tag">Date <span style="float: right; font-weight: 100;"><?=$order_cancel[0]->cancel_date?></span></li>
									</ul>
								</div>
								<?php 
									}
								?>
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- /Page Content -->
			<!-- Footer -->
			<footer class="page-footer variant1">
				<div class="container">
					<div class="after-footer">
						<div class="footer-copyright text-center"> © 2016 Demo Store. All Rights Reserved. </div>
					</div>
				</div>
			</footer>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- Modal -->
	<div class="modal fade" id="status-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title" id="meal_name">Update Order status</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="statusForm">
								<input type="hidden" name="order_id" id="order_id">
								<div id="item_body">
									<label>Status<span class="required">*</span></label>
									<!-- <input type="email" class="form-control input-lg" name="email" id="modalloginemail" placeholder="Email Address" data-error="Please enter a valid email address."> -->
									<select class="form-control" name="stat-update" id="stat-update">
										<option value="1">Order Placed</option>
										<option value="2">Cooking</option>
										<option value="3">Packed</option>
										<option value="4">Ready To Pick</option>
										<option value="5">Delivered</option>
										<option value="6" disabled>Cancelled</option>
									</select>
									<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="update_btn">Update</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/swiper/swiper.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/slick/slick.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/parallax/parallax.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/isotope/isotope.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/countdown/jquery.countdown.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/nouislider/nouislider.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/ez-plus/jquery.ez-plus.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/tocca/tocca.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/scrollLock/jquery-scrollLock.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/darktooltip/dist/jquery.darktooltip.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/instafeed/instafeed.min.js"></script>
	<script src="<?=base_url()?>assets/js/megamenu.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		function getOrder(){  
			// alert('hi');
			let status = '';
			let order_body = '';
			$('#order_body').empty();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>get_order_ajax',
				data: 'search=3845784',
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						for (let i = 0; i < res.message.length; i++) {
							switch (res.message[i]['order_status']) {
								case '1':
									status = 'Order Placed';
									break;
								case '2':
									status = 'Cooking';
									break;
								case '3':
									status = 'Packed';
									break;
								case '4':
									status = 'Ready to Pick';
									break;
								case '5':
									status = 'Delivered';
									break;
								case '6':
									status = 'Cancelled';
									break;
							}
							// alert(status);
							order_body += '<tr>'+
												'<td>'+(i+1)+'</td>'+
												'<td><b>175525</b> <a href="javascript:open_order('+res.message[i]['order_id']+')" class="pull-right">View Details</a></td>'+
												'<td>'+res.message[i]['order_date']+'</td>'+
												'<td><span class="color">Rs.'+res.message[i]['order_amount']+'</span></td>'+
												'<td>'+res.message[i]['f_name']+' '+res.message[i]['l_name']+'</td>'+
												'<td><a href="#" class="btn btn-sm">'+status+'</a></td>'+
											'</tr>';
						}
						$('#order_body').append(order_body);
					}
				},
				error: function (result){  

				}
			});
		}
	</script>
	<script>
		function cancel_order(){  
			let id = $('#operation_id').val();
			$('#cancel_id').val(id);
			$('#order_cancel_name').html('Cancel Order <span style="color: #f82e56;">#'+$('#operation_id').attr('data-code')+'</span>');
			$('#cancel-modal').modal('show');
		}
		$('#cancelForm').on('submit', function(e){  
			e.preventDefault();
			$.ajax({
				type: "POST",
				url: "<?=base_url()?>cancel_order",
				data: $('#cancelForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
						$('#cancel-modal').modal('hide');
						if (res.status == 'success') {
							toastr["success"](res.message);
							setTimeout(function() { 
								window.location.reload();
							}, 2000);	
						}else{
							toastr["error"](res.message);

						}
				},
				error: function (result){  

				}
			});
		});
	</script>
	<script>
		function open_reason(){  
			alert($('#view_reason').val());
		}
		function open_cook(){  
			alert("hi");
		}
	</script>
	<script>
		function update_order(){  
			let order_id = $('#operation_id').val();
			let cur_stat = $('#cur_stat').val();

			$('#stat-update').val(cur_stat);
			$('#order_id').val(order_id);

			$('#stat-update').attr('disabled', false);
			$('#update_btn').attr('disabled', false);

			if (cur_stat == 6) {
				$('#stat-update').attr('disabled', true);
				$('#update_btn').attr('disabled', true);
			}
			$('#status-modal').modal('show');
		}
	</script>
	<script>
		// status-modal
		$('#statusForm').on('submit', function (e) {  
			e.preventDefault();
			let order_id = $('#order_id').val();
			let order_status = $('#stat-update').val();
			let order_text = $( "#stat-update option:selected" ).text();

			// alert($('#statusForm').serialize());
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>chef_update_order_ajax',
				data: $('#statusForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
	                    toastr["success"](res.message);
						$('#status-modal').modal('hide');
						$('#stat').text(order_text);
						$('#cur_stat').val(order_status);
						
					}else{
	                    toastr["error"](res.message);
					}
				},
				error: function (result){  

				}
			});
		});
	</script>
</body>

</html>