<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Head -->
	<?php $this->load->view('includes/head'); ?>
	<!-- /Head -->
</head>

<body class="boxed">
	<div id="wrapper">
		<!-- Page -->
		<div class="page-wrapper">
			<!-- Header -->
				<?php $this->load->view('includes/header'); ?>
			<!-- /Header -->
			<!-- Page Content -->
			<main class="page-main">
				<div class="block">
					<div class="container">
						<ul class="breadcrumbs">
							<li><a href="index.html"><i class="icon icon-home"></i></a></li>
							<li>/<span>Register as a chef</span></li>
						</ul>
					</div>
				</div>


				<div class="form-card" style="">
					<div class="row">
						<div class="col-md-6">
							<h4>Registered As Chef</h4>
							<p>If you have an account with us, please log in.</p>
							<form id="signup-business-form">
								<label>First Name<span class="required">*</span></label>
								<input class="form-control" type="text" name="fname" placeholder="First Name" pattern="^[a-zA-Z. ]+$" data-minlength="3" data-pattern-error="Invalid first name" data-error="Minimum of 3 characters" data-required-error="First name is required" required>
								<label>Last Name<span class="required">*</span></label>
								<input class="form-control" type="text" name="lname" placeholder="Last Name" pattern="^[a-zA-Z. ]+$" data-minlength="3" data-pattern-error="Invalid last name" data-error="Minimum of 3 characters" data-required-error="Last name is required" required>
								<label>Mobile Number<span class="required">*</span></label>
								<input class="form-control" type="number" name="mobile" placeholder="Mobile Number" data-minlength="9" data-error="Mobile number is invalid" data-required-error="Mobile number is required" required>
								<label>City<span class="required">*</span></label>
								<select class="form-control" name="city" id="city" required>
									<?php
										foreach ($cities as $key => $city) {
									?>
									<option value="<?=$city->city_id?>"><?=$city->city_name?></option>
									<?php 
										}
									?>
								</select>
								<label>Address<span class="required">*</span></label>
								<textarea class="form-control" name="address" style="resize: none;" placeholder="Address" required></textarea>
								<label>E-mail<span class="required">*</span></label>
								<input class="form-control" type="email" name="email" placeholder="Email Address" data-error="Please enter a valid email address." data-remote="<?=base_url()?>checkfields?data=email&input=email&table=customers" data-remote-error="Email address already exist" required>
								<label>Password<span class="required">*</span></label>
								<input type="password" placeholder="Password" class="form-control" data-minlength="6" class="form-control" name="password" id="password" data-error="Minimum of 6 characters" data-required-error="Password is Required" required>
								<label>Confirm Password<span class="required">*</span></label>
								<input type="password" class="form-control" id="pass-match" data-match="#password" data-match-error="Password doesn't match" placeholder="Confirm password" data-required-error="Confirm Password is Required" required>
								<div>
									<button class="btn btn-lg" type="submit">Register</button>
									<span class="required-text" style="float: right;">* Required Fields</span>
								</div>
							</form>
						</div>
						<div class="col-md-6">

						</div>
					</div>
					

					<div>
						
					</div>
				</div>
			</main>
			<!-- /Page Content -->
			<!-- Footer -->
    			<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		$('#signup-business-form').on('submit', function (e) {
			e.preventDefault()
			alert($('#signup-business-form').serialize());
			if ($('#password').val() != $('#pass-match').val()) {
				toastr["error"]("Password doesn't match")
			} else {
				$.ajax({
					type: "POST",
					url: "<?=base_url()?>chef-signup",
					data: $('#signup-business-form').serialize(),
					success: function(result) {
						var responsedata = $.parseJSON(result);
						if(responsedata.status=='success'){
							toastr["success"](responsedata.message)
							window.open("<?php echo site_url('business'); ?>", '_self');
						}else{
							toastr["error"](responsedata.message)
						}
					},
					error: function(result) {
						toastr["error"]('Error :'+result)
					}
				});
			}
		});
	</script>
</body>

</html>