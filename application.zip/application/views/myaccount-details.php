<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('includes/head'); ?>
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
			<?php $this->load->view('includes/header'); ?>
			<main class="page-main">
				<div class="block">
					<div class="container">
						<div class="page-title">
							<div class="title">
								<h1>My Dashboard</h1>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="white-sideblock">
									<ul class="category-list">
										<li class="active"><a href="<?=base_url()?>acc-details">Account Details</a></li>
										<li><a href="<?=base_url()?>acc-wallet">My Wallet</a></li>
										<li><a href="<?=base_url()?>account">My Order History</a></li>
										<li><a href="<?=base_url()?>logout">Logout</a></li>
									</ul>
								</div>
								<div class="divider divider-lg"></div>
							</div>
							<div class="col-md-9">
								<h2>Account Details</h2>
								<div class="row">
									<div class="col-md-6">
										<input type="hidden" id="f_name_exist" value="<?=$user_info[0]->consumer_f_name?>">
										<input type="hidden" id="l_name_exist" value="<?=$user_info[0]->consumer_l_name?>">
										<input type="hidden" id="phone_exist" value="<?=$user_info[0]->consumer_mobile?>">
										<div class="white-card">
											<!-- <pre> -->
												<?php 
													// print_r($user_info);
												?>
											<!-- </pre> -->
											<p><b>Name:</b> <span id="name_info"><?=$user_info[0]->consumer_f_name.' '.$user_info[0]->consumer_l_name?></span></p>
											<p><b>E-mail:</b> <?=$user_info[0]->consumer_email?></p>
											<p><b>Phone:</b> <span id="phone_info"><?=$user_info[0]->consumer_mobile?></span></p>
											<p>
												<a href="javascript:edit_user()">Edit Name and Phone</a>
											</p>
										</div>
									</div>
									<div class="col-md-6">
										<h4>Update Password</h4>
										<form action="#" id="passwordUpdateForm">
											<input type="hidden" name="operation_id" id="operation_id" value="<?=$user_info[0]->consumer_id?>">
											<label for="old_pass">Current Password*</label>
											<input type="password" class="form-control" name="old_pass" id="old_pass" required>
											<label for="old_pass">New Password*</label>
											<input type="password" class="form-control" name="new_pass" id="new_pass" required>
											<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="update_btn">Update Password</button>
										</form>
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- Footer -->
    			<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
	</div>

	<div class="modal fade" id="update-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title" id="meal_name">Update Order status</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="UserUpdateForm">
								<input type="hidden" name="operation_id_1" id="operation_id_1" value="<?=$user_info[0]->consumer_id?>">
								<div>
									<div class="row">
										<div class="col-md-6">
											<label>First Name<span class="required">*</span></label>
											<input type="text" class="form-control" name="f_name" id="f_name" placeholder="First Name" required>
										</div>
										<div class="col-md-6">
											<label>Last Name<span class="required">*</span></label>
											<input type="text" class="form-control" name="l_name" id="l_name" placeholder="Last Name" required>
										</div>
									</div>
									<div class="row">
										<div class="col-md-12">
											<label>Phone<span class="required">*</span></label>
											<input type="number" class="form-control" name="phone" id="phone" placeholder="Phone" required>
										</div>
									</div>
									<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="user_update_btn">Update</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		function edit_user(){
			$('#f_name').val($('#f_name_exist').val());
			$('#l_name').val($('#l_name_exist').val());
			$('#phone').val($('#phone_exist').val());

			$('#update-modal').modal('show');
		}
	</script>
	<script>
		$('#passwordUpdateForm').on('submit', function(e){
			e.preventDefault();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>update_customer_pass_ajax',
				data: $('#passwordUpdateForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						toastr["success"](res.message);
						window.open("<?php echo site_url('logout'); ?>", '_self');
					}else{
						toastr["error"](res.message);
					}
				},
				error: function (result){  

				}
			});
		});
	</script>
	<script>
		$('#UserUpdateForm').on('submit', function(e){
			e.preventDefault();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>update_customer_details_ajax',
				data: $('#UserUpdateForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						toastr["success"](res.message);
						$('#f_name_exist').val($('#f_name').val());
						$('#l_name_exist').val($('#l_name').val());
						$('#phone_exist').val($('#phone').val());

						$('#name_info').text($('#f_name').val()+' '+$('#l_name').val());
						$('#phone_info').text($('#phone').val());
						
						$('#update-modal').modal('hide');
					}else{
						toastr["error"](res.message);
					}
				},
				error: function (result){  

				}
			});
		});
	</script>
</body>

</html>