<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CloudMeal | Chef Panel</title>
	<meta name="author" content="BigSteps">
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
	<link rel="shortcut icon" href="<?=base_url()?>assets/images/logo.png"> 
	<!-- Vendor -->
	<link href="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/slick/slick.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/swiper/swiper.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/nouislider/nouislider.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">

	<!--toastr-->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">

	<!-- Custom -->
	<link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/megamenu.css" rel="stylesheet">

	<!-- Color Schemes -->
	<!-- your style-color.css here  -->


	<!-- Icon Font -->
	<link href="<?=base_url()?>assets/fonts/icomoon-reg/style.css" rel="stylesheet">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

	<style>
		.active-nav{
			width: 100%;
			background-color: #494e62;
			left: 0;
			background-color: #494e62;
			left: -4px;
			border-right: 4px solid #f82e56;
		}
		.details-tag{
			position: relative;
			display: block;
			padding: 11px 0;
			font-size: 16px;
			line-height: 1.25em;
			font-weight: 500;
			color: #333745;
			text-decoration: none;
		}
	</style>
</head>

<body class="fullwidth open-panel" onload="getMeal()">
	<div id="wrapper">
		<!-- Page -->
		<div class="page-wrapper">
			<!-- Sidebar -->
			<div class="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li> <a href="<?=base_url()?>chef-account">HOME</a> </li>
					<li> <a href="<?=base_url()?>chef-order">Orders</a> </li>
					<li class="active-nav"> <a href="<?=base_url()?>chef-meals" class="active">My Meals</a> </li>
					<li> <a href="<?=base_url()?>chef-logout">LOGOUT</a> </li>
				</ul>
			</div>
			<!-- /Sidebar -->
			<!--header-->
			<header class="page-header variant-1 fullboxed sticky smart">
				<div class="navbar" style="margin: 0 0 0 0;">
					<div class="container">
						<div class="header-logo">
							<span style="font-size: 24px;font-family: 'Oswald', sans-serif; font-weight: 400; text-transform: uppercase; padding: 0 0 2px; margin: 0 0 30px 0; color: #333745;">Hi, <?=$this->session->userdata('user_logged_in')['user_name']?></span>
						</div>
					</div>
				</div>
			</header>
			<!--header end-->
			<!-- Page Content -->
			<main class="page-main">
				<div class="block">
					<div class="container" style="margin-top: 60px;">
						<div class="page-title">
							<div class="title">
								<!-- <h1>My Dashboard</h1> -->
							</div>
						</div>
						<div class="row" style="padding: 20px;">
							<div class="col-md-12">
								<!-- <a href="#" class="btn btn-alt pull-right">Meals Packs History</a> -->
								<h2>Add New Meal Pack</h2>
								<div class="row">
									<div class="col-md-8">
										<div>
											<form action="#" id="add_meal_form">
												<div class="row">
													<div class="col-md-12">
														<label for="meal_name">Meal Name</label>
														<input type="text" class="form-control" name="meal_name" id="meal_name" required>
													</div>
												</div>
												<div class="row">
													<div class="col-md-6">
														<label for="meal_cat">Meal Category</label>
														<input type="hidden" class="form-control" name="cat_price" id="cat_price" value="0">
														<select class="form-control" name="meal_cat" id="meal_cat" required>
															<?php 
															// print_r($cat);
																for ($j=0; $j < count($cat); $j++) { 
																	
															?>
															<option value="<?=$cat[$j]->category_id?>" data-price="<?=$cat[$j]->category_price?>"><?=$cat[$j]->category.' - (Rs.'.$cat[$j]->category_price.')'?></option>
															<?php 
																}
															?>
														</select>
													</div>
													<div class="col-md-6">
														<label for="meal_qty">Quantity</label>
														<input type="number" class="form-control" name="meal_qty" id="meal_qty" min="1" required>
													</div>
												</div>
												<div class="row">
													<div class="col-md-6">
														<label for="meal_date">Meal Date</label>
														<input type="date" class="form-control" name="meal_date" id="meal_date" required>
													</div>
													<div class="col-md-6">
														<label for="meal_image">Meal Image</label>
														<input type="file" class="form-control" name="meal_image" id="meal_image" accept="image/jpg">
													</div>
												</div>
												<div class="row">
													<div class="col-md-12">
														<div style="padding: 20px; background-color: pink; border-radius: 5px;">
															<div class="row">
																<div class="col-md-12">
																	<a href="javascript:open_items()" class="btn btn-alt pull-right">
																		<i class="icon icon-plus"></i>
																		Add Meal Item
																	</a>
																</div>
															</div>
															<div class="row">
																<div class="col-md-12">
																	<label for="">Meal Items</label>
																</div>
															</div>

															<div id="items_body">
																
															</div>
														</div>
													</div>
												</div>
												<div class="row" style="margin-top: 10px;">
													<div class="col-md-12">
														<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="update_btn">Save Meal</button>
													</div>
												</div>
											</form>
										</div>
									</div>
									<div class="col-md-4" style="background-color: gainsboro; border-radius: 7px; padding-bottom: 10px;">
										<h2>Meal Pack Details</h2>
										<div class="">
											<ul class="category-list">
												<li class="details-tag">Category Price <span style="float: right; font-weight: 100;" id="detail_cat_price">Rs.0</span></li>
												<li class="details-tag">Minimum Price <span style="float: right; font-weight: 100;" id="detail_min_price">Rs.0</span></li>
												<li class="details-tag">Maximum Price <span style="float: right; font-weight: 100;" id="detail_max_price">Rs.0</span></li>
												<li class="details-tag">No. of Items <span style="float: right; font-weight: 100;" id="detail_items">0</span></li>
											</ul>
										</div>
										<div class="divider divider-lg"></div>
									</div>
								</div>
								
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- /Page Content -->
			<!-- Footer -->
			<footer class="page-footer variant1">
				<div class="container">
					<div class="after-footer">
						<div class="footer-copyright text-center"> © 2016 Demo Store. All Rights Reserved. </div>
					</div>
				</div>
			</footer>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- Page Content -->
	<div class="modal fade" id="items-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title" id="meal_name">Update Order status</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="addItemForm">
								<input type="hidden" name="status_meal_id" id="status_meal_id">
								<div id="item_body">
									<label>Item<span class="required">*</span></label>
									<!-- <input type="email" class="form-control input-lg" name="email" id="modalloginemail" placeholder="Email Address" data-error="Please enter a valid email address."> -->
									<select class="form-control" name="meal-items" id="meal-items">
										<?php 
										print_r($meal_item);
											for ($i=0; $i < count($meal_item); $i++) { 
												
										?>
										<option value="<?=$meal_item[$i]->menu_item_id?>" data-min="<?=$meal_item[$i]->min_price?>" data-max="<?=$meal_item[$i]->max_price?>"><?=$meal_item[$i]->item_name.' - (Rs.'.$meal_item[$i]->min_price.' - Rs.'.$meal_item[$i]->max_price.')'?></option>
										<?php 
											}
										?>
									</select>
									<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="update_btn">Add</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/swiper/swiper.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/slick/slick.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/parallax/parallax.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/isotope/isotope.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/countdown/jquery.countdown.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/nouislider/nouislider.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/ez-plus/jquery.ez-plus.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/tocca/tocca.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/scrollLock/jquery-scrollLock.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/darktooltip/dist/jquery.darktooltip.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/instafeed/instafeed.min.js"></script>
	<script src="<?=base_url()?>assets/js/megamenu.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		let item_ids = [];
	</script>
	<script>
		function open_items(){
			$("#meal-items").val(1);
			$('#items-modal').modal('show');
		}
	</script>
	<script>
		$('#addItemForm').on('submit', function (e) {  
			e.preventDefault();
			// alert($('#addItemForm').serialize());
			var sel = document.getElementById('meal-items');
			var selected = sel.options[sel.selectedIndex];
			var item_id = $("#meal-items").val();
			var item_name = $( "#meal-items option:selected" ).text();
			var max_price = selected.getAttribute('data-max');
			var min_price = selected.getAttribute('data-min');

			// alert(item_ids);
			// alert(item_ids.inArray(item_id));
			if ($.inArray(item_id, item_ids) == -1) {
				item_ids.push(item_id);
				let append_body = '<div class="row" id="row_id_'+item_id+'">'+
				'<div class="col-md-8">'+
				'<label for="" class="form-control">'+item_name+'</label>'+
				'</div>'+
				'<div class="col-md-4" style="display: inline-flex;">'+
				'<span style="margin-top: 10px;">Rs.</span>'+
											'<input type="number" class="form-control prices_selected" name="item_list[]" id="price_input_'+item_id+'" value="'+min_price+'" min="'+min_price+'" max="'+max_price+'" onchange="update_price('+item_id+')">'+
											'<input type="hidden" class="form-control" name="item_id_list[]" value="'+item_id+'">'+
											'<i class="icon icon-close" style="font-size: 30px; color: red; margin-top: 6px;" onclick="remove_item('+item_id+')"></i>'+
										'</div>'+
									'</div>';
	
				// alert(append_body);
				// alert(min_price+' - '+max_price);
				$('#items_body').append(append_body);
				$('#items-modal').modal('hide');
				calculate_price();
			}else{
				toastr["error"]("You have already added this item");
			}
		});
	</script>
	<script>
		$('#meal_cat').on('change', function(e){
			var selected = $(this).find('option:selected');
       		var cat_price = selected.data('price'); 
			$('#cat_price').val(cat_price);
			calculate_price();
		});
	</script>
	<script>
		function remove_item(id){  
			// alert(item_ids);
			item_ids = jQuery.grep(item_ids, function(value) {
				return value != id;
			});
			// alert(item_ids);
			$('#row_id_'+id).remove();
			calculate_price();
		}
	</script>
	<script>
		$('#add_meal_form').on('submit', function(e){
			e.preventDefault();
			let meal_qty = parseInt($('#meal_qty').val());
			if (item_ids.length < 1) {
				toastr["error"]("please select at least 1 item for this meal");
			}else if(meal_qty < 1){
				toastr["error"]("Invalid Quantity");
			}else{
				$.ajax({
					type: 'POST',
					url: '<?=base_url()?>save_meal_pack_ajax',
					data: new FormData(this),
					contentType: false,
					cache: false,
					processData:false,
					success: function (result){  
						let res = $.parseJSON(result);
						if (res.status == 'success') {
							toastr["success"](res.message);
							window.open("<?php echo site_url('view_meal/'); ?>" + btoa(res.data), '_self');
						}else{
							toastr["error"](res.message);
						}
					},
					error: function (result){  
	
					}
				});
			}

		});
	</script>
	<script>
		function calculate_price(){
			let total = 0;
			let prices = $("input[name='item_list[]']").map(function(){
				total = parseFloat(total) + parseFloat($(this).val());
				return $(this).val();
			}).get();

			let cat_price = parseFloat($('#cat_price').val());
			$('#detail_cat_price').text("Rs."+cat_price);
			$('#detail_min_price').text("Rs."+cat_price);
			$('#detail_max_price').text("Rs."+(cat_price + parseFloat(total)));
			$('#detail_items').text(prices.length);
			
			console.log(prices);
			// alert(total);
			// detail_cat_price
		}
	</script>
	<script>
		function update_price(id){  
			let new_price = $('#price_input_'+id).val();
			let min_price = parseInt($('#price_input_'+id).attr('min'));
			let max_price = parseInt($('#price_input_'+id).attr('max'));
			// alert(min_price+' - '+max_price);

			if (new_price > max_price || new_price < min_price) {
				toastr["error"]("Please enter price between (Rs."+min_price+" - Rs."+max_price+")");
				$('#price_input_'+id).val(min_price);
				calculate_price();
			}else{
				calculate_price();
			}
			// alert(min_price+' - '+max_price);
			// alert(new_price);
		}
	</script>

















	<script>
		function getMeal(){  
			// alert('hi');
			let meal_name = '';
			let cat = '';

			let status = '';
			let order_body = '';
			$('#order_body').empty();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>get_chef_meal_ajax',
				data: 'meal_name='+meal_name+'&cat='+cat,
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						for (let i = 0; i < res.message.length; i++) {
							// alert(status);
							order_body += '<tr>'+
												'<td>'+(i+1)+'</td>'+
												'<td><img src="<?=base_url()?>assets/images/'+res.message[i]['meal_image']+'" width="32px" onclick="change_image('+res.message[i]['user_meal_id']+')"></td>'+
												'<td>'+res.message[i]['meal_name']+'</td>'+
												'<td>'+res.message[i]['category']+'</td>'+
												'<td><span class="color">Rs.'+res.message[i]['min_price']+' - Rs.'+res.message[i]['max_price']+'</span></td>'+
												'<td>'+res.message[i]['qty']+'</a></td>'+
												'<td>'+(res.message[i]['qty_ordered'])+'</a></td>'+
												'<td>'+res.message[i]['user_meal_date']+'</td>'+
												'<td><a href="javascript:open_meal('+res.message[i]['user_meal_id']+')" class="pull-left">View Details</a></td>'+
											'</tr>';
						}
						$('#order_body').append(order_body);
					}
				},
				error: function (result){  

				}
			});
		}
	</script>
	<script>
		function open_meal(id){  
			// alert(id);
			window.open("<?php echo site_url('view_meal/'); ?>" + btoa(id), '_blank');
		}
	</script>
	<script>
		function change_image(id) {
			alert(id);
			
		}
	</script>
</body>

</html>