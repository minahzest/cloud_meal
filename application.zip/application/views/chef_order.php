<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CloudMeal | Chef Panel</title>
	<meta name="author" content="BigSteps">
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
	<link rel="shortcut icon" href="<?=base_url()?>assets/images/logo.png"> 
	<!-- Vendor -->
	<link href="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/slick/slick.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/swiper/swiper.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/nouislider/nouislider.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">

	<!-- Custom -->
	<link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/megamenu.css" rel="stylesheet">

	<!--toastr-->
	<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">

	<!-- Color Schemes -->
	<!-- your style-color.css here  -->


	<!-- Icon Font -->
	<link href="<?=base_url()?>assets/fonts/icomoon-reg/style.css" rel="stylesheet">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

	<style>
		.active-nav{
			width: 100%;
			background-color: #494e62;
			left: 0;
			background-color: #494e62;
			left: -4px;
			border-right: 4px solid #f82e56;
		}
		ul.category-list li {
			position: relative;
			display: block;
			padding: 11px 0;
			font-size: 16px;
			line-height: 1.25em;
			font-weight: 500;
			color: #333745;
			text-decoration: none;
		}
		
	</style>
</head>

<body class="fullwidth open-panel" onload="getOrder()">
	<div id="wrapper">
		<!-- Page -->
		<div class="page-wrapper">
			<!-- Sidebar -->
			<div class="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li> <a href="<?=base_url()?>chef-account">HOME</a> </li>
					<li class="active-nav"> <a href="<?=base_url()?>chef-order" class="active">Orders</a> </li>
					<li> <a href="<?=base_url()?>chef-meals">My Meals</a> </li>
					<li> <a href="<?=base_url()?>chef-logout">LOGOUT</a> </li>
				</ul>
			</div>
			<!-- /Sidebar -->
			<!--header-->
			<header class="page-header variant-1 fullboxed sticky smart">
				<div class="navbar" style="margin: 0 0 0 0;">
					<div class="container">
						<div class="header-logo">
							<span style="font-size: 24px;font-family: 'Oswald', sans-serif; font-weight: 400; text-transform: uppercase; padding: 0 0 2px; margin: 0 0 30px 0; color: #333745;">Hi, <?=$this->session->userdata('user_logged_in')['user_name']?></span>
						</div>
					</div>
				</div>
			</header>
			<!--header end-->
			<!-- Page Content -->
			<main class="page-main">
				<div class="block">
					<div class="container" style="margin-top: 60px;">
						<div class="page-title">
							<div class="title">
								<!-- <h1>My Dashboard</h1> -->
							</div>
						</div>
						<div class="row" style="padding: 20px;">
							<div class="col-md-12">
								<a href="javascript:reset()" class="btn btn-invert pull-right">Reset</a>
								<a href="javascript:search()" class="btn pull-right" style="margin-left: 5px;" id="filter">Search</a>
								<input type="date" class="form-control pull-right" name="filter_date" id="filter_date" style="width: 20%; margin-left: 5px;">
								<input type="text" class="form-control pull-right" name="filter_order_code" id="filter_order_code" style="width: 20%;" placeholder="Order Code">
								<h2>Order History</h2>
								<div class="row">
									<div class="col-md-9">
										<div class="table-responsive">
											<table class="table table-bordered table-striped">
												<thead>
													<tr>
														<th scope="col"># </th>
														<th scope="col">Order Code</th>
														<th scope="col">Order Date </th>
														<th scope="col">Total Price</th>
														<th scope="col">Cook</th>
														<th scope="col">Status</th>
													</tr>
												</thead>
												<tbody id="order_body">
													
												</tbody>
											</table>
											<!-- <pre> -->
												<?php 
													// print_r($orders);
												?>
											<!-- </pre> -->
										</div>
									</div>
									<div class="col-md-3">
										<h2>Orders Statistics</h2>
										<div class="">
											<ul class="category-list">
												<li>New Order<span class="pull-right" style="font-weight: 100;" id="new_order_count">0</span></li>
												<li>Total Order<span class="pull-right" style="font-weight: 100;" id="total_order_count">0</span></li>
												<li>Total Income<span class="pull-right" style="font-weight: 100;" id="total_order_amount">Rs.0</span></li>
												<!-- <li>My Order History</li>
												<li>Logout</li> -->
											</ul>
										</div>
										<div class="divider divider-lg"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- /Page Content -->
			<!-- Footer -->
			<footer class="page-footer variant1">
				<div class="container">
					<div class="after-footer">
						<div class="footer-copyright text-center"> © 2016 Demo Store. All Rights Reserved. </div>
					</div>
				</div>
			</footer>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- Modal -->
	<div class="modal fade" id="status-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title" id="meal_name">Update Order status</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="statusForm">
								<input type="hidden" name="order_id" id="order_id">
								<div id="item_body">
									<label>Status<span class="required">*</span></label>
									<!-- <input type="email" class="form-control input-lg" name="email" id="modalloginemail" placeholder="Email Address" data-error="Please enter a valid email address."> -->
									<select class="form-control" name="stat-update" id="stat-update">
										<option value="1">Order Placed</option>
										<option value="2">Cooking</option>
										<option value="3">Packed</option>
										<option value="4">Ready To Pick</option>
										<option value="5">Delivered</option>
										<option value="6" disabled>Cancelled</option>
									</select>
									<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="update_btn">Update</button>
								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/swiper/swiper.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/slick/slick.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/parallax/parallax.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/isotope/isotope.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/countdown/jquery.countdown.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/nouislider/nouislider.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/ez-plus/jquery.ez-plus.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/tocca/tocca.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/scrollLock/jquery-scrollLock.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/darktooltip/dist/jquery.darktooltip.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/instafeed/instafeed.min.js"></script>
	<script src="<?=base_url()?>assets/js/megamenu.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>

		function getOrder(){  
			let order_code = $('#filter_order_code').val();
			let filter_date = $('#filter_date').val();

			$('#new_order_count').text('0')
			$('#total_order_count').text('0')
			$('#total_order_amount').text('Rs.0')

			let status = '';
			let order_body = '';
			let total_amount = 0;
			let total_order = 0;
			let new_order = 0;
			$('#order_body').empty();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>get_chef_order_ajax',
				data: 'search='+order_code+'&date='+filter_date,
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						for (let i = 0; i < res.message.length; i++) {
							switch (res.message[i]['order_status']) {
								case '1':
									status = 'Order Placed';
									new_order++;
									break;
								case '2':
									status = 'Cooking';
									break;
								case '3':
									status = 'Packed';
									break;
								case '4':
									status = 'Ready to Pick';
									break;
								case '5':
									status = 'Delivered';
									break;
								case '6':
									status = 'Cancelled';
									break;
							}
							// alert(status);
							order_body += '<tr id="order_row_'+res.message[i]['order_id']+'" dat-stat="'+res.message[i]['order_status']+'">'+
												'<td>'+(i+1)+'</td>'+
												'<td><b>'+res.message[i]['order_code']+'</b> <a href="javascript:open_order('+res.message[i]['order_id']+')" class="pull-right">Open Order</a></td>'+
												'<td>'+res.message[i]['order_date']+'</td>'+
												'<td><span class="color">Rs.'+res.message[i]['order_amount']+'</span></td>'+
												'<td>'+res.message[i]['f_name']+' '+res.message[i]['l_name']+'</td>'+
												'<td><a href="javascript:update_status('+res.message[i]['order_id']+')" class="btn btn-sm btn-alt" id="order_stat_'+res.message[i]['order_id']+'">'+status+'</a></td>'+
											'</tr>';

							total_amount = parseFloat(total_amount) + parseFloat(res.message[i]['order_amount']);
							total_order++;
						}
						$('#order_body').append(order_body);
						$('#new_order_count').text(new_order);
						$('#total_order_count').text(total_order);
						$('#total_order_amount').text('Rs.'+total_amount);
					}
				},
				error: function (result){  

				}
			});
		}
		function search() {
			getOrder();
		}
		function reset(){
			$('#filter_order_code').val('');
			$('#filter_date').val('');
			getOrder();
		}
	</script>
	<script>
		function open_order(id){  
			// alert(id);
			window.open("<?php echo site_url('chef_view_order/'); ?>" + btoa(id), '_blank');
		}
	</script>
	<script>
		function update_status(id){  
			let cur_stat = $('#order_row_'+id).attr('dat-stat');
			$('#stat-update').val(cur_stat);
			$('#order_id').val(id);
			$('#stat-update').attr('disabled', false);
			$('#update_btn').attr('disabled', false);
			if (cur_stat == 6) {
				$('#stat-update').attr('disabled', true);
				$('#update_btn').attr('disabled', true);
			}
			$('#status-modal').modal('show');
		}
	</script>
	<script>
		// status-modal
		$('#statusForm').on('submit', function (e) {  
			e.preventDefault();
			let order_id = $('#order_id').val();
			let order_status = $('#stat-update').val();
			let order_text = $( "#stat-update option:selected" ).text();

			// alert($('#statusForm').serialize());
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>chef_update_order_ajax',
				data: $('#statusForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
	                    toastr["success"](res.message);
						$('#status-modal').modal('hide');
						$('#order_stat_'+order_id).text(order_text);
						$('#order_row_'+order_id).attr('dat-stat', order_status);
						
					}else{
	                    toastr["error"](res.message);
					}
				},
				error: function (result){  

				}
			});
		});
	</script>
</body>

</html>