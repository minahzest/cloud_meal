<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('includes/head'); ?>
</head>

<body class="boxed" onload="getOrder()">
	<div id="wrapper">
		<div class="page-wrapper">
    		<?php $this->load->view('includes/header'); ?>
			<main class="page-main">
				<div class="block">
					<div class="container">
						<div class="page-title">
							<div class="title">
								<div class="row">
									<div class="col-md-6">
										<h1>My Dashboard</h1>
									</div>
									<div class="col-md-6">
										<a href="javascript:recharge()" style="float: right;" class="btn btn-lg btn-invert">Recharge Wallet</a>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-3">
								<div class="">
									<ul class="category-list">
										<li><a href="<?=base_url()?>acc-details">Account Details</a></li>
										<li class="active"><a href="<?=base_url()?>acc-wallet">My Wallet</a></li>
										<li><a href="<?=base_url()?>account">My Order History</a></li>
										<li><a href="<?=base_url()?>logout">Logout</a></li>
									</ul>
								</div>
								<div class="divider divider-lg"></div>
							</div>
							<div class="col-md-9">
								<a href="<?=base_url()?>acc-wallet" style="float: right;" class="btn btn-alt pull-right">Wallet Inflows (Debit)</a>
								<h2>Wallet Outflows (Credit)</h2>

								<div class="table-responsive">
									<table class="table table-bordered table-striped">
										<thead>
											<tr>
												<th scope="col"># </th>
												<th scope="col">Referance</th>
												<th scope="col">Date </th>
												<th scope="col">Order</th>
												<th scope="col">Amount</th>
												<th scope="col">Chef</th>
											</tr>
										</thead>
										<!-- <pre> -->
											<?php 
												// print_r($credits);
											?>
										<!-- </pre> -->
										<tbody id="order_body">
											<?php 
												foreach ($credits as $key => $credit) {
											?>
												<tr>
													<td><?=($key+1)?></td>
													<td><b><?=$credit->credit_referance?></b></td>
													<td><?=$credit->credit_date?></td>
													<td><?=$credit->order_code?></td>
													<td><span class="color"><?=$credit->amount?></span></td>
													<td><a href="#" class="btn btn-sm"><?=$credit->f_name.' '.$credit->l_name?></a></td>
												</tr>
											<?php 
												}
											?>
										</tbody>
									</table>
									<!-- <pre> -->
										<?php 
											// print_r($orders);
										?>
									<!-- </pre> -->
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- Footer -->
    		<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- Recharge Modal -->
	<div class="modal fade" id="recharge-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-header">
					<h2 class="modal-title">Recharge Wallet</h2>
				</div>
				<div class="modal-body">
					<div class="row" style="margin-top: 30px; margin-bottom: 30px;">
						<div class="col-lg-12 col-md-12">
							<form action="#" id="rechargeForm">
								<div id="item_body">
									<ul>
										<li>this recharge will be debited to account.</li>
										<li>Feel hassle free recharge now make more purchase later.</li>
										<li>Please you check your order amount before recharge your wallet.</li>
									</ul>
									<label>Recharge Amount<span class="required"></span></label>
									<input type="number" class="form-control input" name="recharge_amount" id="recharge_amount" min="1" required>
									<div class="row">
										<div class="col-md-6">
											<button type="button" class="btn btn-invert" data-dismiss="modal" style="width: 100%;" aria-label="Close">No</button>
										</div>
										<div class="col-md-6">
											<button type="submit" class="btn btn-primary submit" style="width: 100%;" id="cancel_btn">Yes! Cancel</button>
										</div>
									</div>

								</div>
							</form>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-lg-6 col-md-6">

						</div>
						<div class="col-lg-6 col-md-6">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		function recharge(){  
			$('#recharge-modal').modal('show');
		}
		$('#rechargeForm').on('submit', function (e){  
			e.preventDefault();
			$.ajax({
				type: "POST",
				url: "<?=base_url()?>recharge_wallet_ajax",
				data: $('#rechargeForm').serialize(),
				success: function (result){  
					let res = $.parseJSON(result);
						$('#cancel-modal').modal('hide');
						if (res.status == 'success') {
							toastr["success"](res.message);
							// setTimeout(function() { 
								$('#recharge-modal').modal('hide');
								window.location.reload();
							// }, 2000);	
						}else{
							toastr["error"](res.message);

						}
				},
				error: function (result){  

				}
			});
		});
	</script>
</body>

</html>