<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('includes/head'); ?>
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
    		<?php $this->load->view('includes/header'); ?>
			<main class="page-main">
				<div class="block">
					<div class="container">
						<pre>
						<?php
						// outputs the username that owns the running php/httpd process
						// (on a system with the "whoami" executable in the path)
						// $output=null;
						// $retval=null;
						// exec('whoami', $output_0, $retval_0);
						// // exec('mkdir cmnd', $output_1, $retval_1);
						// exec('cd cmnd && dir', $output_2, $retval_2);
						// // exec('dir', $output_3, $retval_2);
						// echo "Returned with status $retval and output:\n";
						// print_r($output_2);

						?>

						<div class="row">
							<div class="col-sm-4 pt-4" style="padding: 15px;">
								<div class="box style2 bgcolor1 ">
									<h2>Set one's heart</h3>
									<span>Experience your favourite chef's dishes</span>
								</div>
							</div>
							<div class="col-sm-4" style="padding-top: 15px;">
								<div class="">
									<img src="https://cn-geo1.uber.com/image-proc/resize/eats/format=webp/width=550/height=440/quality=70/srcb64=aHR0cHM6Ly9kMWcxZjI1dG44bTJlNi5jbG91ZGZyb250Lm5ldC9iZmQzZTE4MC04OGY4LTRmZDgtOGI1MS00YWEwOWYyZTc0YzYuanBn" width="100%" style="border-radius: 10px;">
								</div>
							</div>
							<div class="col-sm-4" style="padding-top: 15px;">
								<div class="">
									<img src="https://cn-geo1.uber.com/image-proc/resize/eats/format=webp/width=550/height=440/quality=70/srcb64=aHR0cHM6Ly9kMWcxZjI1dG44bTJlNi5jbG91ZGZyb250Lm5ldC9lODEyZDhmYy1jOGJhLTQ3NzAtODY3My0zOTY2NTFlZDA0OTYuanBn" width="100%" style="border-radius: 10px;">
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="text-center bottom-space">
							<h1 class="size-lg no-padding">WELCOME TO <span class="logo-font custom-color">cloudMeal</span> Kitchen</h1>
							<div class="line-divider"></div>
							<p class="custom-color-alt"><span class="theme-color">cloudMeal</span> is your go-to food delivery service, bringing your favorite local cuisines right to your doorstep. We believe in delivering not just food but delightful experiences to your table, whenever and wherever you want.
								<!-- <br> Vim ei oblique tacimates, usu cu iudico graeco. Graeci eripuit inimicus vel eu, eu mel unum laoreet splendide, cu integre apeirian has. -->
							</p>
						</div>
					</div>
				</div>

				<div class="block bottom-space">
					<div class="container">
						<div class="row">
							<div class="col-sm-7">
								<div class="">
									<img src="<?=base_url()?>assets/images/16485210_5739256.jpg" width="100%" style="border-radius: 10px;">
								</div>
							</div>
							<div class="col-sm-5">
								<div>
									<h2><strong>Customize Your Order</strong></h2>
									<div>
										<span>At <span class="theme-color">cloudMeal</span>, we understand that every palate is unique. That's why we offer you the flexibility to tailor your order to suit your tastes and preferences. Personalize your meal just the way you like it!</span><br>
									</div>
									<ul>
										<li><h3><strong>Select Your Dish:</strong></h3></li>
										<span>Begin by choosing your preferred dish from the menu of the restaurant you've selected.</span><br>

										<li><h3><strong>Add-ons / Remove:</strong></h3></li>
										<span>Have specific dietary preferences or allergies? No problem! Remove or add ingredients according to your liking. no onions? Customize it just the way you want.</span><br>

										<li><h3><strong>Custom Pricings:</strong></h3></li>
										<span>Remove or add ingredients according to your liking, the pricings will be alter.</span><br>

										<li><h3><strong>Place Your Order:</strong></h3></li>
										<span>Add your customized the dished cart and place the order to be processed.</span><br>

									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="block">
					<div class="container">
						<div class="text-center bottom-space">
							<h1 class="size-lg no-padding">Become a <span class="theme-color">cloudMeal</span> Chef</h1>
							<div class="line-divider"></div>
							<p class="custom-color-alt">Register a chef and start selling your specialized meal with <span class="theme-color">cloudMeal</span>.
							</p>
						</div>
					</div>
				</div>

				<div class="block bottom-space">
					<div class="container">
						<div class="row">
							<div class="col-sm-5">
								<div>
									<h2><strong>Become <span class="theme-color">cloudMeal</span> Chef</strong></h2>
									<div>
										<span>Do you enjoy cooking a lot and want to show off your talents to a larger audience? Share your passion for cooking with our expanding community of food lovers by becoming a Chef at <span class="theme-color">cloudMeal</span> You may turn your passion into a career as a Chef on our platform and create your own culinary empire.</span><br>
									</div>
									<ul>
										<li><h3><strong>Sign Up:</strong></h3></li>
										<span>Register with <span class="theme-color">cloudMeal</span> to create your Chef profile.</span><br>

										<li><h3><strong>Menu Creation:</strong></h3></li>
										<span>Create a special menu with your signature foods and Based on your daily expectations, prepare a second lunch in advance.</span><br>

										<li><h3><strong>Set Availability:</strong></h3></li>
										<span>Choose your availability and set available quantity. Delight customers with your culinary magic.</span><br>

										<li><h3><strong>Start Cooking:</strong></h3></li>
										<span>Once your profile is created, you may begin accepting orders and preparing delectable meals for our clients.</span><br>
									</ul>
								</div>
							</div>
							<div class="col-sm-7">
								<div class="">
									<img src="<?=base_url()?>assets/images/18407463_5995729.jpg" width="100%" style="border-radius: 10px;">
								</div>
							</div>
						</div>
					</div>
				</div>
			</main>
			<?php $this->load->view('includes/footer'); ?>	

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>


</body>

</html>