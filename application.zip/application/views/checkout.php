<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Head -->
	<?php $this->load->view('includes/head'); ?>
	<!-- /Head -->
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
			<!-- Header -->
			<?php $this->load->view('includes/header'); ?>
			<!-- /Header -->
			<main class="page-main">
				<div class="block">
					<div class="container">
						<div class="row">
							<div class="col-md-6">
								<div class="clearfix"></div>
								<h2>Order Notes</h2>
								<form class="white" action="#">
									<label>Notes about your order, e.g. special notes for order</label>
									<textarea class="form-control" id="order_note" name="order_note"></textarea>
								</form>
								<h2>Order Pickup</h2>
								<p>How to collect your Meal pack from Chef/Cook</p>
								<form class="white" action="#">
									<div class="radioset">
										<span class="outer"><span class="inner"></span></span><b>Order Placed</b> - Under this step You can cancel your order until status update<br>
										<span class="outer"><span class="inner"></span></span><b>Ready To Pick</b> - When order is in this stage you can collect from chef address
									</div>
								</form>
							</div>
							<div class="col-md-6">
								<h2>Your Order</h2>
								<div class="cart-table cart-table--sm">
									<div class="table-header">
										<div class="photo">
											Product Image
										</div>
										<div class="name">
											Product Name
										</div>
										<div class="price">
											Unit Price
										</div>
										<div class="qty">
											Qty
										</div>
										<div class="subtotal">
											Subtotal
										</div>
									</div>
									<?php
										$total = 0;
										foreach ($this->cart->contents() as $key => $value) {
											// echo "<pre>";
											// print_r($value);
											// echo "</pre>";
									?>
									<div class="table-row" id="attrs_div_<?=$value['rowid']?>" style="display: none;">
										<div class="photo">
											<!-- <a href="product.html"><img src="<?=base_url()?>assets/images/<?=$value['options']['image']?>" alt=""></a> -->
										</div>
										<div class="name" id="item_name_<?=$value['rowid']?>" style="font-weight: 100;">
											
										</div>
										<div class="price" id="item_price_<?=$value['rowid']?>" style="font-weight: 100;">
											
										</div>
										<div class="qty">
											
										</div>
										<div class="subtotal">

										</div>
									</div>

									<div class="table-row">
										<div class="photo">
											<a href="product.html"><img src="<?=PHOTO_DOMAIN.$value['options']['image']?>" alt=""></a>
										</div>
										<div class="name">
											<input type="hidden" id="meal_price_<?=$value['rowid']?>" value="<?=$value['price']?>">
											<input type="hidden" id="attrs_<?=$value['rowid']?>" value="<?=$value['options']['attributes']?>">
											<a href="javascript:openItem('<?=$value['rowid']?>')"><?=$value['name']?></a>
										</div>
										<div class="price">
											Rs.<?=$value['price']?>
										</div>
										<div class="qty">
											<?=$value['qty']?>
										</div>
										<div class="subtotal">
											Rs.<?=$value['subtotal']?>
										</div>
									</div>
									<?php 
										$total = $total + $value['subtotal'];
										} 
									?>
									<input type="hidden" id="cart_total_price" value="<?=$total?>">
								</div>
								<table class="total-price" style="max-width: 100%;">
									<tr>
										<td>Subtotal</td>
										<td>Rs.<?=$total?></td>
									</tr>
									<tr class="total">
										<td>Grand Total</td>
										<td>Rs.<?=$total?></td>
									</tr>
								</table>
								<div>
									<button class="btn" style="width: 100%;" id="place_order">PLACE ORDER</button>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- Footer -->
			<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
	<script>
		function openItem(id){
			let attr_array = [];
			attr_array = $('#attrs_'+id).val();
			let price = $('#meal_price_'+id).val();
			attr_array = attr_array.split(',');
			console.log(typeof attr_array);
			let item_body_name = '<span>Base Price fo the Meal</span><br>';
			let item_body_price = '';
			let total = 0;

			$('#item_name_'+id).empty();
			$('#item_price_'+id).empty();
			// alert(attr_array);
			if (attr_array != '') {
				$.ajax({
					type: 'POST',
					url: '<?=base_url()?>get_meal_item_ajax',
					data: 'ids='+attr_array,
					success: function (result){  
						let res = $.parseJSON(result);
						console.log(res.message);
						for (let i = 0; i < res.message.length; i++) {
							item_body_name += '<span>'+res.message[i]['item_name']+'</span><br>';
							item_body_price += '<span>Rs.'+res.message[i]['item_price']+'</span><br>';
							total = total + parseInt(res.message[i]['item_price']);
						}
						// $('#attrs_div_'+id).css('display','block');
						let base_price = parseInt(price)-parseInt(total);
						// alert(total);
						$('#item_name_'+id).html(item_body_name);
						$('#item_price_'+id).html('<span>Rs.'+base_price+'</span><br>'+item_body_price);
						$('#attrs_div_'+id).show();
						
					},
					error: function (result){  
	
					}
				});
			}
		}
	</script>
	<script>
		$('#place_order').on('click', function(e){  
			// alert($('#wallet_balance').val()+' - '+$('#cart_total_price').val());
			let wallet_balance = parseFloat($('#wallet_balance').val());
			let cart_total = parseFloat($('#cart_total_price').val());
			if (wallet_balance < cart_total) {
				toastr["error"]('You are running out of balance in your wallet');
			}else{
				$.ajax({
					type: 'POST',
					url: '<?=base_url()?>place_order_ajax',
					data: 'order_note='+$('#order_note').val(),
					success: function(result){  
						let res = $.parseJSON(result);
						if (res.status == 'success') {
							toastr["success"](res.message);
							setTimeout(function() { 
								window.location.href = "<?=base_url()?>cart";
							}, 2000);
							
						}else{
							toastr["error"](res.message);

						}

					},
					error: function(result){  

					}
				});
			}
		});
	</script>
</body>

</html>