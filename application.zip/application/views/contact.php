<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Head -->
		<?php $this->load->view('includes/head'); ?>
	<!-- /Head -->
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
			<!-- Header -->
    		<?php $this->load->view('includes/header'); ?>
			<!-- /Header -->
			<main class="page-main">
				<div class="block">
					<div class="container">
						<ul class="breadcrumbs">
							<li><a href="index.html"><i class="icon icon-home"></i></a></li>
							<li>/<span>Contact</span></li>
						</ul>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="row">
							<div class="col-sm-5">
								<div class="text-wrapper">
									<h2>Branch address</h2>
									<div class="address-block">
										<h3>ADDRESS 1</h3>
										<ul class="simple-list">
											<li><i class="icon icon-location-pin"></i>Adress: 0071 jayasekara mw, colombo 05, Sri Lanka</li>
											<li><i class="icon icon-phone"></i>Phone: 077123456789</li>
											<li><i class="icon icon-phone"></i>Fax: 1234567894534</li>
											<li><i class="icon icon-close-envelope"></i>Email: <a href="mailto:support@seiko.com">colombo@cloudmeal.com</a></li>
										</ul>
									</div>
									<div class="address-block last">
										<h3>ADDRESS 2</h3>
										<ul class="simple-list">
											<li><i class="icon icon-location-pin"></i>Adress: 123 junaid Road, Thihariya, Sri Lanka</li>
											<li><i class="icon icon-phone"></i>Phone: 077123456789</li>
											<li><i class="icon icon-phone"></i>Fax: 1234567891234</li>
											<li><i class="icon icon-close-envelope"></i>Email: <a href="mailto:support@seiko.com">gampaha@cloudmeal.com</a></li>
										</ul>
									</div>
								</div>
							</div>
							<div class="col-sm-7">
								<div class="text-wrapper">
									<h2>Contact Information</h2>
									<p id="contactFormSuccess">Your email was send successfully!</p>
									<p id="contactFormError">Error, try to submit this form again.</p>
									<form id="contactform" class="contact-form white" name="contactform" method="post">
										<label>Name<span class="required">*</span></label>
										<input type="text" class="form-control input-lg" name="name">
										<label>E-mail<span class="required">*</span></label>
										<input type="text" class="form-control input-lg" name="email">
										<label>Comment<span class="required">*</span></label>
										<textarea class="form-control input-lg" name="message"></textarea>
										<div>
											<button class="btn btn-lg" id="submit">Submit</button>
										</div>
										<div class="required-text">* Required Fields</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="block fullwidth">
					<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBSK_nLPUyr7NGihR1MkH5z1COHYFI9SKs"></script>
					<script type="text/javascript">
						// When the window has finished loading create our google map below
						google.maps.event.addDomListener(window, 'load', init);

						function init() {
							// Basic options for a simple Google Map
							// For more options see: https://developers.google.com/maps/documentation/javascript/reference#MapOptions
							var mapOptions = {
								zoom: 14,
								scrollwheel: false,
								center: new google.maps.LatLng(6.927079, 79.861244, 13.75), // Seiko

								// How you would like to style the map. 
								// This is where you would paste any style found on Snazzy Maps.
								styles: [{
									"featureType": "administrative",
									"elementType": "labels.text.fill",
									"stylers": [{
										"color": "#444444"
									}]
								}, {
									"featureType": "landscape",
									"elementType": "all",
									"stylers": [{
										"color": "#f2f2f2"
									}]
								}, {
									"featureType": "poi",
									"elementType": "all",
									"stylers": [{
										"visibility": "off"
									}]
								}, {
									"featureType": "road",
									"elementType": "all",
									"stylers": [{
										"saturation": -100
									}, {
										"lightness": 45
									}]
								}, {
									"featureType": "road.highway",
									"elementType": "all",
									"stylers": [{
										"visibility": "simplified"
									}]
								}, {
									"featureType": "road.highway",
									"elementType": "geometry.fill",
									"stylers": [{
										"color": "#ffffff"
									}]
								}, {
									"featureType": "road.arterial",
									"elementType": "labels.icon",
									"stylers": [{
										"visibility": "off"
									}]
								}, {
									"featureType": "transit",
									"elementType": "all",
									"stylers": [{
										"visibility": "off"
									}]
								}, {
									"featureType": "water",
									"elementType": "all",
									"stylers": [{
										"color": "#dde6e8"
									}, {
										"visibility": "on"
									}]
								}]
							};

							// Get the HTML DOM element that will contain your map 
							// We are using a div with id="map" seen below in the <body>
							var mapElement = document.getElementById('googleMap');

							// Create the Google Map using our element and options defined above
							var map = new google.maps.Map(mapElement, mapOptions);

							// Let's also add a marker while we're at it
							var marker = new google.maps.Marker({
								position: new google.maps.LatLng(64.127182, -21.817184),
								map: map,
								title: 'Seiko'
							});
						}
					</script>
					<!-- The element that will contain our Google Map. This is used in both the Javascript and CSS above. -->
					<div id="googleMap" class="google-map"></div>
				</div>
			</main>
			<!-- Footer -->
    		<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- jQuery Scripts  -->
	<script src="js/vendor/jquery/jquery.js"></script>
	<script src="js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="js/vendor/swiper/swiper.min.js"></script>
	<script src="js/vendor/slick/slick.min.js"></script>
	<script src="js/vendor/parallax/parallax.js"></script>
	<script src="js/vendor/isotope/isotope.pkgd.min.js"></script>
	<script src="js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
	<script src="js/vendor/countdown/jquery.countdown.min.js"></script>
	<script src="js/vendor/nouislider/nouislider.min.js"></script>
	<script src="js/vendor/ez-plus/jquery.ez-plus.js"></script>
	<script src="js/vendor/tocca/tocca.min.js"></script>
	<script src="js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="js/vendor/scrollLock/jquery-scrollLock.min.js"></script>
	<script src="js/vendor/darktooltip/dist/jquery.darktooltip.js"></script>
	<script src="js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
	<script src="js/vendor/instafeed/instafeed.min.js"></script>
	<script src="js/megamenu.min.js"></script>
	<script src="js/app.js"></script>
	<!-- jQuery form validation -->
	<script src="js/vendor/form/jquery.form.js"></script>
	<script src="js/vendor/form/jquery.validate.min.js"></script>
	<script>
		// Contact page form
		$(function () {
			$('#contactform').validate({
				rules: {
					name: {
						required: true,
						minlength: 3
					},
					message: {
						required: true,
						minlength: 15
					},
					email: {
						required: true,
						email: true
					}

				},
				messages: {
					name: {
						required: "Please enter your name",
						minlength: "Your name must consist of at least 3 characters"
					},
					message: {
						required: "Please enter your message",
						minlength: "Your message must consist of at least 15 characters"
					},
					email: {
						required: "Please enter your email"
					}
				},
				submitHandler: function (form) {
					$(form).ajaxSubmit({
						type: "POST",
						data: $(form).serialize(),
						url: "contact.php",
						success: function () {
							$('#contactFormSuccess').fadeIn();
							$('#contactFormError').fadeOut();
							$('#contactform').trigger('reset');
						},
						error: function () {
							$('#contactFormSuccess').fadeOut();
							$('#contactFormError').fadeIn();
						}
					});
				}
			});
		});
	</script>
	</div>
</body>

</html>