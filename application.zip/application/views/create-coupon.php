<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Head -->
	<?php $this->load->view('includes/head'); ?>
	<!-- /Head -->
    <link rel="stylesheet" href="<?=base_url()?>assets/css/main.css" type="text/css" />
	<style>
		.link-active{
			background-color: #494e62;
			color: #ffffff;
			left: -4px;
			border-right: 4px solid #f82e56;
			width: 100%;
		}
		.color-box{
			float: right;
			height: 25px;
			width: 25px;
			border: 1px solid #e5e5e5;
			border-radius: 5px;
		}
	</style>
	<style>
		.wheel-container {
			position: relative;
		}

		.wheel {
			width: 200px;
			height: 200px;
			border-radius: 50%;
			background-color: #ffd700; /* Yellow color */
			position: relative;
			overflow: hidden;
		}

		.wheel-section {
			position: absolute;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
			clip-path: polygon(50% 50%, 100% 0, 100% 100%);
			transform: rotate(var(--deg));
			background-color: #ff4500; /* Orange color */
		}

		.spin-button {
			position: absolute;
			bottom: 10px;
			left: 50%;
			transform: translateX(-50%);
			padding: 10px 20px;
			background-color: #4caf50; /* Green color */
			color: #fff;
			border: none;
			cursor: pointer;
			font-size: 16px;
		}
	</style>
	<style>
		#toggle {
			display: none;
		}

		.toggle-btn {
			/* background-color: #3498db; */
			/* color: #fff; */
			/* padding: 10px; */
			cursor: pointer;
			/* border-radius: 5px; */
			font-size: 13px;
			line-height: 1.5em;
			font-family: 'Raleway', sans-serif;
			font-weight: 700;
			text-transform: none;
			padding: 0;
			margin: 0 0 8px 0;
			color: #333745;
		}

		.content {
			height: 0;
			overflow: hidden;
			transition: height 0.3s ease-in-out;
		}

		#toggle:checked + .toggle-btn + .content {
			height: 350px; /* Adjust the height based on your content */
		}
		#toggle1 {
			display: none;
		}

		.toggle-btn {
			/* background-color: #3498db; */
			/* color: #fff; */
			/* padding: 10px; */
			cursor: pointer;
			/* border-radius: 5px; */
			font-size: 13px;
			line-height: 1.5em;
			font-family: 'Raleway', sans-serif;
			font-weight: 700;
			text-transform: none;
			padding: 0;
			margin: 0 0 8px 0;
			color: #333745;
		}

		.content1 {
			height: 0;
			overflow: hidden;
			transition: height 0.3s ease-in-out;
		}

		#toggle1:checked + .toggle-btn + .content1 {
			height: 350px; /* Adjust the height based on your content */
		}
	</style>
</head>

<body class="fullwidth open-panel" style="background-color: gainsboro;">
	<!-- Loader -->
	<!-- /Loader -->
	<div id="wrapper">
		<!-- Page -->
		<div class="page-wrapper">
			<!-- Header -->
			<!-- /Header -->
			<!-- Sidebar -->
			<div class="sidebar-wrapper">
				<!-- <div class="sidebar-top"><a href="#" class="slidepanel-toggle"><i class="icon icon-left-arrow-circular"></i></a></div> -->
				<ul class="sidebar-nav">
					<li class="link-active side-btn" id="design"><a href="#">Design</a></li>
					<li class="side-btn" id="text"><a href="#">Text</a></li>
					<li class="side-btn" id="coupon"><a href="#">Coupon</a></li>
					<li class="side-btn" id="settings"><a href="#">Settings</a></li>
					<li class="side-btn" id="trigger"><a href="#">Trigger</a></li>
				</ul>
			</div>
			<!-- /Sidebar -->
			<!-- Page Content -->
			<main class="page-main">
				<div class="row" style="background-color: #ffffff; padding: 10px; box-shadow: 0 0 13px 0 rgba(0, 0, 0, 0.25);">
					<div class="col-md-12">
						<a href="<?=base_url()?>campaign" class="btn btn-primary">< Back</a>
						<a href="" class="btn btn-primary" style="float: right;">Create Game</a>
					</div>
				</div>
				<div class="row">
					<div class="col-md-5">
						<div class="tabs" id="design-tab" style="height: 100vh; background-color: #ffffff; box-shadow: 0 5px 11px 0 rgba(0, 0, 0, 0.25); padding: 20px;">
							<div>
								<h5 class="title">DESKTOP LOGO</h5>
								<input type="file">
								<hr>
							</div>
							<div>
								<h5 class="title">MOBILE LOGO</h5>
								<input type="file">
								<hr>
							</div>
							<div>
								<h5 class="title">COLORS</h5>
								<div style="padding: 13px;">
									<span>Background</span>
									<input type="color" id="background_colorPicker" name="background_colorPicker" value="#ff0000" class="color-box">
								</div>
								<div style="padding: 13px;">
									<span>Cover Text</span>
									<input type="color" id="cover_text_colorPicker" name="cover_text_colorPicker" value="#ff0340" class="color-box">
								</div>
								<!-- <div style="padding: 13px;">
									<span>Cover Text Mobile</span>
									<input type="color" id="colorPicker" name="colorPicker" value="#ff0000" class="color-box">
								</div> -->
								<div style="padding: 13px;">
									<span>Coupon Text</span>
									<input type="color" id="coupon_text_colorPicker" name="coupon_text_colorPicker" value="#ff0000" class="color-box">
								</div>
								<div style="padding: 13px;">
									<span>Button</span>
									<input type="color" id="button_colorPicker" name="button_colorPicker" value="#ff0000" class="color-box">
								</div>
								<div style="padding: 13px;">
									<span>Button Text</span>
									<input type="color" id="button_text_colorPicker" name="button_text_colorPicker" value="#ff0000" class="color-box">
								</div>
								<hr>
							</div>
							<div>
								<h5 class="title">FONT</h5>
								<select name="font" id="font" class="form-control">
									<option value="Nunito Sans, sans-serif">Nunito Sans, sans-serif</option>
									<option value="Oswald, sans-serif">Oswald, sans-serif</option>
									<option value="Inherit">Inherit</option>
									<option value="Lora,serif">Lora,serif</option>
									<option value="Concert One, cursive">Concert One, cursive</option>
									<option value="Noto Sans, sans-serif">Noto Sans, sans-serif</option>
								</select>
							</div>
						</div>

						<div class="tabs" id="text-tab" style="height: 100vh; background-color: #ffffff; box-shadow: 0 5px 11px 0 rgba(0, 0, 0, 0.25); padding: 20px; display: none;">
							<input type="checkbox" id="toggle">
							<label for="toggle" class="title toggle-btn">START SCREEN</label>
							<div class="content">
								<label for="title">TITLE</label>
								<input type="text" id="title" name="title" class="form-control" value="WELCOME BACK!">
								<label for="title">SECOND TITLE</label>
								<input type="text" id="sec-title" name="sec-title" class="form-control" value="PLEASE ENTER YOUR EMAIL TO SPIN AND WIN A PRIZE">
								<label for="title">EMAIL</label>
								<input type="text" id="mail-title" name="mail-title" class="form-control" value="Enter your email">
								<label for="title">BUTTON</label>
								<input type="text" id="btn-title" name="btn-title" class="form-control" value="SPIN">
							</div><hr>

							<input type="checkbox" id="toggle1">
							<label for="toggle1" class="title toggle-btn">WIN SCREEN</label>
							<div class="content1">
								<label for="title">CONGRATULATIONS</label>
								<input type="text" id="congrat" name="title" class="form-control" value="CONGRATULATIONS!">
								<label for="title">YOU GOT</label>
								<input type="text" id="you-got" name="title" class="form-control" value="YOU GOT A">
								<label for="title">YOUR DISCOUNT CODE IS</label>
								<input type="text" id="discount-is" name="title" class="form-control" value="YOUR DISCOUNT CODE IS:">
								<label for="title">BUTTON</label>
								<input type="text" id="win-btn" name="title" class="form-control" value="SHOP NOW">
							</div><hr>
						</div>
					</div>
					<div class="col-md-7" style="display: grid;">
						<div style="display: block;" id="play-tab">
							<div class="modal-body" style="display: flex; top: 200px; left: -83px; z-index: -1;">
								<div class="column" id="main" style="margin-left: 0px; padding: 0px; flex: 24%;">
									<!-- <div style="text-align: center; margin-right: 106px;">
										<img src="<?=base_url()?>assets/images/spin-n-win/pin-8-512 (1).png" width="50">                        
									</div> -->
									<canvas id="canvas" width="434" height="434" style="left: -165px; top: -54px; position: absolute; z-index: 10;">
										<p style="{color: white}" align="center">Sorry, your browser doesn't support canvas. Please try another.</p>
									</canvas>
								</div>
								<div class="column" id="secondary" style="background-color: #df7da6;">
									<div class="sec-content" style="padding: 35px 20px 21px 173px;">
									<h2 class="h2-style" id="spin_head_text" style="color: #ffffff;">Welcome Back!</h2>
									<h3 id="spin_sub_text">Please enter your email to spin and win a prize</h3>
									<!-- <button type="button" class="btn btn-primary">Login</button> -->
									<form id="spin_form">
										<input type="email" class="form-control" name="mail" id="mail" placeholder="Enter your email" value="Enter your email" required>                    
										<button id="spin_button" type="submit" class="btn btn-primary" style="width: 100%;">SPIN</button>
									</form>
									</div>
								</div>
							</div>
						</div>

						<div style="position: fixed; display: none;" id="win-tab">
							<div class="modal-body" style="height: 550px; width: 550px; text-align: center;">
								<div class="sec-content" style="padding: 56px 109px 99px 113px; margin: 77px 27px 28px 25px; width: 560px; text-align-last: center; background-color: antiquewhite; border-radius: 30rem;">
									<h2 class="h2-style" style="color: #000000;" id="congrat-msg">Congratulations!</h2>
									<h3 style="color: #000000;" id="you-got-msg">You got a</h3>
									<h1 class="" style="color: #df7db4; font-weight: 900;">HAPPY DAYS!! 20%</h2>
									<h1 class="" style="color: #df7db4; font-weight: 900;">Discount</h2>
									<h3 style="color: #000000;" id="discount-is-msg">Your Discount Code is:</h3>
									<form id="spin_form">
										<input type="email" class="form-control" id="discount_code" value="3SDH67S8" placeholder="Your Discount Code" disabled required>                    
										<button id="shop_button" type="submit" class="btn" style="width: 100%;">Shop Now</button>
									</form>
								</div>
							</div>
						</div>
						

					</div>
				</div>
			</main>
			<!-- /Page Content -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
        <script>
            // Set the date we're counting down to
            var coupon_status = 0; 
            var coupon_browser_status = 1; 
            // alert("<?=$this->session->userdata('coupon_status')?>");
			coupon_status = <?=$this->session->userdata('coupon_status')?>;
        	coupon_browser_status = <?=$this->session->userdata('coupon_browser_status')?> ;	
            // alert(coupon_browser_status);

            if (coupon_status == 1) {
            	var time = "<?=$this->session->userdata('coupon_time')?>";
	            var countDownDate = new Date(time).getTime();

	            // Update the count down every 1 second
	            var x = setInterval(function() {

	              // Get today's date and time
	              var now = new Date().getTime();

	              // Find the distance between now and the count down date
	              var distance = countDownDate - now;

	              // Time calculations for days, hours, minutes and seconds
	              var days = Math.floor(distance / (1000 * 60 * 60 * 24));
	              var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
	              var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
	              var seconds = Math.floor((distance % (1000 * 60)) / 1000);
	              // var finalCount = '';
	              // if (days != 0) {
	              //   finalCount = days + "d ";
	              // }
	              // if (hours != 0) {
	              //   finalCount = finalCount + hours + "h "; 
	              // }
	              // if (minutes != 0) {
	              //   finalCount = finalCount + minutes + "m "; 
	              // }
	              //   finalCount = finalCount + seconds + "s "; 

	              // Display the result in the element with id="demo"
	              document.getElementById("demo").innerHTML = days + "d " + hours + "h "
	              + minutes + "m " + seconds + "s ";

	              // If the count down is finished, write some text
	              if (distance < 0) {
	                clearInterval(x);
	                document.getElementById("demo").innerHTML = "EXPIRED";
	                $.ajax({
	                    url: "<?php echo site_url('Frontend/expirePrize') ?>",
	                    type: 'post',
	                    dataType: 'json',
	                    success: function(resp) {
	                        // var res = JSON.parse(resp);
	                        // console.log(res);
	                		window.location.href = "<?=base_url()?>";
	                    },
	                    error: function(resp) {

	                    }
	                });
	              }
	            }, 1000);	
            }
            // alert(coupon_browser_status);
            if (coupon_status != 1 && coupon_browser_status == 0) {
            	$('#spinModal').modal('show');
			}

        </script>
        <script type="text/javascript">
	    	$("#btn_click").on('click',function(e){
			//  Use e.effeect() - $('#btn').effeect() - $(this).effeect() 
			  $("#btn_click").effect( "shake", {times:4}, 1000 );
			  // alert('hi');
			});
	    </script>
		<script>
			$('#background_colorPicker').on('change', function(e){
				// alert(this.value);
				$('#secondary').css('background-color', this.value);
			});
			
			$('#cover_text_colorPicker').on('change', function(e){
				// alert(this.value);
				$('#spin_head_text').css('color', this.value);
				$('#spin_sub_text').css('color', this.value);
				$('#mail').css('color', this.value);
			});

			$('#button_colorPicker').on('change', function(e){
				// alert(this.value);
				$('#spin_button').css('background-color', this.value);
				$('#spin_button').css('border-color', this.value);
			});
			
			$('#button_text_colorPicker').on('change', function(e){
				// alert(this.value);
				$('#spin_button').css('color', this.value);
			});

			$('#font').on('change', function(e){
				// alert(this.value);
				$('#spin_head_text').css('font-family', this.value);
				$('#spin_sub_text').css('font-family', this.value);
				$('#mail').css('font-family', this.value);
				$('#spin_button').css('font-family', this.value);
			});
		</script>
		<script>
			$('.side-btn').on('click', function(e){
				// alert(this.id);
				$('.side-btn').removeClass('link-active');
				$('#'+this.id).addClass('link-active');
				$('.tabs').css('display', 'none');
				$('#'+this.id+'-tab').css('display', 'block');
				$('#play-tab').css('display', 'block');
				$('#win-tab').css('display', 'none');
			});
		</script>
		<script>
			$('#title, #sec-title, #mail-title, #btn-title').on('input', function (e){  
				// alert($('#title').data('custom'));
				console.log(this.id);
				switch (this.id) {
					case 'title':
						$('#spin_head_text').text(this.value);
						
						break;
					case 'sec-title':
						$('#spin_sub_text').text(this.value);
						
						break;
					case 'mail-title':
						$('#mail').attr('placeholder',this.value);
						
						break;
					case 'btn-title':
						$('#spin_button').text(this.value);

						break;
				}
			});
		</script>
		<script>
			$('#congrat, #you-got, #discount-is, #win-btn').on('input', function (e){  
				// alert($('#title').data('custom'));
				console.log(this.id);
				switch (this.id) {
					case 'congrat':
						$('#congrat-msg').text(this.value);
						
						break;
					case 'you-got':
						$('#you-got-msg').text(this.value);
						
						break;
					case 'discount-is':
						$('#discount-is-msg').text(this.value);
						
						break;
					case 'win-btn':
						$('#shop_button').text(this.value);

						break;
				}
			});
		</script>
		<script>
			$('#congrat, #you-got, #discount-is, #win-btn').on('click', function (e){  
				$('#play-tab').css('display', 'none');
				$('#win-tab').css('display', 'block');
			});
			$('#title, #sec-title, #mail-title, #btn-title').on('click', function (e){  
				$('#play-tab').css('display', 'block');
				$('#win-tab').css('display', 'none');
			});
		</script>
</body>

</html>