<!DOCTYPE html>
<html lang="en">

<head>
	<!-- Head -->
		<?php $this->load->view('includes/head'); ?>
	<!-- /Head -->
</head>

<body class="boxed">
	<div id="wrapper">
		<div class="page-wrapper">
			<!-- Header -->
    			<?php $this->load->view('includes/header'); ?>
			<!-- /Header -->
			<main class="page-main">
				<div class="block">
					<div class="container">
						<ul class="breadcrumbs">
							<li><a href="index.html"><i class="icon icon-home"></i></a></li>
							<li>/<span>About us</span></li>
						</ul>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="title center">
							<h1>About Us</h1>
						</div>
					</div>
				</div>
				<div class="block fullboxed parallax" data-parallax="scroll" data-image-src="images/block-bg-1.jpg">
					<div class="container">
						<div class="row">
							<div class="col-sm-6">
								<img src="images/logo-big.png" alt class="img-responsive" />
							</div>
							<div class="col-sm-6">
								<div class="text-wrapper text-lg">
									<p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful.</p>
									<p>Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="title center">
							<h2>Meet Our Team</h2>
						</div>
						<div class="row">
							<div class="col-sm-4">
								<div class="person">
									<div class="person-photo">
										<img src="images/person/person-01.jpg" alt="">
									</div>
									<div class="person-info">
										<h3 class="person-name">Thomas Eringer</h3>
										<div class="person-subname">- designer</div>
										<p>These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled</p>
										<div class="person-links">
											<a href="#"><i class="icon icon-twitter-logo"></i></a>
											<a href="#"><i class="icon icon-facebook-logo"></i></a>
											<a href="#"><i class="icon icon-skype-logo"></i></a>
											<a href="#"><i class="icon icon-close-envelope"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="person">
									<div class="person-photo">
										<img src="images/person/person-02.jpg" alt="">
									</div>
									<div class="person-info">
										<h3 class="person-name">Tom Sollers</h3>
										<div class="person-subname">- designer</div>
										<p>These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled</p>
										<div class="person-links">
											<a href="#"><i class="icon icon-twitter-logo"></i></a>
											<a href="#"><i class="icon icon-facebook-logo"></i></a>
											<a href="#"><i class="icon icon-skype-logo"></i></a>
											<a href="#"><i class="icon icon-close-envelope"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="person">
									<div class="person-photo">
										<img src="images/person/person-03.jpg" alt="">
									</div>
									<div class="person-info">
										<h3 class="person-name">Andrea finter</h3>
										<div class="person-subname">- designer</div>
										<p>These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled</p>
										<div class="person-links">
											<a href="#"><i class="icon icon-twitter-logo"></i></a>
											<a href="#"><i class="icon icon-facebook-logo"></i></a>
											<a href="#"><i class="icon icon-skype-logo"></i></a>
											<a href="#"><i class="icon icon-close-envelope"></i></a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="block bg white">
					<div class="container">
						<div class="title center">
							<h2>Partners</h2>
						</div>
						<div class="brand-grid">
							<a href="#" class="brand-item"><img src="images/brands/brand-square-01.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-02.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-03.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-04.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-05.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-06.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-07.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-08.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-09.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-10.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-11.png" alt="Brand Logo"></a>
							<a href="#" class="brand-item"><img src="images/brands/brand-square-12.png" alt="Brand Logo"></a>
						</div>
					</div>
				</div>
				<div class="block">
					<div class="container">
						<div class="row">
							<div class=" col-md-4 col-lg-6">
								<div class="collapsed-mobile">
									<!-- Blog Carousel -->
									<div class="title">
										<h2>From Blog</h2>
										<div class="toggle-arrow"></div>
										<div class="carousel-arrows"></div>
									</div>
									<div class="collapsed-content">
										<div class="blog-carousel">
											<!-- Blog Carousel Item -->
											<div class="blog-item">
												<a href="blog.html" class="blog-item-photo"> <img class="product-image-photo" src="images/blog/blog-1.jpg" alt="From Blog"> </a>
												<div class="blog-item-info">
													<a href="blog.html" class="blog-item-title"> Ac Tincidunt Suspendisse </a>
													<div class="blog-item-teaser"> Commodo laoreet semper tincidunt lorem Vestibulum nc at In Curabitur magna. Euismod euismod Suspendisse </div>
													<div class="blog-item-links"> <span class="pull-left"> <span><a href="#" class="readmore">Read more</a></span> </span> <span class="pull-right"> <span><a href="#">5 Comment(s)</a></span> <span>Post by <a href="#">Admin</a></span> </span>
													</div>
												</div>
											</div>
											<!-- /Blog Carousel Item -->
											<!-- Blog Carousel Item -->
											<div class="blog-item">
												<a href="blog.html" class="blog-item-photo"> <img class="product-image-photo" src="images/blog/blog-2.jpg" alt="From Blog"> </a>
												<div class="blog-item-info">
													<a href="blog.html" class="blog-item-title"> Ac Tincidunt Suspendisse </a>
													<div class="blog-item-teaser"> Commodo laoreet semper tincidunt lorem Vestibulum nc at In Curabitur magna. Euismod euismod Suspendisse </div>
													<div class="blog-item-links"> <span class="pull-left"> <span><a href="#" class="readmore">Read more</a></span> </span> <span class="pull-right"> <span><a href="#">5 Comment(s)</a></span> <span>Post by <a href="#">Admin</a></span> </span>
													</div>
												</div>
											</div>
											<!-- /Blog Carousel Item -->
											<!-- Blog Carousel Item -->
											<div class="blog-item">
												<a href="blog.html" class="blog-item-photo"> <img class="product-image-photo" src="images/blog/blog-1.jpg" alt="From Blog"> </a>
												<div class="blog-item-info">
													<a href="blog.html" class="blog-item-title"> Ac Tincidunt Suspendisse </a>
													<div class="blog-item-teaser"> Commodo laoreet semper tincidunt lorem Vestibulum nc at In Curabitur magna. Euismod euismod Suspendisse </div>
													<div class="blog-item-links"> <span class="pull-left"> <span><a href="#" class="readmore">Read more</a></span> </span> <span class="pull-right"> <span><a href="#">5 Comment(s)</a></span> <span>Post by <a href="#">Admin</a></span> </span>
													</div>
												</div>
											</div>
											<!-- /Blog Carousel Item -->
											<!-- Blog Carousel Item -->
											<div class="blog-item">
												<a href="blog.html" class="blog-item-photo"> <img class="product-image-photo" src="images/blog/blog-2.jpg" alt="From Blog"> </a>
												<div class="blog-item-info">
													<a href="blog.html" class="blog-item-title"> Ac Tincidunt Suspendisse </a>
													<div class="blog-item-teaser"> Commodo laoreet semper tincidunt lorem Vestibulum nc at In Curabitur magna. Euismod euismod Suspendisse </div>
													<div class="blog-item-links"> <span class="pull-left"> <span><a href="#" class="readmore">Read more</a></span> </span> <span class="pull-right"> <span><a href="#">5 Comment(s)</a></span> <span>Post by <a href="#">Admin</a></span> </span>
													</div>
												</div>
											</div>
											<!-- /Blog Carousel Item -->
										</div>
										<!-- /Blog Carousel -->
									</div>
								</div>
							</div>
							<div class=" col-md-4 col-lg-4">
								<div class="">
									<!-- Deal Carousel -->
									<div class="title">
										<h2 class="custom-color">Deal of the day</h2>
										<div class="toggle-arrow"></div>
										<div class="carousel-arrows"></div>
									</div>
									<div class="collapsed-content">
										<div class="deal-carousel products-grid product-variant-1">
											<!-- Product Item -->
											<div class="product-item large">
												<div class="product-item-inside">
													<!-- Product Label -->
													<div class="product-item-label label-sale"><span>-20%</span></div>
													<!-- /Product Label -->
													<div class="product-item-info">
														<!-- Product Photo -->
														<div class="product-item-photo">
															<!-- product inside carousel -->
															<div class="carousel-inside slide" data-ride="carousel">
																<div class="carousel-inner">
																	<div class="item active">
																		<a href="#"><img class="product-image-photo" src="images/products/product-12.jpg" alt=""></a>
																	</div>
																	<div class="item">
																		<a href="#"><img class="product-image-photo" src="images/products/product-12-1.jpg" alt=""></a>
																	</div>
																</div>
																<a class="carousel-control next"></a>
																<a class="carousel-control prev"></a>
															</div>
															<!-- /product inside carousel -->
															<!-- Product Actions -->
															<div class="product-item-actions">
																<div class="actions-primary">
																	<button class="btn btn-sm btn-invert add-to-cart"> <i class="icon icon-cart"></i><span>Add to Cart</span> </button>
																</div>
																<div class="actions-secondary">
																	<a href="#" class="sharing" title="Link"> <i class="icon icon-share"></i> </a>
																	<a href="quick-view.html" class="quick-view-link" title="Quick View"> <i class="icon icon-eye"></i> </a>
																	<a href="#" title="Compare"> <i class="icon icon-balance"></i> </a>
																	<a href="#" title="Wish List" class="wishlist"> <i class="icon icon-heart"></i> </a>
																</div>
																<ul class="social-list">
																	<li>
																		<a href="#" class="icon icon-google google"></a>
																	</li>
																	<li>
																		<a href="#" class="icon icon-fancy fancy"></a>
																	</li>
																</ul>
															</div>
															<!-- /Product Actions -->
														</div>
														<!-- /Product Photo -->
														<!-- Product Details -->
														<div class="product-item-details">
															<div class="product-item-name"> <a title="Slide effect" href="product.html" class="product-item-link">Slide effect</a> </div>
															<div class="product-item-description">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia nonkdni numquam eius modi tempora incidunt ut labore</div>
															<div class="price-box"> <span class="price-container"> <span class="price-wrapper"> <span class="old-price">$190.00</span> <span class="special-price">$149.00</span> </span>
																</span>
															</div>
															<!-- Product Actions -->
															<div class="product-item-actions">
																<div class="actions-primary">
																	<button class="btn btn-sm btn-invert add-to-cart" data-product="321235"> <i class="icon icon-cart"></i><span>Add to Cart</span> </button>
																</div>
															</div>
															<!-- /Product Actions -->
														</div>
														<!-- /Product Details -->
													</div>
												</div>
											</div>
											<!-- /Product Item -->
											<!-- Product Item -->
											<div class="product-item large">
												<div class="product-item-inside">
													<!-- Product Label -->
													<div class="product-item-label label-sale"><span>-20%</span></div>
													<!-- /Product Label -->
													<div class="product-item-info">
														<!-- Product Photo -->
														<div class="product-item-photo">
															<a href="product.html"> <img class="product-image-photo" src="images/products/product-16-c1.jpg" alt=""> </a>
															<!-- Product Actions -->
															<div class="product-item-actions">
																<div class="actions-primary">
																	<button class="btn btn-sm btn-invert add-to-cart"> <i class="icon icon-cart"></i><span>Add to Cart</span> </button>
																</div>
																<div class="actions-secondary">
																	<a href="#" class="sharing" title="Link"> <i class="icon icon-share"></i> </a>
																	<a href="quick-view.html" class="quick-view-link" title="Quick View"> <i class="icon icon-eye"></i> </a>
																	<a href="#" title="Compare"> <i class="icon icon-balance"></i> </a>
																	<a href="#" title="Wish List" class="wishlist"> <i class="icon icon-heart"></i> </a>
																</div>
																<ul class="social-list">
																	<li>
																		<a href="#" class="icon icon-google google"></a>
																	</li>
																	<li>
																		<a href="#" class="icon icon-fancy fancy"></a>
																	</li>
																	<li>
																		<a href="#" class="icon icon-pinterest pinterest"></a>
																	</li>
																	<li>
																		<a href="#" class="icon icon-twitter-logo twitter"></a>
																	</li>
																	<li>
																		<a href="#" class="icon icon-facebook-logo facebook"></a>
																	</li>
																</ul>
															</div>
															<!-- /Product Actions -->
														</div>
														<!-- /Product Photo -->
														<!-- Product Details -->
														<div class="product-item-details">
															<div class="product-item-name"> <a title="Long sleeve overall" href="product.html" class="product-item-link">Long sleeve overall</a> </div>
															<div class="product-item-description">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia nonkdni numquam eius modi tempora incidunt ut labore</div>
															<div class="price-box"> <span class="price-container"> <span class="price-wrapper"> <span class="old-price">$190.00</span> <span class="special-price">$149.00</span> </span>
																</span>
															</div>
															<!-- Product Actions -->
															<div class="product-item-actions">
																<div class="actions-primary">
																	<button class="btn btn-sm btn-invert add-to-cart"> <i class="icon icon-cart"></i><span>Add to Cart</span> </button>
																</div>
															</div>
															<!-- /Product Actions -->
															<!-- Color Swatch -->
															<ul class="color-swatch hidden-xs">
																<li class="active">
																	<a data-image="images/products/product-16-c1.jpg" href="#"><img src="images/colorswatch/color-blue.png" alt="Blue"></a>
																</li>
																<li>
																	<a data-image="images/products/product-16-c2.jpg" href="#"><img src="images/colorswatch/color-grey.png" alt="Gray"></a>
																</li>
																<li>
																	<a data-image="images/products/product-16-c3.jpg" href="#"><img src="images/colorswatch/color-red.png" alt="Red"></a>
																</li>
																<li>
																	<a data-image="images/products/product-16-c4.jpg" href="#"><img src="images/colorswatch/color-violet.png" alt="Violet"></a>
																</li>
																<li>
																	<a data-image="images/products/product-16-c5.jpg" href="#"><img src="images/colorswatch/color-green.png" alt="Green"></a>
																</li>
															</ul>
															<!-- /Color Swatch -->
														</div>
														<!-- /Product Details -->
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- /Deal Carousel -->
								</div>
								<div class="newsletter variant1 collapsed-mobile">
									<div class="title">
										<h2>Newsletter</h2>
										<div class="toggle-arrow"></div>
									</div>
									<div class="collapsed-content">
										<!-- input-group -->
										<form action="#">
											<div class="input-group">
												<input type="text" class="form-control">
												<span class="input-group-btn">
													<button class="btn btn-default" type="submit"><i class="icon icon-close-envelope"></i></button>
													</span>
											</div>
										</form>
										<!-- /input-group -->
									</div>
								</div>
							</div>
							<div class=" col-md-4 col-lg-2">
								<div class="collapsed-mobile">
									<div class="title">
										<h2>Contact</h2>
										<div class="toggle-arrow"></div>
									</div>
									<div class="collapsed-content">
										<ul class="contact-list">
											<li>
												<h3><i class="icon icon-location-pin"></i>ADDRESS</h3>
												<div>5th Floor, AH Building, 756 New Design St Melbourne, Australia.</div>
											</li>
											<li>
												<h3><i class="icon icon-close-envelope"></i>Email</h3>
												<div><a href="#">support@seiko.com</a></div>
												<div><a href="#">hello@tseiko.com</a></div>
												<div><a href="#">hr@tseiko.com</a></div>
												<div><a href="#">sale@tseiko.com</a></div>
											</li>
											<li>
												<h3><i class="icon icon-phone"></i>PHONE</h3>
												<div>Phone 01: (0091) 8547 632521
													<br> Phone 02: (054) 965 4788
													<br> Phone 03: (053) 754 5421
												</div>
											</li>
											<li>
												<h3><i class="icon icon-skype-logo"></i>SKYPE</h3>
												<div>HRSeiko
													<br> Seikosupport
												</div>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</main>
			<!-- Footer -->
    			<?php $this->load->view('includes/footer'); ?>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>
	
	<!-- jQuery Scripts  -->
	<script src="js/vendor/jquery/jquery.js"></script>
	<script src="js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="js/megamenu.min.js"></script>
	<script src="js/app.js"></script>

</body>

</html>