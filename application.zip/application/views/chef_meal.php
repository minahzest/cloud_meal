<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CloudMeal | Chef Panel</title>
	<meta name="author" content="BigSteps">
	<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
	<link rel="shortcut icon" href="favicon.ico">
	<link rel="shortcut icon" href="<?=base_url()?>assets/images/logo.png"> 
	<!-- Vendor -->
	<link href="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/slick/slick.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/swiper/swiper.min.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/nouislider/nouislider.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/animate.css" rel="stylesheet">

	<!-- Custom -->
	<link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
	<link href="<?=base_url()?>assets/css/megamenu.css" rel="stylesheet">

	<!-- Color Schemes -->
	<!-- your style-color.css here  -->


	<!-- Icon Font -->
	<link href="<?=base_url()?>assets/fonts/icomoon-reg/style.css" rel="stylesheet">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Roboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

	<style>
		.active-nav{
			width: 100%;
			background-color: #494e62;
			left: 0;
			background-color: #494e62;
			left: -4px;
			border-right: 4px solid #f82e56;
		}
	</style>
</head>

<body class="fullwidth open-panel" onload="getMeal()">
	<div id="wrapper">
		<!-- Page -->
		<div class="page-wrapper">
			<!-- Sidebar -->
			<div class="sidebar-wrapper">
				<ul class="sidebar-nav">
					<li> <a href="<?=base_url()?>chef-account">HOME</a> </li>
					<li> <a href="<?=base_url()?>chef-order">Orders</a> </li>
					<li class="active-nav"> <a href="<?=base_url()?>chef-meals" class="active">My Meals</a> </li>
					<li> <a href="<?=base_url()?>chef-logout">LOGOUT</a> </li>
				</ul>
			</div>
			<!-- /Sidebar -->
			<!--header-->
			<header class="page-header variant-1 fullboxed sticky smart">
				<div class="navbar" style="margin: 0 0 0 0;">
					<div class="container">
						<div class="header-logo">
							<span style="font-size: 24px;font-family: 'Oswald', sans-serif; font-weight: 400; text-transform: uppercase; padding: 0 0 2px; margin: 0 0 30px 0; color: #333745;">Hi, <?=$this->session->userdata('user_logged_in')['user_name']?></span>
						</div>
					</div>
				</div>
			</header>
			<!--header end-->
			<!-- Page Content -->
			<main class="page-main">
				<div class="block">
					<div class="container" style="margin-top: 60px;">
						<div class="page-title">
							<div class="title">
								<!-- <h1>My Dashboard</h1> -->
							</div>
						</div>
						<div class="row" style="padding: 20px;">
							<div class="col-md-12">
								<a href="<?php echo site_url('chef-meal-history'); ?>" class="btn btn-alt pull-right">Meals Packs History</a>
								<a href="<?php echo site_url('add_meal'); ?>" class="btn btn pull-right"><i class="icon icon-plus"></i> Add Meals Packs</a>
								<h2>My Active Meal Packs</h2>
								<div class="table-responsive">
									<table class="table table-bordered table-striped">
										<thead>
											<tr>
												<th scope="col"># </th>
												<th scope="col"></th>
												<th scope="col">Meal Name</th>
												<th scope="col">Category </th>
												<th scope="col">Price Range</th>
												<th scope="col">Qty</th>
												<th scope="col">Qty Ordered</th>
												<th scope="col">Date</th>
												<th scope="col">Status</th>
											</tr>
										</thead>
										<tbody id="order_body">
											
										</tbody>
									</table>
									<!-- <pre> -->
										<?php 
											// print_r($orders);
										?>
									<!-- </pre> -->
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="divider"></div>
			</main>
			<!-- /Page Content -->
			<!-- Footer -->
			<footer class="page-footer variant1">
				<div class="container">
					<div class="after-footer">
						<div class="footer-copyright text-center"> © 2016 Demo Store. All Rights Reserved. </div>
					</div>
				</div>
			</footer>
			<!-- /Footer -->
		</div>
		<!-- Page Content -->
	</div>

	<!-- jQuery Scripts  -->
	<script src="<?=base_url()?>assets/js/vendor/jquery/jquery.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap/bootstrap.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/swiper/swiper.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/slick/slick.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/parallax/parallax.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/isotope/isotope.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/countdown/jquery.countdown.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/nouislider/nouislider.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/ez-plus/jquery.ez-plus.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/tocca/tocca.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/scrollLock/jquery-scrollLock.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/darktooltip/dist/jquery.darktooltip.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
	<script src="<?=base_url()?>assets/js/vendor/instafeed/instafeed.min.js"></script>
	<script src="<?=base_url()?>assets/js/megamenu.min.js"></script>
	<script src="<?=base_url()?>assets/js/app.js"></script>
	<script>
		function getMeal(){  
			// alert('hi');
			let meal_name = '';
			let cat = '';

			let status = '';
			let order_body = '';
			$('#order_body').empty();
			$.ajax({
				type: 'POST',
				url: '<?=base_url()?>get_chef_meal_ajax',
				data: 'meal_name='+meal_name+'&cat='+cat+'&type='+1,
				success: function (result){  
					let res = $.parseJSON(result);
					if (res.status == 'success') {
						for (let i = 0; i < res.message.length; i++) {
							// alert(status);
							let orders = res.message[i]['qty_ordered']
							if (res.message[i]['qty_ordered'] == null) {
								orders = 0;
							}
							order_body += '<tr>'+
												'<td>'+(i+1)+'</td>'+
												'<td><img src="<?=PHOTO_DOMAIN?>'+res.message[i]['meal_image']+'" width="32px" onclick="change_image('+res.message[i]['user_meal_id']+')"></td>'+
												'<td>'+res.message[i]['meal_name']+'</td>'+
												'<td>'+res.message[i]['category']+'</td>'+
												'<td><span class="color">Rs.'+res.message[i]['min_price']+' - Rs.'+res.message[i]['max_price']+'</span></td>'+
												'<td>'+res.message[i]['qty']+'</a></td>'+
												'<td>'+orders+'</a></td>'+
												'<td>'+res.message[i]['user_meal_date']+'</td>'+
												'<td><a href="javascript:open_meal('+res.message[i]['user_meal_id']+')" class="pull-left">View Details</a></td>'+
											'</tr>';
						}
						$('#order_body').append(order_body);
					}
				},
				error: function (result){  

				}
			});
		}
	</script>
	<script>
		function open_meal(id){  
			// alert(id);
			window.open("<?php echo site_url('view_meal/'); ?>" + btoa(id), '_blank');
		}
	</script>
	<script>
		function change_image(id) {
			alert(id);
			
		}
	</script>
</body>

</html>