<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Welcome';
$route['404_override'] = 'Welcome/not_found';
$route['translate_uri_dashes'] = FALSE;




$route['home'] ='Welcome/index';
$route['contact-us'] = 'Welcome/contact_us';
$route['send-message'] = 'Welcome/send_message';
$route['cart'] = 'Welcome/cart';
$route['about-us'] = 'Welcome/about';
$route['meal-pack'] = 'Welcome/meal_pack';
$route['get_meal'] = 'Welcome/get_meal';
$route['get_mealpack_items_ajax'] = 'Welcome/get_mealpack_items_ajax';
$route['business'] = 'Welcome/business';
$route['register'] = 'Welcome/register';


//sing-in and sing-up
$route['login'] = 'Welcome/user_login_page';
$route['sign-in'] = 'Welcome/user_signin';
$route['user-signup'] = 'Welcome/user_signup';
$route['seller-request'] = 'Welcome/sellerRequest';
$route['submit-request'] = 'Welcome/saveSeller';
$route['chef-signup'] = 'Welcome/chef_signup';//chef register
$route['chef-sign-in'] = 'Welcome/chef_sign_in';//chef login
 

//account
$route['account'] = 'Account/index';
$route['logout'] = 'Account/logout';
$route['get_order_ajax'] = 'Account/orders';
$route['acc-details'] = 'Account/acc_details';
$route['update_customer_pass_ajax'] = 'Account/update_customer_pass_ajax';
$route['update_customer_details_ajax'] = 'Account/update_customer_details_ajax';
$route['acc-wallet'] = 'Account/acc_wallet';
$route['acc-wallet-credit'] = 'Account/acc_wallet_credit';
$route['recharge_wallet_ajax'] = 'Account/recharge_wallet_ajax';
$route['rating_feedback_ajax'] = 'Account/rating_feedback_ajax';

//order
$route['view_order/(:any)'] = 'Account/view_order/$1';
$route['cancel_order'] = 'Account/cancel_order';

//cart
$route['add_to_cart_ajax'] = 'Welcome/add_to_cart_ajax';
$route['remove_from_cart_ajax'] = 'Welcome/remove_from_cart_ajax';
$route['update_cart_qty_ajax'] = 'Welcome/update_cart_qty_ajax';
$route['checkout'] = 'Welcome/checkout';
$route['get_meal_item_ajax'] = 'Welcome/get_meal_item_ajax';
$route['place_order_ajax'] = 'Welcome/place_order_ajax';
// $route['updateItemQty'] = 'Welcome/updateItemQty';

//chef account
$route['chef-account'] = 'Chef/index';
$route['chef-logout'] = 'Chef/logout';
$route['chef-order'] = 'Chef/chef_order';
$route['get_chef_order_ajax'] = 'Chef/orders';
$route['chef_update_order_ajax'] = 'Chef/chef_update_order_ajax';
$route['chef_view_order/(:any)'] = 'Chef/chef_view_order/$1';
$route['chef-meals'] = 'Chef/chef_meals';
$route['get_chef_meal_ajax'] = 'Chef/get_chef_meal_ajax';
$route['view_meal/(:any)'] = 'Chef/view_meal/$1';
$route['chef_meal_qty_update_ajax'] = 'Chef/chef_meal_qty_update_ajax';
$route['chef_meal_status_update_ajax'] = 'Chef/chef_meal_status_update_ajax';
$route['add_meal'] = 'Chef/add_meal';
$route['save_meal_pack_ajax'] = 'Chef/save_meal_pack_ajax';
$route['chef-meal-history'] = 'Chef/chef_meals_history';


// $route['get_order_ajax'] = 'Chef/orders';


