<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Welcome extends Front_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->library('aayusmain');
        $this->load->library('geoip_lib');
        $this->load->model("Front_modal");
        $this->load->model("Common_modal");
        $this->setWallet();
    }
    public function index() {
        $data['name'] = "Hello";
        $output=null;
        $retval=null;
        // exec('whoami', $output_0, $retval_0);
        // $baseDir = 'D:\xampp\htdocs\cloud_meal\videos\cmnd\Warning';
        $baseDir = 'D:\xampp\htdocs\cloud_meal\videos\cmnd\Warning';

        exec('mkdir D:\xampp\htdocs\cloud_meal\videos\cmnd', $output_1, $retval_1);
        exec('md '.$baseDir.'\Warning_0 ^ '.$baseDir.'\Warning_1 ^ '.$baseDir.'\Warning_2 ^ '.$baseDir.'\Warning_3 ^ '.$baseDir.'\Warning_4', $output_3, $retval_3);

        $ffmpeg = $baseDir.' ffmpeg -y -hwaccel cuda -hwaccel_output_format cuda -i Warning.mov ^ -map 0:v:0 -map 0:a:0 ^ -c:v h264_nvenc -pix_fmt yuv420p -s 1920x1080 -b:v 4M ^ -c:a aac -b:a 128k ^ -hls_time 4 -hls_list_size 0 -hls_flags delete_segments ^ -hls_segment_filename "Warning/Warning_0/segment_%03d.ts" ^ -master_pl_name master.m3u8 -f hls Warning/Warning_0/video.m3u8 ^ -master_pl_name master.m3u8 -f hls Warning/video.m3u8 ^ -map 0:v:0 -map 0:a:0 ^ -c:v h264_nvenc -pix_fmt yuv420p -s 1280x720 -b:v 2.5M ^ -c:a aac -b:a 128k ^ -hls_time 4 -hls_list_size 0 -hls_flags delete_segments ^ -hls_segment_filename "Warning/Warning_1/segment_%03d.ts" ^ -master_pl_name master.m3u8 -f hls Warning/Warning_1/video.m3u8 ^ -map 0:v:0 -map 0:a:0 ^ -c:v h264_nvenc -pix_fmt yuv420p -s 960x540 -b:v 1.5M ^ -c:a aac -b:a 128k ^ -hls_time 4 -hls_list_size 0 -hls_flags delete_segments ^ -hls_segment_filename "Warning/Warning_2/segment_%03d.ts" ^ -master_pl_name master.m3u8 -f hls Warning/Warning_2/video.m3u8 ^ -map 0:v:0 -map 0:a:0 ^ -c:v h264_nvenc -pix_fmt yuv420p -s 640x360 -b:v 800K ^ -c:a aac -b:a 128k ^ -hls_time 4 -hls_list_size 0 -hls_flags delete_segments ^ -hls_segment_filename "Warning/Warning_3/segment_%03d.ts" ^ -master_pl_name master.m3u8 -f hls Warning/Warning_3/video.m3u8 ^ -map 0:v:0 -map 0:a:0 ^ -c:v h264_nvenc -pix_fmt yuv420p -s 428x240 -b:v 400K ^ -c:a aac -b:a 64k ^ -hls_time 4 -hls_list_size 0 -hls_flags delete_segments ^ -hls_segment_filename "Warning/Warning_4/segment_%03d.ts" ^ -master_pl_name master.m3u8 -f hls Warning/Warning_4/video.m3u8';

        echo $ffmpeg;
        exec($ffmpeg, $output_10, $retval_10);

        // Loop through each Warning directory
        for ($i = 0; $i <= 4; $i++) {  // Assuming folders are named Warning_0 to Warning_4
            $dirPath = $baseDir . '\Warning_' . $i;

            // Define the path for the text file
            $filePath = $dirPath . '\minhaj.txt';

            // Write the content "minhaj" into the text file
            if (file_put_contents($filePath, "video.m3u8") !== false) {
                echo "File created successfully: $filePath\n";
            } else {
                echo "Failed to create file: $filePath\n";
            }
        }

        for ($j = 0; $j <= 4; $j++) {
            // $filePath = $baseDir . '\Warning_' . $i . '\minhaj.txt';
            
            $baseDirFrom = $baseDir.'\Warning_'.$j.'\minhaj.txt';
            $baseDirTo = $baseDir.'\master.txt';

            exec("type $baseDirFrom >> $baseDirTo", $output, $retval);

            // Append a newline after each file's content
            file_put_contents($baseDirTo, PHP_EOL, FILE_APPEND);

            // Optionally check if each exec was successful
            if ($retval === 0) {
                echo "Appended content of $baseDirFrom to $baseDirTo successfully.\n";
            } else {
                echo "Failed to append content of $baseDirFrom.\n";
            }
        }

//         exec("set counter=0", $output_11, $retval_11);
//         exec('(for /f "tokens=*" %i in (D:\xampp\htdocs\cloud_meal\videos\cmnd\Warning\master.txt) do (
//     echo %i | findstr "video.m3u8" >nul && (
//         echo Warning_!counter!/%i >> D:\xampp\htdocs\cloud_meal\videos\cmnd\Warning\master_new.txt
//     set /a counter+=1
//     ) || (
//         echo %i >> D:\xampp\htdocs\cloud_meal\videos\cmnd\Warning\master_new.txt
//     )
// ))', $output_12, $retval_12);
        // Initialize the counter variable
        // exec("cmd /c set counter=0", $output_11, $retval_11);

        // Execute the loop using a single exec command
        // exec('cmd /v:on', $output_11, $retval_11); 
        exec('cmd /v:on /c "set counter=0 & (for /f "tokens=*" %i in (D:\xampp\htdocs\cloud_meal\videos\cmnd\Warning\master.txt) do ( echo %i | findstr "video.m3u8" >nul && ( echo Warning_!counter!/%i >> D:\xampp\htdocs\cloud_meal\videos\cmnd\Warning\master_new.txt & set /a counter+=1 ) || ( echo %i >> D:\xampp\htdocs\cloud_meal\videos\cmnd\Warning\master_new.txt ) ))"', $output_12, $retval_12);

        // Check the output and return value
        if ($retval_12 === 0) {
            echo "Processing completed successfully.\n";
        } else {
            echo "Processing failed with error code: $retval_12\n";
            print_r($output_12);
        }

        echo "Returned with status $retval and output:\n";
        print_r($output_10);
        $this->load->view('home',$data);
    }
    public function not_found() {
        $this->load->view('not_found');
    }
    public function setWallet()
	{
		$data['inflows'] = $this->Common_modal->sumField('tbl_wallet_debit','amount','consumer_id', $this->session->userdata('cust_logged_in')['cust_id']);
		$data['outflows'] =	$this->Common_modal->sumField('tbl_wallet_credit','amount','consumer_id', $this->session->userdata('cust_logged_in')['cust_id']);
		$this->session->set_userdata('wallet_balance', ($data['inflows']->total - $data['outflows']->total));
	}
    public function getfrontPro()
    {
        $cate_id = (int)$this->input->post('cate_id');
        $category = $this->Common_modal->getCateSubById($cate_id);
        array_push($category, $cate_id);
        $result = $this->Front_modal->getFrontCatePros($category,8);
        echo json_encode($result);
    }

    public function meal_pack(){
        $data['cat'] = $this->Common_modal->getAll("tbl_category");
        $data['cities'] = $this->Common_modal->getAll("tbl_cities");
        $this->load->view('meal_pack', $data);

    }

    public function get_meal(){
        $data['cat'] = $this->input->post('cat');
        $data['filter_date'] = $this->input->post('filter_date');
        $data['filter_city'] = $this->input->post('filter_city');
        
        $data['meals'] = $this->Front_modal->get_meal_packs($data);
        echo json_encode($data);
    }

    public function get_mealpack_items_ajax(){
        $data['id'] = $this->input->post('id');
        $data['meal_item'] = $this->Front_modal->get_meal_pack_item($data);
        echo json_encode($data);
    }

    public function add_to_cart_ajax(){

        try {
            $data['user_meal_id'] = $this->input->post('cart_meal_id');
            $data['final_price'] = $this->input->post('final_price');
            $data['final_qty'] = $this->input->post('final_qty');
            $data['min_price'] = $this->input->post('min_price');
            $data['meal_item_selected'] = $this->input->post('meal_item_selected');
            $product = $this->Common_modal->getAllWhere('tbl_user_meal','user_meal_id', $data['user_meal_id']);

            $cart = $this->cart->contents();
            $check_user = true;
            $cart_qty = 0;
            foreach ($this->cart->contents() as $key => $value) {
                if ($value['options']['sub_pro_id'] != $product->user_id) {
                    $check_user = false;
                    throw new Exception("You cannot have 2 different cooks meal in same order please process the current order 1st");
                    
                }
                if ($value['id'] == $data['user_meal_id']) {
                    $cart_qty = $value['qty'];
                    
                }

            }
            $exists = 0;
            $rowid = '';
            if ($check_user) {

                $ordered_qty = $this->Common_modal->sumField('tbl_order_meal', 'qty', 'user_meal_id', $data['user_meal_id']);

                $qty_request = (int)$data['final_qty'] + (int)$cart_qty;
                $available_qty = (int)$product->qty - (int)$ordered_qty->total;

                if ($qty_request > $available_qty) {
                    throw new Exception("Requested Quantity not available :(");
                }

                $data['user_meal_id'] = $this->input->post('cart_meal_id');
                $data['final_price'] = $this->input->post('final_price');
                $data['final_qty'] = $this->input->post('final_qty');
                $data['min_price'] = $this->input->post('min_price');
                $data['meal_item_selected'] = $this->input->post('meal_item_selected');

                $cart_data = array(
                'id'=> $data['user_meal_id'],
                'qty'=> $data['final_qty'],
                'price'=> $data['final_price'],
                'name'=> $product->meal_name,
                'options' => array(
                    'sub_pro_id' => $product->user_id, 
                    'image' => $product->meal_image, 
                    'weight' => 100, 
                    'unit_price' => $data['final_price'],
                    'discount_percentage' => 0,
                    'attributes' => $data['meal_item_selected'])
                );
                $this->cart->insert($cart_data);
                $rows = count($this->cart->contents());
                $message['status'] = "success";
                $message['exists'] = $exists;
                $message['count'] = $rows;
                $message['cart_data'] = $cart_data;

            }else{
                $rows = count($this->cart->contents());
                $message['status'] = "error";
                $message['exists'] = $exists;
                $message['count'] = $rows;
                $message['cart_data'] = "";
                $message['message'] = $product->user_id;

            }
            $message['user_stat'] = $check_user;
            // print_r($cart_data);
            echo json_encode($message);
        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
            echo json_encode($message);

        }


    }

    public function remove_from_cart_ajax(){
        try {

            $rowid = ($this->input->post('id'));
            $cart = $this->cart->contents();
            $exists = false;
            $Sub_total = 0;
            foreach($cart as $item){
                if($item['rowid'] == $rowid)
                {
                    $exists = true;
                }
            }
            if($exists)
            {
                $data = array(
                    'rowid' => $rowid,
                    'qty' => 0
                );
                $this->cart->update($data);  
            }
            foreach($this->cart->contents() as $items){
                $price = str_replace(".","",$items['price']);
                $qty = $items['qty'];
                $Sub_total += $price*$qty;
            }
            $rows = count($this->cart->contents());
            $myarray['total'] = $Sub_total;
            $myarray['count'] = $rows;
            echo json_encode($myarray);

        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
        }
    }

    public function user_signup(){
        try{            
            $fName= $this->input->post('fname');
            $lName= $this->input->post('lname');
            $mobile= $this->input->post('mobile');
            $email= $this->input->post('email');
            $password= trim($this->input->post('password'));
            $date = date("Y-m-d H:i:s");
            $checkCust = $this->Common_modal->checkField('tbl_consumers','consumer_email',$email);
            if ($checkCust) {
                throw new Exception("Email address already exist");
            }

            if (strlen($mobile) < 10 || strlen($mobile) > 11) {
                throw new Exception("Invalid Phone Number");
            }

            if (strlen($password) < 5) {
                throw new Exception("Your password is too short, please use atleast 5 characters");
            }

            $user_array = array(
                'consumer_f_name' => $fName,
                'consumer_l_name' => $lName,
                'consumer_mobile' => $mobile,
                'consumer_email' => $email,
                'consumer_password' => $this->get_encrypted_password($password),
                'registered_date' => $date,
                'consumer_status' => 1
            );
            $result = $this->Common_modal->insert("tbl_consumers",$user_array);
            if ($result) {
                $message = array("status" => "success","message" => 'You have successfully registered');
            }else{
                throw new Exception("Somthing went wrong :(");
            }
        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    public function user_login_page(){
        $this->load->view('login');
    }

    public function user_signin(){
        $email= ($this->input->post('email'));
        $password= $this->input->post('password');
        $redirect= $this->input->post('redirect');
        try{
            $result = $this->Front_modal->get_login_cust($email);//consumer_id,consumer_f_name,consumer_l_name,consumer_email,consumer_password,consumer_status
            if($result){
                if($result->consumer_status==1 && password_verify($password, $result->consumer_password)){
                    $log_array = array(
                        'cust_id' => $result->consumer_id,
                        'name' => $result->consumer_f_name.' '.$result->consumer_l_name,
                        'email' => $result->consumer_email
                    );
                    $this->session->set_userdata('cust_logged_in', $log_array);
                    $message = array("status" => "success","message" => 'account');
                }else if(!password_verify($password, $result->consumer_password)){
                    throw new Exception("Invalid password, Please try again.");
                }else{
                    throw new Exception("User blocked. Please contact administrator.");
                }
            }else{
                throw new Exception("Invalid email, User not exists.");
            }
        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    public function cart()
    {
        $this->load->view('cart');
    }

    function update_cart_qty_ajax() {
        try {
            $rowid = ($this->input->post('rowid'));
            $qty = ($this->input->post('qty'));
            $type = ($this->input->post('type'));
            $cart = $this->cart->contents();

            $exists = false;
            $Sub_total = 0;
            $pro_id = '';

            foreach($cart as $item){
                if($item['rowid'] == $rowid)
                {
                    $pro_id = $item['id'];
                    $exists = true;
                }
            }
            if($exists){
                $ordered_qty = $this->Common_modal->sumField('tbl_order_meal', 'qty', 'user_meal_id', $pro_id);
                $product = $this->Common_modal->getAllWhere('tbl_user_meal', 'user_meal_id', $pro_id);

                $qty_request = $qty;
                $available_qty = (int)$product->qty - (int)$ordered_qty->total;

                if ($type == 1) {
                    $qty_request++;
                }else{
                    $qty_request--;  
                }

                if ($qty_request > $available_qty) {
                    throw new Exception("Requested Quantity not available :(");
                }else{
                    $data = array(
                        'rowid' => $rowid,
                        'qty' => $qty_request
                    );
                    $this->cart->update($data);  
                    foreach($this->cart->contents() as $items){
                        $price = str_replace(".","",$items['price']);
                        $qty = $items['qty'];
                        $Sub_total += $price*$qty;
                    }    
                }
                $rows = count($this->cart->contents());               
                $message = array("status" => "success","message" => $Sub_total, "count" => $rows);
            }else{
                throw new Exception("Somthing went wrong :(");
            }
            
        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    public function checkout()
    {
        try{
            if (0<count($this->cart->contents())) {
                // $data['page'] = $this->Front_modal->getPage(4);
                // $data['countries'] = $this->Common_modal->getCountries();
                $data['subtotal'] = 0;
                $data['discount'] = 0;
                $data['total'] = 0;
                foreach($this->cart->contents() as $items){
                    $price = str_replace(".","",$items['price']);
                    $qty = $items['qty'];
                    $data['subtotal'] += $price*$qty;
                }
                // if($this->session->userdata('coupon')!=null){
                //     if ($this->session->userdata['coupon']['type']==0) {
                //         $data['discount'] = $this->session->userdata['coupon']['amount'];
                //     }else{
                //         $data['discount'] = ($data['subtotal'] /100)*$this->session->userdata['coupon']['amount'];
                //     }
                //     $data['total'] = $data['subtotal'] - $data['discount'];
                // }else{
                    $data['total'] = $data['subtotal'];
                // }
                
                $this->load->view('checkout', $data);
            }else{
                throw new Exception("Cart is empty");
            }
        }catch(Exception $ex){
            redirect(base_url().'cart');
        }
    }

    public function get_meal_item_ajax(){
        try{
            $attr = $this->input->post('ids');
            // if (0<count($this->cart->contents())) {

            // }else{
            //     throw new Exception("Cart is empty");
            // }
            // echo print_r($attr);
            // $str_arr = explode ( "," , $attr); 
            // print_r($str_arr);
            // foreach ($attr as $key => $value) {
            //     echo (int)$value;
            // }

            $attr_result = $this->Front_modal->getMealItem($attr);
            $message = array("status" => "success","message" => $attr_result);
            echo json_encode($message);
        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
            echo json_encode($message);

        }
    }

    public function place_order_ajax(){
        try{
            $order_note = $this->input->post('order_note');
            $wallet_balance = $this->session->userdata('wallet_balance');
            if($this->session->userdata('cust_logged_in')!=null){
                $cust_id=$this->session->userdata['cust_logged_in']['cust_id'];
            }else{
                throw new Exception("Please login");
                
            }
            if(count($this->cart->contents())>0){
                $total_bill_amount = $this->cart->total();
                if ($wallet_balance < $total_bill_amount) {
                    throw new Exception('You are running out of balance in your wallet'); 
                }else{
                    // throw new Exception('You have balance'); 
                    $user_id = '';
                    $order = array(
                        'consumer_id' => $cust_id,
                        'user_id' => 1,
                        'order_amount'  => 0,
                        'order_note'  => $order_note,
                        'order_date' => date('Y-m-d H:m:i'),
                        'order_status' => 1
                    );
                    $attr = array();
                    $order_meal = array();
                    $order_meal_items = array();
                    $order_total = 0;
                    $order_id = $this->Common_modal->insert("tbl_user_order",$order);
                    // echo "<pre>";
                    foreach ($this->cart->contents() as $key => $value) {
                        $user_id = $value['options']['sub_pro_id'];
                        // $attr = gettype($value['options']['attributes']);
                        $attr = $value['options']['attributes'];

                        $order_meal = array(
                            'order_id' => $order_id,
                            'user_meal_id' => $value['id'],
                            'order_meal_price' => $value['price'],
                            'qty'  => $value['qty'],
                            'order_meal_date' => date('Y-m-d H:m:i'),
                            'order_meal_status' => 1
                        );
                        $order_total += $value['subtotal'];
                        $order_meal_id = $this->Common_modal->insert("tbl_order_meal",$order_meal);

                        if ($attr) { 
                            $attr = explode(",",$attr);
                            // print_r($attr);
                            foreach ($attr as $key1 => $atr) {
                                $order_meal_items[$key1]['order_meal_id'] = $order_meal_id;
                                $order_meal_items[$key1]['user_meal_items_id'] = $atr;
                                $order_meal_items[$key1]['order_meal_item_status'] = 1;
                            }
                            $order_meal_item_stat = $this->Common_modal->insert_batch("tbl_order_meal_item",$order_meal_items);
                            // print_r($order_meal_items);
                        }else{
                            // echo "have no attributes";
                        }

                        // print_r($order_total);
                        // print_r($order_meal);
                        
                    }
                    $dateString = date('Ymd');
                    $center = 101;
                    $receiptNumber = 1;
                    $data = array(
                        'user_id' => $user_id,
                        'order_code' => $dateString.'-'.$center.'-'.$order_id,
                        'order_amount' => $order_total
                    );
                    $this->Common_modal->update('order_id',$order_id,"tbl_user_order",$data);

                }
                $credit_ref = 'OF-'.time().$order_id;
                $wallet_credit = array(
                    'user_id' => $user_id,
                    'consumer_id' => $cust_id,
                    'order_id' => $order_id,
                    'credit_referance' => $credit_ref,
                    'amount' => $order_total,
                    'credit_date' => date('Y-m-d H:m:i')
                );
                $wallet_credit_id = $this->Common_modal->insert("tbl_wallet_credit", $wallet_credit);
                $order_details = $this->Common_modal->getAllWhere('tbl_user_order','order_id', $order_id);
                $this->cart->destroy();
                $message = array("status" => "success","message" => "Order Place Successfully", "wallet_credit" => $wallet_credit_id, "order_data" => $order_details);
                echo json_encode($message);

            }else{
                throw new Exception('Cart is empty'); 
            }

            // $attr_result = $this->Front_modal->getMealItem($attr);
            
        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
            echo json_encode($message);

        }
    }

    public function business(){
        // $data['cat'] = $this->Common_modal->getAll("tbl_category");
        $this->load->view('business');       
    }

    public function register(){
        $data['cities'] = $this->Common_modal->getAll("tbl_cities");
        $this->load->view('business_signup', $data);       
    }

    public function chef_signup(){
        try{            
            $fName= $this->input->post('fname');
            $lName= $this->input->post('lname');
            $mobile= $this->input->post('mobile');
            $email= $this->input->post('email');
            $address= $this->input->post('address');
            $city= $this->input->post('city');
            $password= trim($this->input->post('password'));
            $date = date("Y-m-d H:i:s");
            $checkCust = $this->Common_modal->checkField('tbl_user_account','e_mail',$email);
            if ($checkCust) {
                throw new Exception("Email address already exist");
            }
            $user_array = array(
                'f_name' => $fName,
                'l_name' => $lName,
                'phone' => $mobile,
                'e_mail' => $email,
                'user_password' => $this->get_encrypted_password($password),
                'user_date' => $date,
                'user_status' => 1
            );
            $user_id = $this->Common_modal->insert("tbl_user_account", $user_array);
            $addr_array = array(
                'user_id' => $user_id,
                'address' => $address,
                'city_id' => $city,
                'address_date' => $date,
                'address_status' => 1
            );
            // $result = $this->Front_modal->saveCust($user_array,$addr_array);
            $address_id = $this->Common_modal->insert("tbl_addresses", $addr_array);
            if ($address_id) {
                $message = array("status" => "success","message" => 'You have successfully registered');
            }else{
                throw new Exception("Somthing went wrong :(");
            }
        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
        }
        echo json_encode($message);       
    }

    public function chef_sign_in(){
        $email= ($this->input->post('email'));
        $password= $this->input->post('password');
        $redirect= $this->input->post('redirect');
        try{
            $result = $this->Front_modal->get_login_chef($email);//consumer_id,consumer_f_name,consumer_l_name,consumer_email,consumer_password,consumer_status
            if($result){
                if($result->user_status==1 && password_verify($password, $result->user_password)){
                    $log_array = array(
                        'user_id' => $result->user_id,
                        'user_name' => $result->f_name.' '.$result->l_name,
                        'user_email' => $result->e_mail
                    );
                    $this->session->set_userdata('user_logged_in', $log_array);
                    $message = array("status" => "success","message" => 'chef-account');
                }else if(!password_verify($password, $result->user_password)){
                    throw new Exception("Invalid password, Please try again.");
                }else{
                    throw new Exception("User blocked. Please contact administrator.");
                }
            }else{
                throw new Exception("Invalid email, User not exists.");
            }
        }catch(Exception $ex){
            $message = array("status" => "error","message" => $ex->getMessage());
        }
        echo json_encode($message);
    }
    
}