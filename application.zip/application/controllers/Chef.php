<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Chef extends Chef_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('aayusmain');
        $this->load->model("Account_modal");
        $this->load->model("Common_modal");
        $this->load->model("Chef_modal");
        $this->setWallet();
    }

    function clear_cache()
    {
        $this->output->set_header("Cache-Control: no-store, no-cache, must-revalidate, no-transform, max-age=0, post-check=0, pre-check=0");
        $this->output->set_header("Pragma: no-cache");
    }

    public function index()
    {
        // $data['pageTitle'] = 'ACCOUNT';
        // $data['popular'] = $this->Common_modal->getFrontProducts(1,1,8);
        // $data['top'] = $this->Common_modal->getFrontProducts(1,2,10);
        // print_r($this->session->userdata());
        // die();
        $user_id = $this->session->userdata('user_logged_in')['user_id'];
        $data['orders'] = count($this->Common_modal->getAllWhereMore('tbl_user_order', 'user_id', $user_id));
        $data['new_order'] = count($this->Common_modal->getAllWhereMoreClause('tbl_user_order', array("user_id" => $user_id, "order_status" => 1)));
        $data['meals'] = count($this->Common_modal->getAllWhereMore('tbl_user_meal', 'user_id', $user_id));
        $sum = 0;
        $rate = 0;
        for ($i=1; $i < 6; $i++) { 
            $count = count($this->Common_modal->getAllWhereMoreClause('tbl_rating_feedback', array("user_id" => $user_id, "rating" => $i)));
            if($count >= $sum){
                $sum = $count;
                $rate = $i;
            }
        }
        $data['rating'] = $rate;
        $this->load->view('chef_panel', $data);
    }
    public function setWallet()
    {
        $data['inflows'] = $this->Common_modal->sumField('tbl_wallet_debit', 'amount', 'consumer_id', $this->session->userdata('cust_logged_in')['cust_id']);
        $data['outflows'] =    $this->Common_modal->sumField('tbl_wallet_credit', 'amount', 'consumer_id', $this->session->userdata('cust_logged_in')['cust_id']);
        // $data['notify'] = $this->USERDBAPI->getCount('tbl_message', 'merchant_id', 2);
        // $data['notify'] = $this->USERDBAPI->getWhere('tbl_message', array('merchant_id' => $this->session->userdata('user_id'), 'view' => 0));
        $this->session->set_userdata('wallet_balance', ($data['inflows']->total - $data['outflows']->total));
        // $this->session->set_userdata('notify', count($data['notify']));
    }

    public function chef_order()
    {
        $data['order_code'] = '';
        $data['date'] = '';
        $data['orders'] = $this->Chef_modal->getOrders($this->session->userdata('user_logged_in')['user_id'], $data);
        $this->load->view('chef_order', $data);
    }

    public function orders()
    {
        $data['order_code'] = $this->input->post('search');
        $data['date'] = $this->input->post('date');
        $user_id = $this->session->userdata['user_logged_in']['user_id'];
        $data['orders'] = $this->Chef_modal->getOrders($user_id, $data);
        $message = array("status" => "success", "message" => $data['orders'], "user_id" => $user_id);
        echo json_encode($message);
    }

    public function chef_update_order_ajax()
    {
        try {
            $order_id = $this->input->post('order_id');
            $status = $this->input->post('stat-update');

            if ($status == 6) {
                throw new Exception("Sorry, You cannot cancel orders");
            }

            $order = $this->Common_modal->getAllWhere('tbl_user_order', 'order_id', $order_id);

            if ($order->order_status == 6) {
                throw new Exception("Sorry, You cannot update cancelled order status");
            } else if ($order->order_status == $status) {
                throw new Exception("Sorry, You have not changed the status please select a new status");
            }

            $this->Common_modal->update('order_id', $order_id, "tbl_user_order", array("order_status" => $status));
            $message = array('status' => 'success', 'message' => 'Order Status Updated Successfully');
        } catch (Exception $e) {
            $message = array('status' => 'error', 'message' => $e->getMessage());
        }
        echo json_encode($message);
    }

    public function chef_view_order($id)
    {
        $id = base64_decode($id);

        $data['order_info'] = $this->Account_modal->getOrderInfo($id);
        $data['order_meal'] = $this->Account_modal->getOrderMealInfo($id);
        $data['order_cancel'] = $this->Account_modal->getOrderCancelInfo($id);
        $data['order_rating'] = $this->Common_modal->getAllWhere('tbl_rating_feedback', 'order_id', $id);
        foreach ($data['order_meal'] as $key => $value) {
            // echo $value->order_meal_id;
            $data['order_meal'][$key]->items = $this->Account_modal->getOrderMealItemInfo($value->order_meal_id);
        }
        $data['id'] = $id;
        $this->load->view('chef_view_order', $data);
    }

    public function chef_meals()
    {
        $data['order_code'] = '';
        $data['date'] = '';
        $data['orders'] = $this->Chef_modal->getOrders($this->session->userdata('user_logged_in')['user_id'], $data);
        $this->load->view('chef_meal', $data);
    }

    public function get_chef_meal_ajax()
    {
        $data['meal_name'] = $this->input->post('meal_name');
        $data['cat'] = $this->input->post('cat');
        $data['type'] = $this->input->post('type');
        $user_id = $this->session->userdata['user_logged_in']['user_id'];
        $data['meals'] = $this->Chef_modal->getMeals($user_id, $data);
        $message = array("status" => "success", "message" => $data['meals'], "user_id" => $user_id);
        echo json_encode($message);
    }

    public function view_meal($id)
    {
        $id = base64_decode($id);

        $data['order_info'] = $this->Chef_modal->getOrderInfo($id);
        $data['meal_info'] = $this->Chef_modal->getMealInfo($id);
        $data['meal_items'] = $this->Chef_modal->getMealItem($id);
        // foreach ($data['order_meal'] as $key => $value) {
        //     // echo $value->order_meal_id;
        //     $data['order_meal'][$key]->items = $this->Account_modal->getOrderMealItemInfo($value->order_meal_id);
        // }
        $data['id'] = $id;
        $this->load->view('chef_view_meal', $data);
    }

    public function chef_meal_qty_update_ajax()
    {
        try {
            $user_id = $this->session->userdata['user_logged_in']['user_id'];
            $data['meal_id'] = $this->input->post('meal_id');
            $data['qty-update'] = $this->input->post('qty-update');

            if ($data['qty-update'] == 0 || !is_numeric($data['qty-update'])) {
                throw new Exception("Please enter valid quantity");
            }

            $this->Common_modal->update('user_meal_id', $data['meal_id'], "tbl_user_meal", array("qty" => $data['qty-update']));
            $message = array('status' => 'success', 'message' => 'Quantity Updated Successfully');
        } catch (Exception $e) {
            $message = array('status' => 'error', 'message' => $e->getMessage());
        }
        echo json_encode($message);
    }

    public function chef_meal_status_update_ajax()
    {
        try {
            $user_id = $this->session->userdata['user_logged_in']['user_id'];
            $data['meal_id'] = $this->input->post('status_meal_id');
            $data['stat-update'] = $this->input->post('stat-update');
            $status_desc = '';
            if ($data['stat-update'] == 1) {
                $status_desc = 'Deactivated';
            } else {
                $status_desc = 'Activated';
            }

            $this->Common_modal->update('user_meal_id', $data['meal_id'], "tbl_user_meal", array("user_meal_status" => $data['stat-update']));
            $message = array('status' => 'success', 'message' => 'Your Meal ' . $status_desc . ' Successfully');
        } catch (Exception $e) {
            $message = array('status' => 'error', 'message' => $e->getMessage());
        }
        echo json_encode($message);
    }

    public function add_meal()
    {
        $data['cat'] = $this->Common_modal->getAllWhereMore('tbl_category', 'category_status', 1);
        $data['meal_item'] = $this->Common_modal->getAllWhereMore('tbl_menu_item', 'menu_status', 1);
        $this->load->view('chef_add_meal', $data);
    }

    public function save_meal_pack_ajax()
    {
        try {
            $data['user_id'] = $this->session->userdata['user_logged_in']['user_id'];
            $data['category_id'] = $this->input->post('meal_cat'); 
            $data['meal_name'] = $this->input->post('meal_name'); 
            $data['qty'] = $this->input->post('meal_qty'); 
            $data['min_price'] = $this->input->post('cat_price'); 
            $data['max_price'] = $this->input->post('cat_price'); 
            $data['user_meal_date'] = $this->input->post('meal_date'); 
            $data['user_meal_date_time_added'] = date('Y-m-d H:m:i'); 
            $data['user_meal_status'] = 1; 



            $data_item['item_list'] = $this->input->post('item_list'); 
            $data_item['item_id_list'] = $this->input->post('item_id_list');

            // echo "<pre>";
            // print_r($data_item['item_list']);
            // echo "</pre>";
            // die();

            if ($data['qty'] <= 5) {
                throw new Exception("quantitiy minimum has to be 5");
                
            }

            $valid_extensions = array('jpeg', 'jpg', 'png');
            $folder = $_SERVER['DOCUMENT_ROOT'] . "/cloud_meal/photos/";

            if (!empty($_FILES['meal_image'])) {
                $img = $_FILES['meal_image']['name'];
                $tmp = $_FILES['meal_image']['tmp_name'];
                $ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
                $final_image = date('Y_m_d') . '_' . time() . '_'  . $img;
                $image_for_db = '';
                if (!empty($img)) {
                    if (in_array($ext, $valid_extensions)) {
                        $folder = $folder . strtolower($final_image);
                        if (move_uploaded_file($tmp, $folder)) {
                            $data['meal_image'] = $final_image;
                             
                        } else {
                            throw new Exception("Can not upload original file...");
                        }
                    } else {
                        throw new Exception("Invalid image type");
                        
                    }
                }else{
                    $data['meal_image'] = '1537403022514-w2880-b8.jpg';
                }
            }       

            $user_meal_id = $this->Common_modal->insert("tbl_user_meal", $data);
            if ($user_meal_id) {
                $user_meal_items = [];
                $max_price = floatval($data['min_price']);
                foreach ($data_item['item_id_list'] as $key => $list_value) {
                    $user_meal_items[$key]['user_meal_id'] = $user_meal_id;
                    $user_meal_items[$key]['menu_item_id'] = $list_value;
                    $user_meal_items[$key]['item_price'] = $data_item['item_list'][$key];
                    $user_meal_items[$key]['user_meal_item_status'] = 1;

                    $max_price =  floatval($max_price) + floatval($data_item['item_list'][$key]);
                    
                }
                $meal_items_status = $this->Common_modal->insert_batch("tbl_user_meal_items", $user_meal_items);
                if ($meal_items_status) {
                    $this->Common_modal->update('user_meal_id', $user_meal_id, "tbl_user_meal", array("max_price" => $max_price));
                    $message = array('status' => 'success', 'message' => "saved succesfully", "data" => $user_meal_id);                    
                }else{                    
                    throw new Exception("Something went wrong with saving your items please try again");
                }
            }else{
                throw new Exception("Something went wrong. please try again");
            }
        } catch (Exception $e) {
            $message = array('status' => 'error', 'message' => $e->getMessage());
        }
        echo json_encode($message);
    }

    public function logout()
    {
        if ($this->session->userdata('user_logged_in') != null) {

            $log_array = array(
                'user_id' => '',
                'user_name' => '',
                'user_email' => ''
            );
            $this->session->set_userdata('user_logged_in', $log_array);
            $this->session->unset_userdata('user_logged_in');
            //$this->session->sess_destroy();
            $this->clear_cache();
            redirect(base_url());
        }
    }

    public function chef_meals_history()
    {
        $data['order_code'] = '';
        $data['date'] = '';
        $data['orders'] = $this->Chef_modal->getOrders($this->session->userdata('user_logged_in')['user_id'], $data);
        $this->load->view('chef_meal_history', $data);
    }



























































    public function cancel_order()
    {

        try {
            $cust_id = $this->session->userdata('cust_logged_in')['cust_id'];
            $order_id = $this->input->post('cancel_id');
            $reason = $this->input->post('reason');
            $order_info = $this->Common_modal->getAllWhere('tbl_user_order', 'order_id', $order_id);

            if ($order_info->order_status != 1) {
                throw new Exception("The cook has started working on your order just now, sorry you can't cancel now");
            }

            $wallet_debit = array(
                'consumer_id' => $cust_id,
                'referance' => 'CNL063892',
                'amount'  => $order_info->order_amount,
                'debit_date' => date('Y-m-d H:m:i')
            );
            $wallet_debit_id = $this->Common_modal->insert("tbl_wallet_debit", $wallet_debit);

            $order_cancel = array(
                'wallet_debit_id' => $wallet_debit_id,
                'order_id' => $order_id,
                'reason' => $reason,
                'cancel_date' => date('Y-m-d H:m:i')
            );
            $order_cancel_id = $this->Common_modal->insert("tbl_order_cancel", $order_cancel);
            $this->Common_modal->update('order_id', $order_id, "tbl_user_order", array("order_status" => 6));
            // echo "<pre>";
            // print_r($wallet_debit);
            // print_r($order_cancel);
            // echo "</pre>";
            // die();
            $message = array("status" => "success", "message" => "Your Order is Successfully Cancelled");
        } catch (Exception $e) {
            $message = array("status" => "error", "message" => $e->getMessage());
        }
        echo json_encode($message);
    }


    












    public function wishlist()
    {
        $data['pageTitle'] = 'WISHLIST';
        $user_id = $this->session->userdata['cust_logged_in']['cust_id'];
        $data['wishlist'] = $this->Account_modal->getwishlist($user_id);
        $this->load->view('ac_wishlist', $data);
    }

    public function removeWishListItem()
    {
        try {
            if (isset($_POST['id'])) {
                $id = $this->input->post('id');
                $user_id = $this->session->userdata['cust_logged_in']['cust_id'];
                $result = $this->Account_modal->check_user_wishlist($user_id, $id);
                if ($result == false) {
                    throw new Exception("Somthing went wrong :(");
                }
                $status = $this->Common_modal->delete('wish_list', 'wl_id', $id);
                if ($status) {
                    $message = array("status" => "success", "message" => "Product removed successfully");
                } else {
                    throw new Exception("Somthing went wrong :(");
                }
            } else {
                throw new Exception("Somthing went wrong :(");
            }
        } catch (Exception $ex) {
            $message = array("status" => "error", "message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    public function addresses()
    {
        $data['pageTitle'] = 'ADDRESSES';
        $user_id = $this->session->userdata['cust_logged_in']['cust_id'];
        $data['addresses'] = $this->Account_modal->getAddress($user_id);
        $data['countries'] = $this->Common_modal->getCountries();
        $this->load->view('ac_adresses', $data);
    }

    function add_address()
    {
        try {
            $fName = $this->input->post('first_name');
            $lName = $this->input->post('last_name');
            $mobile = $this->input->post('phone');
            $email = $this->input->post('email');
            $country = $this->input->post('country');
            $region = $this->input->post('region');
            $address = $this->input->post('address');
            $city = $this->input->post('city');
            $user_id = $this->session->userdata['cust_logged_in']['cust_id'];

            $addr_array = array(
                'fname' => $fName,
                'lname' => $lName,
                'address' => $address,
                'city_id' => $city,
                'reg_id' => $region,
                'country_id' => $country,
                'phone' => $mobile,
                'add_type' => 1,
                'user_id' => $user_id
            );
            $this->Common_modal->insert('addresses', $addr_array);
            $message = array("status" => "success", "message" => "Address added successfully");
        } catch (Exception $ex) {
            $message = array("status" => "error", "message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    public function deleteAddress()
    {
        try {
            if (isset($_POST['id'])) {
                $id = $this->input->post('id');
                $user_id = $this->session->userdata['cust_logged_in']['cust_id'];
                $result = $this->Account_modal->check_user_address($user_id, $id);
                if ($result == false) {
                    throw new Exception("Somthing went wrong :(");
                }
                $status = $this->Common_modal->delete('addresses', 'add_id', $id);
                if ($status) {
                    $message = array("status" => "success", "message" => "Address deleted successfully");
                } else {
                    throw new Exception("Somthing went wrong :(");
                }
            } else {
                throw new Exception("Somthing went wrong :(");
            }
        } catch (Exception $ex) {
            $message = array("status" => "error", "message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    public function messages()
    {
        $data['pageTitle'] = 'MESSAGES';
        $user_id = $this->session->userdata['cust_logged_in']['cust_id'];

        $this->load->view('ac_message', $data);
    }

    public function profile()
    {
        try {
            $data['pageTitle'] = 'PROFILE';
            $user_id = $this->session->userdata['cust_logged_in']['cust_id'];
            $data['profile'] = $this->Account_modal->getProfileDet($user_id);
            if ($data['profile'] == false) {
                throw new Exception("Somthing went wrong :(");
            }
            $data['countries'] = $this->Common_modal->getCountries();
            $data['region'] = $this->Common_modal->getRegion($data['profile']->country_id);
            $data['city'] = $this->Common_modal->getCities($data['profile']->reg_id);
            $this->load->view('ac_profile', $data);
        } catch (Exception $ex) {
            redirect(base_url());
        }
    }

    public function update_profile()
    {
        try {
            $fName = $this->input->post('first_name');
            $lName = $this->input->post('last_name');
            $mobile = $this->input->post('phone');
            $email = $this->input->post('email');
            $country = $this->input->post('country');
            $region = $this->input->post('region');
            $address = $this->input->post('address');
            $city = $this->input->post('city');
            $date = date("Y-m-d H:i:s");
            $user_id = $this->session->userdata['cust_logged_in']['cust_id'];

            $user_array = array(
                'fname' => $fName,
                'lname' => $lName,
                'mobile' => $mobile,
                'modified_date' => $date
            );

            $addr_array = array(
                'fname' => $fName,
                'lname' => $lName,
                'address' => $address,
                'city_id' => $city,
                'reg_id' => $region,
                'country_id' => $country,
                'phone' => $mobile
            );

            $result = $this->Account_modal->update_profile($user_id, $user_array, $addr_array);

            if ($result == TRUE) {
                $message = array("status" => "success", "message" => 'Profile updated successfully');
            } else {
                throw new Exception("Somthing went wrong :(");
            }
        } catch (Exception $ex) {
            $message = array("status" => "error", "message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    public function update_password()
    {
        try {
            $cpassword = trim($this->input->post('cpassword'));
            $npassword = trim($this->input->post('npassword'));
            $date = date("Y-m-d H:i:s");
            $user_id = $this->session->userdata['cust_logged_in']['cust_id'];
            $pass = $this->Common_modal->getSingleField('customers', 'password', 'cust_id', $user_id);
            if ($pass) {
                if (password_verify($cpassword, $pass->password)) {
                    $data = array(
                        'password' => $this->get_encrypted_password($npassword),
                        'modified_date' => $date
                    );
                    $this->Common_modal->update('cust_id', $user_id, 'customers', $data);
                    $message = array("status" => "success", "message" => 'Password updated successfully');
                } else {
                    throw new Exception("Current Password is invalid");
                }
            } else {
                throw new Exception("Somthing went wrong :(");
            }
        } catch (Exception $ex) {
            $message = array("status" => "error", "message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    public function contact()
    {
        $data['pageTitle'] = 'CONTACT';
        $user_id = $this->session->userdata['cust_logged_in']['cust_id'];
        $this->load->view('ac_contact', $data);
    }

    public function pay_order()
    {
        try {
            $order_id = $this->input->post('order_id');
            $user_id = $this->session->userdata['cust_logged_in']['cust_id'];

            $result = $this->Account_modal->check_user_order($user_id, $order_id);
            if ($result == false) {
                throw new Exception("Somthing went wrong :(");
            }
            $order_det = $this->Account_modal->getOrderPaydet($order_id);
            if ($order_det == false) {
                throw new Exception("Somthing went wrong :(");
            }
            $cart_total = floatval($order_det->cart_total);
            $del_charge = floatval($order_det->del_charge);
            $discount = floatval($order_det->discount);
            $paid_total = floatval($order_det->paid_total);
            $order_total = ($cart_total + $del_charge) - $discount;
            $balance = $order_total - $paid_total;

            $message = '<input type="hidden" name="merchant_id" value="212118">' .
                '<input type="hidden" name="return_url" value="' . base_url() . 'success-page">' .
                '<input type="hidden" name="cancel_url" value="' . base_url() . 'failure-page">' .
                '<input type="hidden" name="notify_url" value="' . base_url() . 'notify-url">' .
                '<input type="hidden" name="order_id" value="' . $order_det->order_code . '">' .
                '<input type="hidden" name="items" value="' . $order_det->order_code . '">' .
                '<input type="hidden" name="currency" value="LKR">' .
                '<input type="hidden" name="amount" value="' . $balance . '">' .
                '<input type="hidden" name="first_name" value="' . $order_det->fname . '">' .
                '<input type="hidden" name="last_name" value="' . $order_det->lname . '">' .
                '<input type="hidden" name="email" value="' . $order_det->order_email . '">' .
                '<input type="hidden" name="phone" value="' . $order_det->phone . '">' .
                '<input type="hidden" name="address" value="' . $order_det->address . '">' .
                '<input type="hidden" name="city" value="' . $order_det->city_name . '">' .
                '<input type="hidden" name="country" value="' . $order_det->nicename . '">';
        } catch (Exception $ex) {
            $message = array("status" => "error", "message" => $ex->getMessage());
        }
        echo json_encode($message);
    }

    
}
