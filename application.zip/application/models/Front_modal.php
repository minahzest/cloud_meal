<?php

use function PHPSTORM_META\type;

class Front_modal extends CI_Model {
    public function __construct(){
        parent::__construct();
        $this->load->model("Common_modal");
    }

    public function get_meal_packs($data){
        $this->db->select('um.*, c.category, c.category_price, ua.f_name, ua.l_name'); 
        $this->db->from('tbl_user_meal um');
        if ($data['cat'] != 0) {
            $this->db->where('um.category_id', $data['cat']);
        }
        if ($data['filter_date'] != '') {
            $this->db->where('um.user_meal_date', $data['filter_date']);
        }
        $this->db->where('um.user_meal_status', 1);
        $this->db->join('tbl_category c', 'c.category_id=um.category_id');
        $this->db->join('tbl_user_account ua', 'ua.user_id=um.user_id');
        $this->db->join('tbl_addresses a', 'a.user_id=um.user_id', 'left');
        if ($data['filter_city'] != 0) {
            $this->db->where('a.city_id', $data['filter_city']);
        }
        $this->db->where('um.user_meal_date >=', date('Y-m-d'));
        $this->db->order_by("user_meal_date_time_added", "asc");
        $query = $this->db->get();
        return $query->result();

    }

    public function get_meal_pack_item($data){
        $this->db->select('umi.*, mi.*'); 
        $this->db->from('tbl_user_meal_items umi');
        $this->db->where('umi.user_meal_id', $data['id']);
        $this->db->where('umi.user_meal_item_status', 1);
        $this->db->join('tbl_menu_item mi', 'mi.menu_item_id=umi.menu_item_id');
        // $this->db->order_by("user_meal_date_time_added", "asc");
        $query = $this->db->get();
        return $query->result();
    }

    function saveCust($user_array,$addr_array){
        $this->db->trans_start();
        $this->db->insert('tbl_consumers',$user_array);
        $addr_array['consumer_id'] =  $this->db->insert_id();
        $this->db->insert('tbl_consumer_address',$addr_array);
        
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE) {
            return FALSE;
        } else {
            $this->db->trans_commit();
            return TRUE;
        }
    }

    function get_login_cust($email) {
        $this->db->select('consumer_id,consumer_f_name,consumer_l_name,consumer_email,consumer_password,consumer_status'); 
        $this->db->from('tbl_consumers');
        $this->db->where('consumer_email', $email);
        $this->db->limit(1);
        $query = $this->db->get();
        if($query->num_rows() == 1){
          return $query->row();
        }else{
          return false;
        }
    }

    function getProCartDet($id){
        $this->db->select('p.pro_id,p.pro_code,p.name,p.price,p.quantity,p.weight,p.added_date,q.pid,q.photo_path,q.photo_title');
        $this->db->from("products p");
        $this->db->where("p.pro_id", $id);
        $this->db->where('p.status', 0);
        $this->db->join('photo q', 'q.table="products" AND q.field_id = p.pro_id');
        $this->db->order_by("photo_order", "asc");
        $this->db->group_by("p.pro_id");
        $this->db->limit(1);
        $query = $this->db->get();
        if($query->num_rows() == 1){
          return $query->row();
        }else{
          return false;
        }
    }

    function getMealItem($id){
        // $tex = gettype($id); 
        // echo $tex;
        // print_r();
        
        $this->db->select('umi.*,mi.item_name');
        $this->db->from("tbl_user_meal_items umi");
        $this->db->where("umi.user_meal_items_id in(".$id.")");
        $this->db->where("umi.user_meal_item_status",1);
        $this->db->join('tbl_menu_item mi', 'umi.menu_item_id=mi.menu_item_id');
        $this->db->order_by("umi.user_meal_items_id", "asc");
        // $this->db->group_by("umi.user_meal_items_id");
        $query = $this->db->get();
        // print_r($this->db);
        return $query->result();
    }

    function get_login_chef($email) {
        $this->db->select('user_id,f_name,l_name,e_mail,user_password,user_status'); 
        $this->db->from('tbl_user_account');
        $this->db->where('e_mail', $email);
        $this->db->limit(1);
        $query = $this->db->get();
        if($query->num_rows() == 1){
          return $query->row();
        }else{
          return false;
        }
    }
}
