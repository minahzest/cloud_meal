<?php
class Common_modal extends CI_Model {
    function getAll($table){
		$this->db->select('*');
		$this->db->from($table);
		$query = $this->db->get();
		return $query->result();
	}
	function insert($table,$data){
		$this->db->insert($table, $data); 
		return  $this->db->insert_id();
	}
	function update($idName,$id,$table,$data){
		$this->db->where($idName, $id);
		$this->db->update($table, $data); 
	}
	function delete($table,$idName,$val){
        $this->db->where($idName, $val);
        $this->db->delete($table);
        if($this->db->affected_rows()>0){
            return $val;
        }else{
            return false;
        }
    }
	function getAllWhere($table,$idName,$val){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($idName, $val);
        $this->db->limit(1);
        $query = $this->db->get();
        if($query->num_rows() == 1){
          return $query->row();
        }else{
          return false;
        }
    }
  function getAllWhereMore($table,$idName,$val){
      $this->db->select('*');
      $this->db->from($table);
      $this->db->where($idName, $val);
      $query = $this->db->get();
      return $query->result();
  }
  function getAllWhereMoreClause($table,$idName){
    $this->db->select('*');
    $this->db->from($table);
    $this->db->where($idName);
    $query = $this->db->get();
    return $query->result();
}
    function getAllWhereGreaterThan($table,$idName){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($idName.">", 0);
        $this->db->where('status', 0);
        $query = $this->db->get();
        if($query->num_rows() > 1){
          return $query->row();
        }else{
          return false;
        }
    }
    function getCountries(){
		$this->db->select('country_id,nicename');
		$this->db->from('country');
		$this->db->order_by('nicename', "asc");
		$query = $this->db->get();
		return $query->result();
	}
    function getRegion($country){
		$this->db->select('reg_id,region_name');
		$this->db->from('regions');
	   	$this->db->where('country_id', $country);
		$this->db->order_by('region_name', "asc");
		$query = $this->db->get();
		return $query->result();
	}
	function getCities($region){
		$this->db->select('city_id,city_name');
		$this->db->from('cities');
	   	$this->db->where('reg_id', $region);
		$this->db->order_by('city_name', "asc");
		$query = $this->db->get();
		return $query->result();
	}
	function checkField($table,$id,$value){
		$this->db->select($id);
		$this->db->from($table);
	   	$this->db->where($id, $value);
	   	$this->db->limit(1);
		$query = $this->db->get();
		if($query->num_rows() == 1){
			return true;
		}else{
			return false;
		}
	}
	function getSingleField($table,$col,$id, $value){
      $this->db->select($col);
      $this->db->from($table);
      $this->db->where($id, $value);
      $this->db->limit(1);
      $query = $this->db->get();
      if($query->num_rows() == 1){
        return $query->row();
      }else{
        return false;
      }
  }

  function getAllCate(){
      $this -> db -> select('*'); 
      $this -> db -> from('categories');
      $this -> db -> where('parent_id', 0);
      $this -> db -> where('status', 0);
      $this->db->order_by("cate_id", "asc");
      $query = $this -> db -> get();
      $main_cats = $query -> result();
      foreach ($main_cats as $main_cat) {
          $child = $this->get_child_categories($main_cat->cate_id);
          
          $main_cat->sub_cat = $child;
      }
      return $main_cats;
  }
  function getNextMainCat($prev_id){
      $this->db->select('*');
      $this -> db -> from('categories');
      $this -> db -> where('cate_id >', $prev_id);
      $this -> db -> where('status', 0);
      $this -> db -> where('parent_id', 0);
      $this->db->order_by("cate_id", "asc");
      $this->db->limit(1);
        
      $query = $this->db->get();
      if(0<$query->num_rows()){
        return $query->row();
      }else{
        return false;
      }
  }
  function getMaxId($field,$table)
  {
    $maxid = 0;
  $row = $this->db->query('SELECT MAX('.$field.') AS maxid FROM '.$table)->row();
  if ($row) {
      $maxid = $row->maxid; 
  }
  return $maxid;
  }
  function increaseField($idName,$id,$table,$field,$amount){
      $this->db->where($idName, $id);
      $this->db->set($field, $field.'+'.$amount, FALSE);
      $this->db->update($table); 
  }
  function decreaseField($idName,$id,$table,$field,$amount){
      $this->db->where($idName, $id);
      $this->db->set($field, $field.'-'.$amount, FALSE);
      $this->db->update($table); 
  }
  function sumField($table,$col,$id, $value){
    $this->db->select('SUM('.$col.') as total');
    $this->db->from($table);
    $this->db->where($id, $value);
    $this->db->limit(1);
    $query = $this->db->get();
    if($query->num_rows() == 1){
      return $query->row();
    }else{
      return false;
    }
  }
  public function insert_batch($table, $data)
  {
      $this->db->trans_start();
      $this->db->insert_batch($table, $data);
      $this->db->trans_complete();
      if ($this->db->trans_status() === FALSE) {
          return FALSE;
      } else {
          $this->db->trans_commit();
          return TRUE;
      }
  }
}
