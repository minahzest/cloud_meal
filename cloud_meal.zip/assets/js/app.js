/*-----------------------------------------------------------------------------------

	Theme Name: Seiko HTML5 eCommerce Template
	Author: BigSteps
	Author URI: http://themeforest.net/user/bigsteps
	Version: 1.2.0

-----------------------------------------------------------------------------------*/

$(function () {

	"use strict";

	// mobile menu
	$.fn.mobileMenu = function () {

		var $mobilemenu = $(this),
			$toggleMenu = $('.mobilemenu-toggle');

		$toggleMenu.on('click.mobileMenu', function () {
			$mobilemenu.toggleClass('active');
			$body.toggleClass('fixed');
			return false;
		});
	}

	// Megamenu
  if ($(".megamenu").length) {
	  $(".megamenu").megaMenu();
  }
	// mobile menu	
	$(".mobilemenu").mobileMenu();
	if ($(".filter-col").length) {
		$(".filter-col").isFilters();
		$(".filter-col").mobileFilter();
	}
	
})